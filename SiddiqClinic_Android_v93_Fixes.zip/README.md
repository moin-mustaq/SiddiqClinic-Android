# SiddiqClinic Android v93

Fixes: bill header rendering, OPD/LAB patient ID direct search, bill preview restoration, prescription patient/vitals field rendering, and Patients Admitted Today count includes checked-out admissions.
