package com.siddiqclinic.android;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

public final class BackupManager {
    public static final int APP_VERSION = 113;
    public static final int BACKUP_FORMAT_VERSION = 1;
    private static final String PREF = "backup_settings";
    private static final String KEY_LOCAL_ENABLED="local_enabled";
    private static final String KEY_CLOUD_ENABLED="cloud_enabled";
    private static final String KEY_LOCAL_HOURS="local_hours";
    private static final String KEY_CLOUD_HOURS="cloud_hours";
    private static final String KEY_LOCAL_RETENTION="local_retention";
    private static final String KEY_CLOUD_RETENTION="cloud_retention";
    private static final String KEY_TREE_URI="cloud_tree_uri";
    private static final String KEY_LAST_LOCAL="last_local_ms";
    private static final String KEY_LAST_CLOUD="last_cloud_ms";

    private BackupManager() {}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}

    public static String hospitalName(Context c){
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READONLY)){
            Cursor cur=d.rawQuery("SELECT hospital_name FROM hospital_profile WHERE profile_id=1 LIMIT 1",null);
            String s="SIDDIQ HOSPITAL"; if(cur.moveToFirst()) s=cur.getString(0); cur.close();
            return s==null||s.trim().isEmpty()?"SIDDIQ HOSPITAL":s.trim();
        }catch(Exception e){return "SIDDIQ HOSPITAL";}
    }
    public static String safeHospital(String s){
        s=s==null?"":s.replaceAll("\\s+","").replaceAll("[^A-Za-z0-9._&-]","");
        return s.isEmpty()?"Hospital":""+s;
    }
    public static String today(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    public static String fileName(Context c){return safeHospital(hospitalName(c))+"_v"+APP_VERSION+"_"+today()+".zip";}
    public static File backupDir(Context c){File d=new File(c.getExternalFilesDir(null),"Backups");if(!d.exists())d.mkdirs();return d;}

    public static JSONObject status(Context c){
        JSONObject o=new JSONObject(); try{
            SharedPreferences p=prefs(c);o.put("localEnabled",p.getBoolean(KEY_LOCAL_ENABLED,true));o.put("cloudEnabled",p.getBoolean(KEY_CLOUD_ENABLED,false));
            o.put("localHours",p.getInt(KEY_LOCAL_HOURS,1));o.put("cloudHours",p.getInt(KEY_CLOUD_HOURS,6));o.put("localRetention",p.getInt(KEY_LOCAL_RETENTION,30));o.put("cloudRetention",p.getInt(KEY_CLOUD_RETENTION,30));
            o.put("cloudConnected",p.getString(KEY_TREE_URI,"").length()>0);o.put("hospitalName",hospitalName(c));o.put("safeHospitalName",safeHospital(hospitalName(c)));o.put("todayFile",fileName(c));
            File f=new File(backupDir(c),fileName(c));o.put("localFileExists",f.exists());o.put("localFileSize",f.exists()?f.length():0);o.put("lastLocalMs",p.getLong(KEY_LAST_LOCAL,0));o.put("lastCloudMs",p.getLong(KEY_LAST_CLOUD,0));
        }catch(Exception ignored){} return o;
    }

    public static void saveSettings(Context c, boolean le,int lh,boolean ce,int ch,int lr,int cr){
        lh=Math.max(1,Math.min(168,lh));ch=Math.max(1,Math.min(168,ch));lr=Math.max(1,Math.min(365,lr));cr=Math.max(1,Math.min(365,cr));
        prefs(c).edit().putBoolean(KEY_LOCAL_ENABLED,le).putInt(KEY_LOCAL_HOURS,lh).putBoolean(KEY_CLOUD_ENABLED,ce).putInt(KEY_CLOUD_HOURS,ch).putInt(KEY_LOCAL_RETENTION,lr).putInt(KEY_CLOUD_RETENTION,cr).apply();
        BackupWorker.schedule(c);
    }
    public static void setTreeUri(Context c,Uri uri){
        if(uri==null)return;int flags=Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        try{c.getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
        prefs(c).edit().putString(KEY_TREE_URI,uri.toString()).apply();BackupWorker.schedule(c);
    }
    public static void clearTreeUri(Context c){prefs(c).edit().remove(KEY_TREE_URI).apply();BackupWorker.schedule(c);}
    public static Uri treeUri(Context c){String s=prefs(c).getString(KEY_TREE_URI,"");return s.isEmpty()?null:Uri.parse(s);}

    public static File createLocalBackup(Context c)throws Exception{return createLocalBackup(c,false);}
    public static File createLocalBackup(Context c,boolean manual)throws Exception{
        File dir=backupDir(c);if(!dir.exists()&&!dir.mkdirs())throw new IOException("Unable to create local backup folder");
        File out=new File(dir,fileName(c));File tmp=new File(dir,out.getName()+".tmp");if(tmp.exists())tmp.delete();
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");
        // Flush SQLite WAL before taking the snapshot.
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){try{d.rawQuery("PRAGMA wal_checkpoint(FULL)",null).close();}catch(Exception ignored){}}
        JSONObject info=new JSONObject();info.put("backup_format_version",BACKUP_FORMAT_VERSION);info.put("application_name","Siddiq Clinic");info.put("application_version",APP_VERSION);info.put("database_version",APP_VERSION);info.put("hospital_name",hospitalName(c));info.put("backup_date",today());info.put("created_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));
        try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))){
            putText(z,"backup_info.json",info.toString(2));
            addFile(z,db,"database/SiddiqClinic.db");
            addIfExists(z,new File(db.getPath()+"-wal"),"database/SiddiqClinic.db-wal");
            addIfExists(z,new File(db.getPath()+"-shm"),"database/SiddiqClinic.db-shm");
            File pres=new File(c.getFilesDir(),"prescriptions");if(pres.exists())addDir(z,pres,"prescriptions");
        }
        if(out.exists()&&!out.delete())throw new IOException("Unable to replace previous daily backup");if(!tmp.renameTo(out)){copy(tmp,out);tmp.delete();}
        prefs(c).edit().putLong(KEY_LAST_LOCAL,System.currentTimeMillis()).apply();pruneLocal(c);
        return out;
    }
    private static void putText(ZipOutputStream z,String name,String s)throws IOException{ZipEntry e=new ZipEntry(name);z.putNextEntry(e);z.write(s.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private static void addIfExists(ZipOutputStream z,File f,String path)throws IOException{if(f.exists())addFile(z,f,path);}
    private static void addDir(ZipOutputStream z,File dir,String base)throws IOException{File[] fs=dir.listFiles();if(fs==null)return;for(File f:fs){String p=base+"/"+f.getName();if(f.isDirectory())addDir(z,f,p);else addFile(z,f,p);}}
    private static void addFile(ZipOutputStream z,File f,String path)throws IOException{ZipEntry e=new ZipEntry(path);z.putNextEntry(e);try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)z.write(b,0,n);}z.closeEntry();}
    private static void copy(File a,File b)throws IOException{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[]x=new byte[16384];int n;while((n=i.read(x))>0)o.write(x,0,n);}}

    public static void syncLatestToDrive(Context c)throws Exception{
        Uri tree=treeUri(c);if(tree==null)throw new IOException("Google Drive is not connected");
        File local=createLocalBackup(c,false);DocumentFile parent=DocumentFile.fromTreeUri(c,tree);if(parent==null||!parent.canWrite())throw new IOException("Google Drive location is not writable");
        String rootName=safeHospital(hospitalName(c))+"_backup";DocumentFile root=findOrCreateDir(parent,rootName);DocumentFile day=findOrCreateDir(root,today());
        DocumentFile old=day.findFile(local.getName());if(old!=null)old.delete();DocumentFile dest=day.createFile("application/zip",local.getName());if(dest==null)throw new IOException("Unable to create backup file in Google Drive");
        try(InputStream in=new BufferedInputStream(new FileInputStream(local));OutputStream out=c.getContentResolver().openOutputStream(dest.getUri(),"w")){if(out==null)throw new IOException("Unable to open Google Drive file");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}
        prefs(c).edit().putLong(KEY_LAST_CLOUD,System.currentTimeMillis()).apply();pruneCloud(c,parent,root);
    }
    private static DocumentFile findOrCreateDir(DocumentFile parent,String name)throws IOException{DocumentFile f=parent.findFile(name);if(f!=null&&f.isDirectory())return f;if(f!=null)f.delete();f=parent.createDirectory(name);if(f==null)throw new IOException("Unable to create Google Drive folder: "+name);return f;}
    private static void pruneLocal(Context c){int keep=prefs(c).getInt(KEY_LOCAL_RETENTION,30);File[] fs=backupDir(c).listFiles((d,n)->n.endsWith(".zip"));if(fs==null||fs.length<=keep)return;Arrays.sort(fs,Comparator.comparingLong(File::lastModified));for(int i=0;i<fs.length-keep;i++)fs[i].delete();}
    private static void pruneCloud(Context c,DocumentFile parent,DocumentFile root){int keep=prefs(c).getInt(KEY_CLOUD_RETENTION,30);DocumentFile[] fs=root.listFiles();List<DocumentFile> days=new ArrayList<>();for(DocumentFile f:fs)if(f.isDirectory()&&f.getName()!=null&&f.getName().matches("\\d{8}"))days.add(f);if(days.size()<=keep)return;days.sort(Comparator.comparing(DocumentFile::getName));for(int i=0;i<days.size()-keep;i++)days.get(i).delete();}

    public static JSONObject restoreZip(Context c,InputStream input)throws Exception{
        File tmp=new File(c.getCacheDir(),"restore_"+System.currentTimeMillis()+".zip");try(OutputStream o=new FileOutputStream(tmp)){byte[]b=new byte[32768];int n;while((n=input.read(b))>0)o.write(b,0,n);}return restoreZipFile(c,tmp);
    }
    public static JSONObject restoreZipFile(Context c,File zip)throws Exception{
        JSONObject info=null;File stage=new File(c.getCacheDir(),"restore_stage_"+System.currentTimeMillis());if(!stage.mkdirs())throw new IOException("Unable to create restore staging folder");
        try(ZipFile z=new ZipFile(zip)){ZipEntry ie=z.getEntry("backup_info.json");if(ie==null)throw new IOException("Invalid backup: backup_info.json is missing");try(InputStream in=z.getInputStream(ie)){ByteArrayOutputStream bout=new ByteArrayOutputStream();byte[] bb=new byte[8192];int nn;while((nn=in.read(bb))>0)bout.write(bb,0,nn);info=new JSONObject(new String(bout.toByteArray(),StandardCharsets.UTF_8));}int fmt=info.optInt("backup_format_version",0);if(fmt!=BACKUP_FORMAT_VERSION)throw new IOException("Unsupported backup format version: "+fmt);ZipEntry db=z.getEntry("database/SiddiqClinic.db");if(db==null)throw new IOException("Backup database is missing");extract(z,"database/",new File(stage,"database"));extract(z,"prescriptions/",new File(stage,"prescriptions"));}
        int backupVersion=info.optInt("application_version",0);File stagedDb=new File(stage,"database/SiddiqClinic.db");if(!stagedDb.exists()||stagedDb.length()<10000)throw new IOException("Backup database is invalid or empty");
        // Validate that SQLite can open the staged database before touching current data.
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(stagedDb.getPath(),null,SQLiteDatabase.OPEN_READONLY)){d.rawQuery("SELECT name FROM sqlite_master LIMIT 1",null).close();}
        File safety=createLocalBackup(c,true);
        File currentDb=new File(c.getFilesDir(),"SiddiqClinic.db");copy(stagedDb,currentDb);
        File sp=new File(c.getFilesDir(),"prescriptions");if(sp.exists())deleteTree(sp);File stagedPres=new File(stage,"prescriptions");if(stagedPres.exists())copyTree(stagedPres,sp);
        deleteTree(stage);try{zip.delete();}catch(Exception ignored){}
        JSONObject out=new JSONObject();out.put("backupVersion",backupVersion);out.put("currentVersion",APP_VERSION);out.put("migrated",backupVersion!=APP_VERSION);out.put("safetyBackup",safety.getName());return out;
    }
    private static void extract(ZipFile z,String prefix,File dest)throws IOException{dest.mkdirs();Enumeration<? extends ZipEntry> en=z.entries();while(en.hasMoreElements()){ZipEntry e=en.nextElement();if(e.isDirectory()||!e.getName().startsWith(prefix))continue;String rel=e.getName().substring(prefix.length());if(rel.isEmpty())continue;File f=new File(dest,rel);File canon=dest.getCanonicalFile();if(!f.getCanonicalPath().startsWith(canon.getPath()+File.separator))throw new IOException("Unsafe backup path");f.getParentFile().mkdirs();try(InputStream in=z.getInputStream(e);OutputStream out=new FileOutputStream(f)){byte[]b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}}}
    private static void copyTree(File src,File dst)throws IOException{if(src.isDirectory()){dst.mkdirs();File[]fs=src.listFiles();if(fs!=null)for(File f:fs)copyTree(f,new File(dst,f.getName()));}else{dst.getParentFile().mkdirs();copy(src,dst);}}
    private static void deleteTree(File f){if(!f.exists())return;if(f.isDirectory()){File[]fs=f.listFiles();if(fs!=null)for(File x:fs)deleteTree(x);}f.delete();}
}
