package com.siddiqclinic.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.print.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.util.Base64;
import android.net.Uri;
import android.os.*;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import android.widget.FrameLayout;
import androidx.core.content.FileProvider;
import org.json.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean prescriptionPdfBusy=false;
    private File dbFile;
    private static final int RESTORE_DB = 4101;
    private static final int PICK_HOSPITAL_LOGO = 4102;
    private static final int CONNECT_GOOGLE_DRIVE = 4103;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(18,59,109));
        getWindow().setNavigationBarColor(Color.rgb(18,59,109));
        dbFile = new File(getFilesDir(), "SiddiqClinic.db");
        if (!dbFile.exists()) copyAsset("database/TEST.db", dbFile);
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setTextZoom(100);
        webView.setBackgroundColor(Color.rgb(244,246,249));
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient(){ @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail){ runOnUiThread(()->Toast.makeText(MainActivity.this,"WebView renderer stopped. Reloading Siddiq Clinic...",Toast.LENGTH_LONG).show()); try{ view.destroy(); }catch(Exception ignored){} recreateMainWebView(); return true; } });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        BackupWorker.schedule(this);
    }

    private void recreateMainWebView(){
        runOnUiThread(()->{
            try{
                WebView nw=new WebView(MainActivity.this);
                WebSettings ws=nw.getSettings();
                ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
                ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setTextZoom(100);
                nw.setBackgroundColor(Color.rgb(244,246,249));
                nw.addJavascriptInterface(new Bridge(),"Android");
                nw.setWebViewClient(new WebViewClient(){ @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail){ return true; } });
                webView=nw;
                setContentView(webView);
                webView.loadUrl("file:///android_asset/index.html");
            }catch(Exception e){ Toast.makeText(MainActivity.this,"Unable to reload Siddiq Clinic: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        });
    }

    private void copyAsset(String name, File dest) {
        try (InputStream in = getAssets().open(name); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
        } catch(Exception e){ throw new RuntimeException(e); }
    }

    private SQLiteDatabase openDb() { return SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.OPEN_READWRITE); }
    private String jsonRows(Cursor c) throws Exception {
        JSONArray a=new JSONArray(); String[] cols=c.getColumnNames();
        while(c.moveToNext()){ JSONObject o=new JSONObject(); for(int i=0;i<cols.length;i++){ int t=c.getType(i); Object v; switch(t){case Cursor.FIELD_TYPE_NULL:v=JSONObject.NULL;break;case Cursor.FIELD_TYPE_INTEGER:v=c.getLong(i);break;case Cursor.FIELD_TYPE_FLOAT:v=c.getDouble(i);break;default:v=c.getString(i);} o.put(cols[i],v);} a.put(o); }
        c.close(); return a.toString();
    }
    private Object bind(JSONArray p,int i) throws Exception { Object v=p.opt(i); if(v==JSONObject.NULL) return null; return v; }

    public class Bridge {
        @JavascriptInterface public String sha256(String s){ try{byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)); StringBuilder h=new StringBuilder(); for(byte x:d) h.append(String.format("%02x",x)); return h.toString();}catch(Exception e){return "";} }
        @JavascriptInterface public String query(String sql, String paramsJson){ SQLiteDatabase d=null; Cursor c=null; try{d=openDb(); JSONArray p=new JSONArray(paramsJson==null?"[]":paramsJson); String[] args=new String[p.length()]; for(int i=0;i<p.length();i++){ Object v=bind(p,i); args[i]=v==null?null:String.valueOf(v); } c=d.rawQuery(sql,args); return jsonRows(c);}catch(Exception e){return error(e);}finally{if(c!=null&&!c.isClosed())c.close();if(d!=null)d.close();} }
        @JavascriptInterface public String execute(String sql, String paramsJson){SQLiteDatabase d=null; try{d=openDb(); JSONArray p=new JSONArray(paramsJson==null?"[]":paramsJson); Object[] args=new Object[p.length()]; for(int i=0;i<p.length();i++) args[i]=bind(p,i); d.execSQL(sql,args); long id=-1; try{Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);if(c.moveToFirst())id=c.getLong(0);c.close();}catch(Exception ignored){} JSONObject o=new JSONObject();o.put("ok",true);o.put("lastInsertRowId",id);return o.toString();}catch(Exception e){return error(e);}finally{if(d!=null)d.close();}}
        @JavascriptInterface public String executeBatch(String batchJson){SQLiteDatabase d=null; try{d=openDb(); JSONArray b=new JSONArray(batchJson); d.beginTransaction(); long id=-1; for(int i=0;i<b.length();i++){JSONObject x=b.getJSONObject(i);JSONArray p=x.optJSONArray("params");Object[] args=new Object[p==null?0:p.length()];for(int j=0;j<args.length;j++)args[j]=bind(p,j);d.execSQL(x.getString("sql"),args);Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);if(c.moveToFirst())id=c.getLong(0);c.close();}d.setTransactionSuccessful();d.endTransaction();JSONObject o=new JSONObject();o.put("ok",true);o.put("lastInsertRowId",id);return o.toString();}catch(Exception e){if(d!=null&&d.inTransaction())d.endTransaction();return error(e);}finally{if(d!=null)d.close();}}
        private String error(Exception e){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",e.toString());return o.toString();}catch(Exception x){return "{\"ok\":false}";}}

        @JavascriptInterface public void toast(String msg){runOnUiThread(()->Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show());}
        @JavascriptInterface public void alert(String title,String msg){runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show());}
        @JavascriptInterface public void shareText(String subject,String text){Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_SUBJECT,subject);s.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(s,"Share"));}
        @JavascriptInterface public void whatsapp(String phone,String text){try{String p=phone==null?"":phone.replaceAll("[^0-9]","");String url="https://wa.me/"+(p.startsWith("91")?p:"91"+p)+"?text="+Uri.encode(text);startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("WhatsApp is not available");}}
        @JavascriptInterface public void chooseHospitalLogo(){
            try{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i,PICK_HOSPITAL_LOGO);
            }catch(Exception e){ alert("Hospital Logo","Unable to open image picker: "+e); }
        }
        @JavascriptInterface public void printPage(){
            runOnUiThread(()->{
                try{
                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                    PrintDocumentAdapter ad=webView.createPrintDocumentAdapter("Siddiq Clinic");
                    pm.print("Siddiq Clinic",ad,new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                }catch(Exception e){ alert("Print","Unable to start printing: "+e.getMessage()); }
            });
        }

        private String compactEmbeddedImages(String html){
            if(html==null || html.length()<1000) return html==null?"":html;
            Pattern p=Pattern.compile("src\\s*=\\s*([\\\"\\\'])data:image/[^;]+;base64,([^\\\"\\\']+)\\1",Pattern.CASE_INSENSITIVE);
            Matcher m=p.matcher(html); StringBuffer sb=new StringBuffer();
            while(m.find()){
                try{
                    byte[] raw=Base64.decode(m.group(2),Base64.DEFAULT);
                    Bitmap src=BitmapFactory.decodeByteArray(raw,0,raw.length);
                    if(src==null){m.appendReplacement(sb,Matcher.quoteReplacement(m.group(0)));continue;}
                    int maxW=1000,maxH=500,w=src.getWidth(),h=src.getHeight();
                    float scale=Math.min(1f,Math.min((float)maxW/w,(float)maxH/h));
                    Bitmap b=src;
                    if(scale<1f){int nw=Math.max(1,Math.round(w*scale)),nh=Math.max(1,Math.round(h*scale));b=Bitmap.createScaledBitmap(src,nw,nh,true);}
                    // Canvas handwriting PNGs commonly contain a transparent background.
                    // Bitmap.compress(JPEG) converts transparent pixels to black, which was
                    // causing the entire handwriting area to appear as a solid black box in
                    // generated/viewed/printed prescriptions. Composite onto white first.
                    Bitmap white=Bitmap.createBitmap(b.getWidth(),b.getHeight(),Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas wc=new android.graphics.Canvas(white);
                    wc.drawColor(Color.WHITE);
                    wc.drawBitmap(b,0,0,null);
                    ByteArrayOutputStream bos=new ByteArrayOutputStream();
                    white.compress(Bitmap.CompressFormat.JPEG,88,bos);
                    String enc=Base64.encodeToString(bos.toByteArray(),Base64.NO_WRAP);
                    String replacement="src=\"data:image/jpeg;base64,"+enc+"\"";
                    m.appendReplacement(sb,Matcher.quoteReplacement(replacement));
                    if(white!=b) white.recycle();
                    if(b!=src) b.recycle();
                    src.recycle();
                }catch(Throwable ignored){
                    m.appendReplacement(sb,Matcher.quoteReplacement(m.group(0)));
                }
            }
            m.appendTail(sb); return sb.toString();
        }

        private void savePrescriptionPdfInternal(String html,String relativePath, final Runnable onSuccess, final Runnable onFailure){
            runOnUiThread(()->{
                if(prescriptionPdfBusy){ if(onFailure!=null) onFailure.run(); return; }
                prescriptionPdfBusy=true;
                final File out=new File(getFilesDir(),relativePath==null?"prescriptions/prescription.pdf":relativePath);
                File parent=out.getParentFile();
                if(parent!=null&&!parent.exists()&&!parent.mkdirs()&&!parent.exists()){
                    prescriptionPdfBusy=false; if(onFailure!=null) onFailure.run();
                    return;
                }

                final ViewGroup contentRoot=(ViewGroup)findViewById(android.R.id.content);
                if(contentRoot==null){ prescriptionPdfBusy=false; if(onFailure!=null) onFailure.run(); return; }

                final WebView w=new WebView(MainActivity.this);
                final boolean[] finished={false};
                final Runnable cleanup=()->{
                    try{ if(w.getParent() instanceof ViewGroup) ((ViewGroup)w.getParent()).removeView(w); }catch(Exception ignored){}
                    try{ w.stopLoading(); }catch(Exception ignored){}
                    try{ w.destroy(); }catch(Exception ignored){}
                };
                final Runnable fail=()->{
                    if(finished[0])return;
                    finished[0]=true;
                    cleanup.run();
                    prescriptionPdfBusy=false; if(onFailure!=null)onFailure.run();
                };

                // Only the temporary renderer is attached. The application's main WebView
                // remains untouched, avoiding parent/layout corruption during Save/View PDF.
                try {
                    ViewGroup.LayoutParams lp=new ViewGroup.LayoutParams(794,1123);
                    contentRoot.addView(w,lp);
                    w.setAlpha(0.01f);

                WebSettings ws=w.getSettings();
                ws.setJavaScriptEnabled(true);
                ws.setDomStorageEnabled(true);
                ws.setAllowFileAccess(true);
                ws.setAllowContentAccess(true);
                ws.setLoadsImagesAutomatically(true);
                ws.setDefaultTextEncodingName("UTF-8");
                ws.setUseWideViewPort(false);
                ws.setLoadWithOverviewMode(false);
                ws.setSupportZoom(false);
                int densityScale = Math.max(1, Math.round(getResources().getDisplayMetrics().density * 100f));
                w.setInitialScale(Math.max(25, Math.min(100, Math.round(10000f / densityScale))));
                w.setBackgroundColor(Color.WHITE);
                // Do NOT force software rendering. WebView is a Chromium renderer and
                // forcing a software layer can trigger renderer/memory failures on some devices.

                w.setWebViewClient(new WebViewClient(){
                    private boolean pageReady=false;
                    private void renderWhenReady(WebView view){
                        if(finished[0]||pageReady)return;
                        pageReady=true;
                        view.postDelayed(()->{
                            if(finished[0])return;
                            try{
                                final int pdfWidth=595, pdfHeight=842;
                                final int cssWidth=794, cssHeight=1123;
                                view.measure(View.MeasureSpec.makeMeasureSpec(cssWidth,View.MeasureSpec.EXACTLY),
                                             View.MeasureSpec.makeMeasureSpec(cssHeight,View.MeasureSpec.EXACTLY));
                                view.layout(0,0,cssWidth,cssHeight);

                                android.graphics.pdf.PdfDocument pdf=new android.graphics.pdf.PdfDocument();
                                android.graphics.pdf.PdfDocument.PageInfo info=
                                        new android.graphics.pdf.PdfDocument.PageInfo.Builder(pdfWidth,pdfHeight,1).create();
                                android.graphics.pdf.PdfDocument.Page page=pdf.startPage(info);
                                android.graphics.Canvas canvas=page.getCanvas();
                                canvas.drawColor(Color.WHITE);
                                canvas.save();
                                canvas.scale((float)pdfWidth/cssWidth,(float)pdfHeight/cssHeight);
                                view.draw(canvas);
                                canvas.restore();
                                pdf.finishPage(page);
                                try(FileOutputStream fos=new FileOutputStream(out,false)){ pdf.writeTo(fos); }
                                pdf.close();

                                if(!out.exists()||out.length()<100){ throw new IOException("Generated PDF is empty"); }
                                finished[0]=true;
                                cleanup.run();
                                prescriptionPdfBusy=false;
                                if(onSuccess!=null)onSuccess.run();
                            }catch(Throwable e){
                                try{if(out.exists())out.delete();}catch(Exception ignored){}
                                fail.run();
                            }
                        },300);
                    }
                    @Override public void onPageFinished(WebView view,String url){
                        if(finished[0])return;
                        // Wait for document images and fonts rather than relying on a fixed
                        // 1.5 second delay. This is important for saved handwriting images.
                        view.evaluateJavascript("(async function(){try{if(document.fonts&&document.fonts.ready)await document.fonts.ready;var imgs=[...document.images];await Promise.all(imgs.map(function(i){return i.complete?Promise.resolve():new Promise(function(r){i.onload=i.onerror=r;});}));return 'READY';}catch(e){return 'READY';}})()",value->{
                            if(!finished[0])renderWhenReady(view);
                        });
                    }
                    @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){
                        // Never let a Chromium/WebView renderer failure close the whole clinic app.
                        fail.run();
                        return true;
                    }
                });

                String fragment=compactEmbeddedImages(html==null?"":html);
                String pdfHtml="<!doctype html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=794, initial-scale=1, maximum-scale=1, user-scalable=no\"><link rel=\"stylesheet\" href=\"styles.css\"><style>html,body{margin:0!important;padding:0!important;background:#fff!important;width:794px!important;height:1123px!important;} .rx-sheet{position:relative!important;margin:0!important;width:210mm!important;height:297mm!important;min-height:297mm!important;max-height:297mm!important;overflow:hidden!important;transform:none!important;transform-origin:top left!important;} table{border-collapse:collapse;} img{max-width:100%;}</style></head><body>"+fragment+"</body></html>";
                w.loadDataWithBaseURL("file:///android_asset/",pdfHtml,"text/html","UTF-8",null);
                } catch(Throwable setupError) {
                    try{ if(w.getParent() instanceof ViewGroup) ((ViewGroup)w.getParent()).removeView(w); }catch(Exception ignored){}
                    try{ w.destroy(); }catch(Exception ignored){}
                    prescriptionPdfBusy=false; if(onFailure!=null) onFailure.run();
                }
            });
        }

        private void notifyJsPdfResult(String path, boolean ok, String action){
            String p=JSONObject.quote(path==null?"":path);
            String a=JSONObject.quote(action==null?"":action);
            runOnUiThread(()->{
                try{ if(webView!=null) webView.evaluateJavascript("window.onPrescriptionPdfResult && window.onPrescriptionPdfResult("+p+","+ok+","+a+")",null); }catch(Exception ignored){}
            });
        }

        @JavascriptInterface public void savePrescriptionPdf(String html,String relativePath){
            final String path=relativePath==null?"prescriptions/prescription.pdf":relativePath;
            savePrescriptionPdfInternal(html,path,()->notifyJsPdfResult(path,true,"save"),()->{notifyJsPdfResult(path,false,"save");alert("Prescription PDF","Unable to save prescription PDF. Please try again.");});
        }

        @JavascriptInterface public void savePrescriptionPdfAndOpen(String html,String relativePath){
            final String path=relativePath==null?"prescriptions/prescription.pdf":relativePath;
            savePrescriptionPdfInternal(html,path,()->openPdf(path),()->alert("Prescription PDF","Unable to recreate the prescription PDF."));
        }

        @JavascriptInterface public void savePrescriptionPdfAndPrint(String html,String relativePath){
            final String path=relativePath==null?"prescriptions/prescription.pdf":relativePath;
            savePrescriptionPdfInternal(html,path,()->{printPdfFile(new File(getFilesDir(),path));notifyJsPdfResult(path,true,"print");},()->{notifyJsPdfResult(path,false,"print");alert("Prescription PDF","Unable to create the prescription PDF for printing.");});
        }

        @JavascriptInterface public boolean pdfExists(String relativePath){
            try{
                File f=new File(getFilesDir(),relativePath==null?"":relativePath);
                return f.exists() && f.length()>0;
            }catch(Exception e){ return false; }
        }

        private void printPdfFile(File file){
            try{
                if(file==null||!file.exists()||file.length()==0){alert("Print","Prescription PDF not found.");return;}
                PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                PrintDocumentAdapter adapter=new PrintDocumentAdapter(){
                    @Override public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){
                        if(cs.isCanceled()){cb.onLayoutCancelled();return;}
                        PrintDocumentInfo info=new PrintDocumentInfo.Builder(file.getName()).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();
                        cb.onLayoutFinished(info,true);
                    }
                    @Override public void onWrite(PageRange[] pages,ParcelFileDescriptor dest,CancellationSignal cs,WriteResultCallback cb){
                        try(FileInputStream in=new FileInputStream(file);FileOutputStream out=new FileOutputStream(dest.getFileDescriptor())){
                            byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0){if(cs.isCanceled()){cb.onWriteCancelled();return;}out.write(buf,0,n);}out.flush();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                        }catch(Exception e){cb.onWriteFailed(e.getMessage());}
                        finally{try{dest.close();}catch(Exception ignored){}}
                    }
                };
                pm.print("Siddiq Clinic Prescription",adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
            }catch(Exception e){alert("Print","Unable to start prescription printing: "+e.getMessage());}
        }

        @JavascriptInterface public void openPdf(String relativePath){
            try{
                File f=new File(getFilesDir(),relativePath==null?"":relativePath);
                if(!f.exists()){alert("Prescription PDF","PDF file not found.");return;}
                Uri u=FileProvider.getUriForFile(MainActivity.this,"com.siddiqclinic.android.fileprovider",f);
                Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(u,"application/pdf");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }catch(Exception e){alert("Prescription PDF","No PDF viewer is available on this device, or the PDF could not be opened: "+e);}
        }
        @JavascriptInterface public void backup(){runOnUiThread(()->{try{File out=BackupManager.createLocalBackup(MainActivity.this,true);shareFile(out,"application/zip","Siddiq Clinic backup");alert("Backup created","Backup saved locally:\n"+out.getName());}catch(Exception e){alert("Backup error",e.toString());}});}
        @JavascriptInterface public void createBackupNow(){new Thread(()->{try{File out=BackupManager.createLocalBackup(MainActivity.this,true);runOnUiThread(()->alert("Backup created","Backup saved locally:\n"+out.getName()));}catch(Exception e){runOnUiThread(()->alert("Backup error",e.toString()));}}).start();}
        @JavascriptInterface public String backupStatus(){return BackupManager.status(MainActivity.this).toString();}
        @JavascriptInterface public void saveBackupSettings(boolean localEnabled,int localHours,boolean cloudEnabled,int cloudHours,int localRetention,int cloudRetention){BackupManager.saveSettings(MainActivity.this,localEnabled,localHours,cloudEnabled,cloudHours,localRetention,cloudRetention);runOnUiThread(()->toast("Backup settings saved"));}
        @JavascriptInterface public void connectGoogleDrive(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,CONNECT_GOOGLE_DRIVE);}catch(Exception e){alert("Google Drive","Unable to open Google Drive folder picker: "+e);}}
        @JavascriptInterface public void disconnectGoogleDrive(){BackupManager.clearTreeUri(MainActivity.this);runOnUiThread(()->toast("Google Drive disconnected"));}
        @JavascriptInterface public void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,RESTORE_DB);}
        @JavascriptInterface public void exportCsv(String fileName,String csv){try{File f=new File(getExternalFilesDir(null),safe(fileName,"report.csv"));try(FileOutputStream o=new FileOutputStream(f)){o.write(csv.getBytes(StandardCharsets.UTF_8));}shareFile(f,"text/csv","Export report");}catch(Exception e){alert("Export error",e.toString());}}
        @JavascriptInterface public void exportXlsx(String fileName,String payload){try{JSONObject data=new JSONObject(payload);JSONArray headers=data.getJSONArray("headers"), rows=data.getJSONArray("rows");File f=new File(getExternalFilesDir(null),safe(fileName,"report.xlsx"));writeXlsx(f,headers,rows);shareFile(f,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Export Excel");}catch(Exception e){alert("Export error",e.toString());}}
        private String safe(String f,String def){if(f==null||f.trim().isEmpty())return def;return f.replaceAll("[^A-Za-z0-9._-]","_");}
        private String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
        private void shareFile(File f,String type,String chooser){Uri u=FileProvider.getUriForFile(MainActivity.this,"com.siddiqclinic.android.fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,chooser));}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_HOSPITAL_LOGO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                Uri u=data.getData();
                InputStream in=getContentResolver().openInputStream(u);
                Bitmap src=BitmapFactory.decodeStream(in);
                if(in!=null)in.close();
                if(src==null)throw new IOException("Selected file is not a valid image");
                int max=640;
                float scale=Math.min(1f,Math.min((float)max/src.getWidth(),(float)max/src.getHeight()));
                Bitmap bmp=scale<1f?Bitmap.createScaledBitmap(src,Math.max(1,Math.round(src.getWidth()*scale)),Math.max(1,Math.round(src.getHeight()*scale)),true):src;
                ByteArrayOutputStream bout=new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG,100,bout);
                String dataUrl="data:image/png;base64,"+Base64.encodeToString(bout.toByteArray(),Base64.NO_WRAP);
                if(bmp!=src)bmp.recycle();
                if(src!=bmp)src.recycle();
                String safeJs=JSONObject.quote(dataUrl);
                webView.post(()->webView.evaluateJavascript("window.receiveHospitalLogo("+safeJs+")",null));
            }catch(Exception e){new AlertDialog.Builder(this).setTitle("Hospital Logo").setMessage("Unable to load logo: "+e).setPositiveButton("OK",null).show();}
            return;
        }
        if(requestCode==CONNECT_GOOGLE_DRIVE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{BackupManager.setTreeUri(this,data.getData());new Thread(()->{try{BackupManager.syncLatestToDrive(this);runOnUiThread(()->Toast.makeText(MainActivity.this,"Google Drive connected and latest backup synced",Toast.LENGTH_SHORT).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Google Drive connected; first sync will retry automatically",Toast.LENGTH_SHORT).show());}}).start();new AlertDialog.Builder(this).setTitle("Google Drive connected").setMessage("The selected Google Drive location is authorized. Siddiq Clinic will create the hospital backup folder and date folders automatically.").setPositiveButton("OK",null).show();}catch(Exception e){new AlertDialog.Builder(this).setTitle("Google Drive").setMessage("Unable to save Google Drive access: "+e).setPositiveButton("OK",null).show();}
        }
        if(requestCode==RESTORE_DB&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            new Thread(()->{try{Uri u=data.getData();InputStream in=getContentResolver().openInputStream(u);if(in==null)throw new IOException("Unable to open selected backup");JSONObject result;try{result=BackupManager.restoreZip(this,in);}finally{try{in.close();}catch(Exception ignored){}}final JSONObject rr=result;runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Restore complete").setMessage("Backup version: v"+rr.optInt("backupVersion")+"\nCurrent version: v"+rr.optInt("currentVersion")+(rr.optBoolean("migrated")?"\n\nOlder backup detected. Database migration/schema upgrade will run when the application reloads.":"\n\nBackup version matches the application.")+"\n\nA safety backup was created before restore.").setPositiveButton("RELOAD",(x,w)->webView.reload()).show());}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Restore error").setMessage(e.toString()).setPositiveButton("OK",null).show());}}).start();
        }
    }

    private static void copyFile(File a,File b)throws IOException{try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){byte[]z=new byte[8192];int n;while((n=in.read(z))>0)out.write(z,0,n);}}

    private static String esc(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private void writeEntry(ZipOutputStream z,String path,String body)throws IOException{z.putNextEntry(new ZipEntry(path));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private void writeXlsx(File file,JSONArray headers,JSONArray rows)throws Exception{
        StringBuilder sheet=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        int r=1; sheet.append("<row r=\"1\">"); for(int c=0;c<headers.length();c++)sheet.append(cell(c+1,r,headers.optString(c))); sheet.append("</row>");
        for(int i=0;i<rows.length();i++){r++;JSONArray row=rows.getJSONArray(i);sheet.append("<row r=\""+r+"\">");for(int c=0;c<row.length();c++)sheet.append(cell(c+1,r,row.optString(c,"")));sheet.append("</row>");}
        sheet.append("</sheetData></worksheet>");
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(file))){
            writeEntry(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
            writeEntry(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            writeEntry(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Report\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            writeEntry(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
            writeEntry(z,"xl/worksheets/sheet1.xml",sheet.toString());
        }
    }
    private String cell(int col,int row,String val){StringBuilder ref=new StringBuilder();int n=col;while(n>0){int rem=(n-1)%26;ref.insert(0,(char)('A'+rem));n=(n-1)/26;}ref.append(row);return "<c r=\""+ref+"\" t=\"inlineStr\"><is><t>"+esc(val)+"</t></is></c>";}
}
