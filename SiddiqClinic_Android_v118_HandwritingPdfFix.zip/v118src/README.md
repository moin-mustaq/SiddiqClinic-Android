

## v118 fix
Handwriting PDF rendering fix: transparent handwriting images are composited onto a white bitmap before JPEG conversion, preventing black rectangles in PDF view/print.
