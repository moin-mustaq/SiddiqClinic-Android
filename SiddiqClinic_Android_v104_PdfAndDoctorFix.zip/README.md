# SiddiqClinic Android v104

Fixes:
- Prescription history/View Patient Prescription PDF recreation now loads the application stylesheet and waits for WebView rendering before generating the PDF.
- More robust PDF WebView rendering and image loading.
- Patient Registration doctor dropdown explicitly defaults to the first doctor by Doctor ID ascending.
- Doctor ordering ignores blank names and uses numeric Doctor ID first.
