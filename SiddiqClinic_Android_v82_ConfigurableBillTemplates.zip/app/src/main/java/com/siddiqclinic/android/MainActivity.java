package com.siddiqclinic.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.print.PrintManager;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.net.Uri;
import android.os.*;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private File dbFile;
    private static final int RESTORE_DB = 4101;
    private static final int PICK_HOSPITAL_LOGO = 4102;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(18,59,109));
        getWindow().setNavigationBarColor(Color.rgb(18,59,109));
        dbFile = new File(getFilesDir(), "SiddiqClinic.db");
        if (!dbFile.exists()) copyAsset("database/TEST.db", dbFile);
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setTextZoom(100);
        webView.setBackgroundColor(Color.rgb(244,246,249));
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void copyAsset(String name, File dest) {
        try (InputStream in = getAssets().open(name); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
        } catch(Exception e){ throw new RuntimeException(e); }
    }

    private SQLiteDatabase openDb() { return SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.OPEN_READWRITE); }
    private String jsonRows(Cursor c) throws Exception {
        JSONArray a=new JSONArray(); String[] cols=c.getColumnNames();
        while(c.moveToNext()){ JSONObject o=new JSONObject(); for(int i=0;i<cols.length;i++){ int t=c.getType(i); Object v; switch(t){case Cursor.FIELD_TYPE_NULL:v=JSONObject.NULL;break;case Cursor.FIELD_TYPE_INTEGER:v=c.getLong(i);break;case Cursor.FIELD_TYPE_FLOAT:v=c.getDouble(i);break;default:v=c.getString(i);} o.put(cols[i],v);} a.put(o); }
        c.close(); return a.toString();
    }
    private Object bind(JSONArray p,int i) throws Exception { Object v=p.opt(i); if(v==JSONObject.NULL) return null; return v; }

    public class Bridge {
        @JavascriptInterface public String sha256(String s){ try{byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)); StringBuilder h=new StringBuilder(); for(byte x:d) h.append(String.format("%02x",x)); return h.toString();}catch(Exception e){return "";} }
        @JavascriptInterface public String query(String sql, String paramsJson){ SQLiteDatabase d=null; Cursor c=null; try{d=openDb(); JSONArray p=new JSONArray(paramsJson==null?"[]":paramsJson); String[] args=new String[p.length()]; for(int i=0;i<p.length();i++){ Object v=bind(p,i); args[i]=v==null?null:String.valueOf(v); } c=d.rawQuery(sql,args); return jsonRows(c);}catch(Exception e){return error(e);}finally{if(c!=null&&!c.isClosed())c.close();if(d!=null)d.close();} }
        @JavascriptInterface public String execute(String sql, String paramsJson){SQLiteDatabase d=null; try{d=openDb(); JSONArray p=new JSONArray(paramsJson==null?"[]":paramsJson); Object[] args=new Object[p.length()]; for(int i=0;i<p.length();i++) args[i]=bind(p,i); d.execSQL(sql,args); long id=-1; try{Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);if(c.moveToFirst())id=c.getLong(0);c.close();}catch(Exception ignored){} JSONObject o=new JSONObject();o.put("ok",true);o.put("lastInsertRowId",id);return o.toString();}catch(Exception e){return error(e);}finally{if(d!=null)d.close();}}
        @JavascriptInterface public String executeBatch(String batchJson){SQLiteDatabase d=null; try{d=openDb(); JSONArray b=new JSONArray(batchJson); d.beginTransaction(); long id=-1; for(int i=0;i<b.length();i++){JSONObject x=b.getJSONObject(i);JSONArray p=x.optJSONArray("params");Object[] args=new Object[p==null?0:p.length()];for(int j=0;j<args.length;j++)args[j]=bind(p,j);d.execSQL(x.getString("sql"),args);Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);if(c.moveToFirst())id=c.getLong(0);c.close();}d.setTransactionSuccessful();d.endTransaction();JSONObject o=new JSONObject();o.put("ok",true);o.put("lastInsertRowId",id);return o.toString();}catch(Exception e){if(d!=null&&d.inTransaction())d.endTransaction();return error(e);}finally{if(d!=null)d.close();}}
        private String error(Exception e){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",e.toString());return o.toString();}catch(Exception x){return "{\"ok\":false}";}}

        @JavascriptInterface public void toast(String msg){runOnUiThread(()->Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show());}
        @JavascriptInterface public void alert(String title,String msg){runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show());}
        @JavascriptInterface public void shareText(String subject,String text){Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_SUBJECT,subject);s.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(s,"Share"));}
        @JavascriptInterface public void whatsapp(String phone,String text){try{String p=phone==null?"":phone.replaceAll("[^0-9]","");String url="https://wa.me/"+(p.startsWith("91")?p:"91"+p)+"?text="+Uri.encode(text);startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("WhatsApp is not available");}}
        @JavascriptInterface public void chooseHospitalLogo(){
            try{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i,PICK_HOSPITAL_LOGO);
            }catch(Exception e){ alert("Hospital Logo","Unable to open image picker: "+e); }
        }
        @JavascriptInterface public void printPage(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);PrintDocumentAdapter ad=webView.createPrintDocumentAdapter("Siddiq Clinic");pm.print("Siddiq Clinic",ad,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());});}
        @JavascriptInterface public void backup(){try{File out=new File(getExternalFilesDir(null),"SIDDIQ_CLINIC_BACKUP_"+stamp()+".db");copyFile(dbFile,out);shareFile(out,"application/octet-stream","Backup database");}catch(Exception e){alert("Backup error",e.toString());}}
        @JavascriptInterface public void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");startActivityForResult(i,RESTORE_DB);}
        @JavascriptInterface public void exportCsv(String fileName,String csv){try{File f=new File(getExternalFilesDir(null),safe(fileName,"report.csv"));try(FileOutputStream o=new FileOutputStream(f)){o.write(csv.getBytes(StandardCharsets.UTF_8));}shareFile(f,"text/csv","Export report");}catch(Exception e){alert("Export error",e.toString());}}
        @JavascriptInterface public void exportXlsx(String fileName,String payload){try{JSONObject data=new JSONObject(payload);JSONArray headers=data.getJSONArray("headers"), rows=data.getJSONArray("rows");File f=new File(getExternalFilesDir(null),safe(fileName,"report.xlsx"));writeXlsx(f,headers,rows);shareFile(f,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Export Excel");}catch(Exception e){alert("Export error",e.toString());}}
        private String safe(String f,String def){if(f==null||f.trim().isEmpty())return def;return f.replaceAll("[^A-Za-z0-9._-]","_");}
        private String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
        private void shareFile(File f,String type,String chooser){Uri u=FileProvider.getUriForFile(MainActivity.this,"com.siddiqclinic.android.fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,chooser));}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_HOSPITAL_LOGO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                Uri u=data.getData();
                InputStream in=getContentResolver().openInputStream(u);
                Bitmap src=BitmapFactory.decodeStream(in);
                if(in!=null)in.close();
                if(src==null)throw new IOException("Selected file is not a valid image");
                int max=640;
                float scale=Math.min(1f,Math.min((float)max/src.getWidth(),(float)max/src.getHeight()));
                Bitmap bmp=scale<1f?Bitmap.createScaledBitmap(src,Math.max(1,Math.round(src.getWidth()*scale)),Math.max(1,Math.round(src.getHeight()*scale)),true):src;
                ByteArrayOutputStream bout=new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG,100,bout);
                String dataUrl="data:image/png;base64,"+Base64.encodeToString(bout.toByteArray(),Base64.NO_WRAP);
                if(bmp!=src)bmp.recycle();
                if(src!=bmp)src.recycle();
                String safeJs=JSONObject.quote(dataUrl);
                webView.post(()->webView.evaluateJavascript("window.receiveHospitalLogo("+safeJs+")",null));
            }catch(Exception e){alert("Hospital Logo","Unable to load logo: "+e);}
            return;
        }
        if(requestCode==RESTORE_DB&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{Uri u=data.getData();InputStream in=getContentResolver().openInputStream(u);File tmp=new File(getFilesDir(),"restore.tmp");try(OutputStream out=new FileOutputStream(tmp)){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}if(in!=null)in.close();SQLiteDatabase d;try{d=openDb();d.close();}catch(Exception ignored){}if(tmp.length()<10000)throw new IOException("Selected file is not a valid Siddiq Clinic database");if(!tmp.renameTo(dbFile)){copyFile(tmp,dbFile);tmp.delete();}new AlertDialog.Builder(this).setTitle("Restore complete").setMessage("Database restored. Reloading the application.").setPositiveButton("OK",(x,w)->webView.reload()).show();}catch(Exception e){new AlertDialog.Builder(this).setTitle("Restore error").setMessage(e.toString()).setPositiveButton("OK",null).show();}
        }
    }

    private static void copyFile(File a,File b)throws IOException{try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){byte[]z=new byte[8192];int n;while((n=in.read(z))>0)out.write(z,0,n);}}

    private static String esc(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private void writeEntry(ZipOutputStream z,String path,String body)throws IOException{z.putNextEntry(new ZipEntry(path));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private void writeXlsx(File file,JSONArray headers,JSONArray rows)throws Exception{
        StringBuilder sheet=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        int r=1; sheet.append("<row r=\"1\">"); for(int c=0;c<headers.length();c++)sheet.append(cell(c+1,r,headers.optString(c))); sheet.append("</row>");
        for(int i=0;i<rows.length();i++){r++;JSONArray row=rows.getJSONArray(i);sheet.append("<row r=\""+r+"\">");for(int c=0;c<row.length();c++)sheet.append(cell(c+1,r,row.optString(c,"")));sheet.append("</row>");}
        sheet.append("</sheetData></worksheet>");
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(file))){
            writeEntry(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
            writeEntry(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            writeEntry(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Report\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            writeEntry(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
            writeEntry(z,"xl/worksheets/sheet1.xml",sheet.toString());
        }
    }
    private String cell(int col,int row,String val){StringBuilder ref=new StringBuilder();int n=col;while(n>0){int rem=(n-1)%26;ref.insert(0,(char)('A'+rem));n=(n-1)/26;}ref.append(row);return "<c r=\""+ref+"\" t=\"inlineStr\"><is><t>"+esc(val)+"</t></is></c>";}
}
