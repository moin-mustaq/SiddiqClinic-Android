SiddiqClinic Android v103

Changes:
1. Fixed prescription PDF recreation/open flow for Patient Consultation History and View Patient Prescription.
2. PDF recreation now validates rendered content before saving and allows a longer native generation/open window.
3. Increased WebView render wait before PDF generation for more reliable A4 PDF creation.
4. View Patient Prescription remains visible to all roles.
5. Patient Registration doctor dropdown/default now uses the first doctor by numeric Doctor ID (c_id) ascending, instead of alphabetical doctor name.
6. The same doctor ordering is used wherever the shared doctor list is used.
