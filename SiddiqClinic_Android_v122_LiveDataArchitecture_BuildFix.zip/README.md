# Siddiq Clinic Android v122

v122 changes the selected local folder into the persistent live-data mirror and backup location.

Selected folder creates:
- `<HospitalNameWithoutSpaces>_appdata/` — live database mirror, prescriptions, bills/templates/hospital folders, and app_state.json.
- `<HospitalNameWithoutSpaces>_backup/YYYYMMDD/` — full backup ZIP snapshots.

The app keeps a small SQLite working copy internally because Android's Storage Access Framework DocumentFile URI cannot be opened directly by SQLiteDatabase. Every successful database write/batch is checkpointed and mirrored to the selected external folder. Prescription PDFs are mirrored after successful PDF creation. On startup, if the internal database is missing, the app attempts recovery from the persisted selected folder permission and live database mirror.

If Android Clear Data also removes the persisted folder permission on a device, Android will require the user to re-select the same parent folder; the external files themselves are not deleted by the app.
