package com.siddiqclinic.android;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class BackupManager {
    public static final int APP_VERSION = 122;
    public static final int BACKUP_FORMAT_VERSION = 1;
    private static final String PREF = "backup_settings";
    private static final String KEY_LOCAL_ENABLED="local_enabled";
    private static final String KEY_CLOUD_ENABLED="cloud_enabled";
    private static final String KEY_LOCAL_HOURS="local_hours";
    private static final String KEY_CLOUD_HOURS="cloud_hours";
    private static final String KEY_LOCAL_RETENTION="local_retention";
    private static final String KEY_CLOUD_RETENTION="cloud_retention";
    private static final String KEY_TREE_URI="cloud_tree_uri";
    private static final String KEY_LOCAL_TREE_URI="local_tree_uri";
    private static final String KEY_LAST_LOCAL="last_local_ms";
    private static final String KEY_LAST_CLOUD="last_cloud_ms";
    private static final String KEY_LIVE_ROOT_NAME="live_root_name";

    private BackupManager() {}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}

    public static String hospitalName(Context c){
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READONLY)){
            Cursor cur=d.rawQuery("SELECT hospital_name FROM hospital_profile WHERE profile_id=1 LIMIT 1",null);
            String s="SIDDIQ HOSPITAL"; if(cur.moveToFirst()) s=cur.getString(0); cur.close();
            return s==null||s.trim().isEmpty()?"SIDDIQ HOSPITAL":s.trim();
        }catch(Exception e){return "SIDDIQ HOSPITAL";}
    }
    public static String safeHospital(String s){
        s=s==null?"":s.replaceAll("\\s+","").replaceAll("[^A-Za-z0-9._&-]","");
        return s.isEmpty()?"Hospital":""+s;
    }
    private static int databaseVersion(File db)throws Exception{try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READONLY)){Cursor c=d.rawQuery("PRAGMA user_version",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}}
    public static String today(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    public static String fileName(Context c){return fileName(c,false);}
    public static String fileName(Context c,boolean manual){String base=safeHospital(hospitalName(c))+"_v"+APP_VERSION+"_"+today();return base+(manual?"_"+new SimpleDateFormat("HHmmss",Locale.US).format(new Date()):"")+".zip";}
    public static File backupDir(Context c){File d=new File(c.getExternalFilesDir(null),"Backups");if(!d.exists())d.mkdirs();return d;}

    public static JSONObject status(Context c){
        JSONObject o=new JSONObject(); try{
            SharedPreferences p=prefs(c);o.put("localEnabled",p.getBoolean(KEY_LOCAL_ENABLED,true));o.put("cloudEnabled",p.getBoolean(KEY_CLOUD_ENABLED,false));
            o.put("localHours",p.getInt(KEY_LOCAL_HOURS,1));o.put("cloudHours",p.getInt(KEY_CLOUD_HOURS,6));o.put("localRetention",p.getInt(KEY_LOCAL_RETENTION,30));o.put("cloudRetention",p.getInt(KEY_CLOUD_RETENTION,30));
            o.put("cloudConnected",p.getString(KEY_TREE_URI,"").length()>0);o.put("localFolderSet",p.getString(KEY_LOCAL_TREE_URI,"").length()>0);o.put("localFolderUri",p.getString(KEY_LOCAL_TREE_URI,""));o.put("hospitalName",hospitalName(c));o.put("safeHospitalName",safeHospital(hospitalName(c)));o.put("todayFile",fileName(c));
            File f=new File(backupDir(c),fileName(c));o.put("localFileExists",f.exists());o.put("localFileSize",f.exists()?f.length():0);o.put("lastLocalMs",p.getLong(KEY_LAST_LOCAL,0));o.put("lastCloudMs",p.getLong(KEY_LAST_CLOUD,0));
        }catch(Exception ignored){} return o;
    }

    public static void saveSettings(Context c, boolean le,int lh,boolean ce,int ch,int lr,int cr){
        lh=Math.max(1,Math.min(168,lh));ch=Math.max(1,Math.min(168,ch));lr=Math.max(1,Math.min(365,lr));cr=Math.max(1,Math.min(365,cr));
        prefs(c).edit().putBoolean(KEY_LOCAL_ENABLED,le).putInt(KEY_LOCAL_HOURS,lh).putBoolean(KEY_CLOUD_ENABLED,ce).putInt(KEY_CLOUD_HOURS,ch).putInt(KEY_LOCAL_RETENTION,lr).putInt(KEY_CLOUD_RETENTION,cr).apply();
        BackupWorker.schedule(c);
    }
    public static void setTreeUri(Context c,Uri uri){
        if(uri==null)return;int flags=Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        try{c.getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
        prefs(c).edit().putString(KEY_TREE_URI,uri.toString()).apply();BackupWorker.schedule(c);
    }
    public static void clearTreeUri(Context c){prefs(c).edit().remove(KEY_TREE_URI).apply();BackupWorker.schedule(c);}
    public static Uri treeUri(Context c){String s=prefs(c).getString(KEY_TREE_URI,"");return s.isEmpty()?null:Uri.parse(s);}
    public static void setLocalTreeUri(Context c,Uri uri){if(uri==null)return;int flags=Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION;try{c.getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}prefs(c).edit().putString(KEY_LOCAL_TREE_URI,uri.toString()).apply();try{ensureLiveDataFolders(c);mirrorLiveData(c);}catch(Exception ignored){}BackupWorker.schedule(c);}
    public static void clearLocalTreeUri(Context c){prefs(c).edit().remove(KEY_LOCAL_TREE_URI).remove(KEY_LIVE_ROOT_NAME).apply();BackupWorker.schedule(c);}
    public static Uri localTreeUri(Context c){String s=prefs(c).getString(KEY_LOCAL_TREE_URI,"");if(!s.isEmpty())return Uri.parse(s);return discoverPersistedLocalTree(c);}
    private static Uri discoverPersistedLocalTree(Context c){try{for(android.content.UriPermission p:c.getContentResolver().getPersistedUriPermissions()){Uri u=p.getUri();DocumentFile d=DocumentFile.fromTreeUri(c,u);if(d==null||!d.canRead())continue;String root=safeHospital(hospitalName(c))+"_appdata";DocumentFile f=d.findFile(root);if(f!=null&&f.isDirectory()){prefs(c).edit().putString(KEY_LOCAL_TREE_URI,u.toString()).putString(KEY_LIVE_ROOT_NAME,root).apply();return u;}}}catch(Exception ignored){}return null;}

    public static DocumentFile ensureLiveDataFolders(Context c)throws IOException{Uri tree=localTreeUri(c);if(tree==null)throw new IOException("Live data folder is not configured");DocumentFile parent=DocumentFile.fromTreeUri(c,tree);if(parent==null||!parent.canWrite())throw new IOException("Selected live data folder is not writable");String rootName=safeHospital(hospitalName(c))+"_appdata";DocumentFile root=findOrCreateDir(parent,rootName);findOrCreateDir(root,"database");findOrCreateDir(root,"prescriptions");findOrCreateDir(root,"bills");findOrCreateDir(root,"templates");findOrCreateDir(root,"hospital");prefs(c).edit().putString(KEY_LIVE_ROOT_NAME,rootName).apply();return root;}

    /** Mirror the current live SQLite database to the selected external folder. The app keeps a local working copy because SQLite cannot open a SAF DocumentFile URI directly; the external mirror is the persistent recovery source. */
    public static void mirrorLiveData(Context c)throws IOException{Uri tree=localTreeUri(c);if(tree==null)return;DocumentFile root=ensureLiveDataFolders(c);DocumentFile dbdir=root.findFile("database");if(dbdir==null)dbdir=findOrCreateDir(root,"database");File db=new File(c.getFilesDir(),"SiddiqClinic.db");if(!db.exists())return;try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){try(Cursor x=d.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null)){ }catch(Exception ignored){}}DocumentFile old=dbdir.findFile("SiddiqClinic.db");if(old!=null)old.delete();DocumentFile tmp=dbdir.createFile("application/octet-stream","SiddiqClinic.db.tmp");if(tmp==null)throw new IOException("Unable to create live database mirror");try(InputStream in=new BufferedInputStream(new FileInputStream(db));OutputStream out=c.getContentResolver().openOutputStream(tmp.getUri(),"w")){if(out==null)throw new IOException("Unable to open live database mirror");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}DocumentFile finalDb=dbdir.createFile("application/octet-stream","SiddiqClinic.db");if(finalDb==null)throw new IOException("Unable to finalize live database mirror");try(InputStream in=c.getContentResolver().openInputStream(tmp.getUri());OutputStream out=c.getContentResolver().openOutputStream(finalDb.getUri(),"w")){if(in==null||out==null)throw new IOException("Unable to finalize live database mirror");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}tmp.delete();DocumentFile manifest=root.findFile("app_state.json");if(manifest!=null)manifest.delete();manifest=root.createFile("application/json","app_state.json");if(manifest!=null){try{JSONObject m=new JSONObject();m.put("application_version",APP_VERSION);m.put("hospital_name",hospitalName(c));m.put("updated_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));try(OutputStream out=c.getContentResolver().openOutputStream(manifest.getUri(),"w")){if(out!=null)out.write(m.toString(2).getBytes(StandardCharsets.UTF_8));}}catch(org.json.JSONException e){throw new IOException("Unable to create live data manifest",e);}}}

    public static boolean recoverLiveDataIfNeeded(Context c,File target)throws IOException{if(target.exists()&&target.length()>10000)return false;Uri tree=localTreeUri(c);if(tree==null)return false;DocumentFile root=ensureLiveDataFolders(c);DocumentFile dbdir=root.findFile("database");DocumentFile src=dbdir==null?null:dbdir.findFile("SiddiqClinic.db");if(src==null||!src.isFile())return false;File tmp=new File(c.getCacheDir(),"live_recover_"+System.currentTimeMillis()+".db");try(InputStream in=c.getContentResolver().openInputStream(src.getUri());OutputStream out=new FileOutputStream(tmp)){if(in==null)throw new IOException("Unable to read live database mirror");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}try(SQLiteDatabase d=SQLiteDatabase.openDatabase(tmp.getPath(),null,SQLiteDatabase.OPEN_READONLY)){try(Cursor x=d.rawQuery("SELECT name FROM sqlite_master LIMIT 1",null)){} }catch(Exception e){tmp.delete();throw new IOException("Live database mirror is invalid",e);}if(target.exists())target.delete();copy(tmp,target);tmp.delete();DocumentFile pdir=root.findFile("prescriptions");if(pdir!=null&&pdir.isDirectory()){File localPres=new File(c.getFilesDir(),"prescriptions");if(localPres.exists())deleteTree(localPres);localPres.mkdirs();for(DocumentFile pf:pdir.listFiles()){if(pf.isFile()&&pf.getName()!=null){File dst=new File(localPres,pf.getName());try(InputStream in=c.getContentResolver().openInputStream(pf.getUri());OutputStream out=new FileOutputStream(dst)){if(in==null)continue;byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}}}}return true;}

    public static void mirrorPrescriptionFile(Context c,File source,String relativeName)throws IOException{Uri tree=localTreeUri(c);if(tree==null||source==null||!source.exists())return;DocumentFile root=ensureLiveDataFolders(c);DocumentFile dir=root.findFile("prescriptions");if(dir==null)dir=findOrCreateDir(root,"prescriptions");String name=new File(relativeName).getName();DocumentFile old=dir.findFile(name);if(old!=null)old.delete();DocumentFile dest=dir.createFile("application/pdf",name);if(dest==null)throw new IOException("Unable to create live prescription mirror");try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=c.getContentResolver().openOutputStream(dest.getUri(),"w")){if(out==null)throw new IOException("Unable to write live prescription mirror");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}}

    public static File createLocalBackup(Context c)throws Exception{return createLocalBackup(c,false);}
    public static File createLocalBackup(Context c,boolean manual)throws Exception{
        File dir=backupDir(c);if(!dir.exists()&&!dir.mkdirs())throw new IOException("Unable to create local backup folder");
        File out=new File(dir,fileName(c,manual));File tmp=new File(dir,out.getName()+".tmp");if(tmp.exists())tmp.delete();
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");
        // Flush SQLite WAL before taking the snapshot.
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){try{d.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null).close();}catch(Exception ignored){}}
        JSONObject info=new JSONObject();info.put("backup_format_version",BACKUP_FORMAT_VERSION);info.put("application_name","Siddiq Clinic");info.put("application_version",APP_VERSION);info.put("database_version",databaseVersion(db));info.put("hospital_name",hospitalName(c));info.put("backup_date",today());info.put("created_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));
        try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))){
            putText(z,"backup_info.json",info.toString(2));
            addFile(z,db,"database/SiddiqClinic.db");
            File pres=new File(c.getFilesDir(),"prescriptions");if(pres.exists())addDir(z,pres,"prescriptions");
        }
        if(out.exists()&&!out.delete())throw new IOException("Unable to replace previous daily backup");if(!tmp.renameTo(out)){copy(tmp,out);tmp.delete();}
        prefs(c).edit().putLong(KEY_LAST_LOCAL,System.currentTimeMillis()).apply();
        copyBackupToSelectedLocalFolder(c,out,manual);
        pruneLocal(c);
        pruneSelectedLocal(c);
        return out;
    }
    private static void copyBackupToSelectedLocalFolder(Context c,File source,boolean manual)throws IOException{Uri tree=localTreeUri(c);if(tree==null)return;DocumentFile parent=DocumentFile.fromTreeUri(c,tree);if(parent==null||!parent.canWrite())throw new IOException("Selected live data folder is not writable");String rootName=safeHospital(hospitalName(c))+"_backup";DocumentFile root=findOrCreateDir(parent,rootName);String dayName=backupDateFromZip(source);DocumentFile day=findOrCreateDir(root,dayName);String name=source.getName();DocumentFile old=day.findFile(name);if(old!=null)old.delete();DocumentFile dest=day.createFile("application/zip",name);if(dest==null)throw new IOException("Unable to create backup file in selected folder");try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=c.getContentResolver().openOutputStream(dest.getUri(),"w")){if(out==null)throw new IOException("Unable to open selected backup folder");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}}
    private static void putText(ZipOutputStream z,String name,String s)throws IOException{ZipEntry e=new ZipEntry(name);z.putNextEntry(e);z.write(s.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private static void addIfExists(ZipOutputStream z,File f,String path)throws IOException{if(f.exists())addFile(z,f,path);}
    private static void addDir(ZipOutputStream z,File dir,String base)throws IOException{File[] fs=dir.listFiles();if(fs==null)return;for(File f:fs){String p=base+"/"+f.getName();if(f.isDirectory())addDir(z,f,p);else addFile(z,f,p);}}
    private static void addFile(ZipOutputStream z,File f,String path)throws IOException{ZipEntry e=new ZipEntry(path);z.putNextEntry(e);try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)z.write(b,0,n);}z.closeEntry();}
    private static void copy(File a,File b)throws IOException{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[]x=new byte[16384];int n;while((n=i.read(x))>0)o.write(x,0,n);}}

    public static void syncLatestToDrive(Context c)throws Exception{
        Uri tree=treeUri(c);if(tree==null)throw new IOException("Google Drive is not connected");
        File local=new File(backupDir(c),fileName(c,false));
        if(!local.exists()||local.length()<1000) local=createLocalBackup(c,false);
        uploadBackupToDrive(c,local);
    }

    /** Uploads the newest successful local backup without creating a new backup.
     *  Used by the manual CLOUD BACKUP NOW button so the cloud receives exactly
     *  the last local snapshot the user has already created.
     */
    public static void syncLastLocalBackupToDrive(Context c)throws Exception{
        Uri tree=treeUri(c);if(tree==null)throw new IOException("Google Drive is not connected");
        File local=findLatestLocalBackup(c);
        if(local==null||local.length()<1000)throw new IOException("No successful local backup is available yet. Create a local backup first.");
        uploadBackupToDrive(c,local);
    }

    private static File findLatestLocalBackup(Context c)throws IOException{
        File[] fs=backupDir(c).listFiles((d,n)->n!=null&&n.toLowerCase(Locale.US).endsWith(".zip"));
        if(fs==null||fs.length==0)return null;
        Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        return fs[0];
    }

    private static void uploadBackupToDrive(Context c,File local)throws Exception{
        if(local==null||!local.exists()||local.length()<1000)throw new IOException("Local backup is missing or invalid");
        DocumentFile parent=DocumentFile.fromTreeUri(c,treeUri(c));
        if(parent==null||!parent.canWrite())throw new IOException("Google Drive location is not writable");
        String rootName=safeHospital(hospitalName(c))+"_backup";
        DocumentFile root=findOrCreateDir(parent,rootName);
        String dayName=backupDateFromZip(local);
        DocumentFile day=findOrCreateDir(root,dayName);
        DocumentFile old=day.findFile(local.getName());if(old!=null)old.delete();
        DocumentFile dest=day.createFile("application/zip",local.getName());
        if(dest==null)throw new IOException("Unable to create backup file in Google Drive");
        try(InputStream in=new BufferedInputStream(new FileInputStream(local));OutputStream out=c.getContentResolver().openOutputStream(dest.getUri(),"w")){
            if(out==null)throw new IOException("Unable to open Google Drive file");
            byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();
        }
        prefs(c).edit().putLong(KEY_LAST_CLOUD,System.currentTimeMillis()).apply();
        pruneCloud(c,parent,root);
    }

    private static String backupDateFromZip(File zip)throws IOException{
        try(ZipFile z=new ZipFile(zip)){
            ZipEntry e=z.getEntry("backup_info.json");
            if(e!=null){
                try(InputStream in=z.getInputStream(e)){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[4096];int n;while((n=in.read(x))>0)b.write(x,0,n);
                    try{String d=new JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8)).optString("backup_date","");if(d.matches("\\d{8}"))return d;}catch(Exception ignored){}
                }
            }
        }catch(Exception ignored){}
        String n=zip.getName();Matcher m=Pattern.compile("_(\\d{8})(?:_\\d{6})?\\.zip$",Pattern.CASE_INSENSITIVE).matcher(n);
        return m.find()?m.group(1):today();
    }
    private static DocumentFile findOrCreateDir(DocumentFile parent,String name)throws IOException{DocumentFile f=parent.findFile(name);if(f!=null&&f.isDirectory())return f;if(f!=null)f.delete();f=parent.createDirectory(name);if(f==null)throw new IOException("Unable to create Google Drive folder: "+name);return f;}
    private static void pruneLocal(Context c){int keep=prefs(c).getInt(KEY_LOCAL_RETENTION,30);File[] fs=backupDir(c).listFiles((d,n)->n.endsWith(".zip"));if(fs==null||fs.length<=keep)return;Arrays.sort(fs,Comparator.comparingLong(File::lastModified));for(int i=0;i<fs.length-keep;i++)fs[i].delete();}
    private static void pruneSelectedLocal(Context c){Uri tree=localTreeUri(c);if(tree==null)return;try{DocumentFile parent=DocumentFile.fromTreeUri(c,tree);if(parent==null||!parent.canRead())return;int keep=prefs(c).getInt(KEY_LOCAL_RETENTION,30);DocumentFile[] fs=parent.listFiles();List<DocumentFile> zips=new ArrayList<>();for(DocumentFile f:fs){String n=f.getName();if(f.isFile()&&n!=null&&n.toLowerCase(Locale.US).endsWith(".zip"))zips.add(f);}if(zips.size()<=keep)return;zips.sort(Comparator.comparingLong(f->{try{return f.lastModified();}catch(Exception e){return 0L;}}));for(int i=0;i<zips.size()-keep;i++)zips.get(i).delete();}catch(Exception ignored){}}
    private static void pruneCloud(Context c,DocumentFile parent,DocumentFile root){int keep=prefs(c).getInt(KEY_CLOUD_RETENTION,30);DocumentFile[] fs=root.listFiles();List<DocumentFile> days=new ArrayList<>();for(DocumentFile f:fs)if(f.isDirectory()&&f.getName()!=null&&f.getName().matches("\\d{8}"))days.add(f);if(days.size()<=keep)return;days.sort(Comparator.comparing(DocumentFile::getName));for(int i=0;i<days.size()-keep;i++)days.get(i).delete();}

    public static JSONObject restoreZip(Context c,InputStream input)throws Exception{
        File tmp=new File(c.getCacheDir(),"restore_"+System.currentTimeMillis()+".zip");try(OutputStream o=new FileOutputStream(tmp)){byte[]b=new byte[32768];int n;while((n=input.read(b))>0)o.write(b,0,n);}return restoreZipFile(c,tmp);
    }
    public static JSONObject restoreZipFile(Context c,File zip)throws Exception{
        JSONObject info=null;File stage=new File(c.getCacheDir(),"restore_stage_"+System.currentTimeMillis());if(!stage.mkdirs())throw new IOException("Unable to create restore staging folder");
        try(ZipFile z=new ZipFile(zip)){ZipEntry ie=z.getEntry("backup_info.json");if(ie==null)throw new IOException("Invalid backup: backup_info.json is missing");try(InputStream in=z.getInputStream(ie)){ByteArrayOutputStream bout=new ByteArrayOutputStream();byte[] bb=new byte[8192];int nn;while((nn=in.read(bb))>0)bout.write(bb,0,nn);info=new JSONObject(new String(bout.toByteArray(),StandardCharsets.UTF_8));}int fmt=info.optInt("backup_format_version",0);if(fmt!=BACKUP_FORMAT_VERSION)throw new IOException("Unsupported backup format version: "+fmt);ZipEntry db=z.getEntry("database/SiddiqClinic.db");if(db==null)throw new IOException("Backup database is missing");extract(z,"database/",new File(stage,"database"));extract(z,"prescriptions/",new File(stage,"prescriptions"));}
        int backupVersion=info.optInt("application_version",0);int backupDbVersion=info.optInt("database_version",0);if(backupVersion<=0)throw new IOException("Backup application version is missing");if(backupVersion>APP_VERSION)throw new IOException("This backup was created by a newer Siddiq Clinic version (v"+backupVersion+"). Install/update the app before restoring it.");if(backupDbVersion>APP_VERSION)throw new IOException("This backup database schema is newer than this app. Install/update the app before restoring it.");File stagedDb=new File(stage,"database/SiddiqClinic.db");if(!stagedDb.exists()||stagedDb.length()<10000)throw new IOException("Backup database is invalid or empty");
        // Validate that SQLite can open the staged database before touching current data.
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(stagedDb.getPath(),null,SQLiteDatabase.OPEN_READONLY)){d.rawQuery("SELECT name FROM sqlite_master LIMIT 1",null).close();}
        File safety=createLocalBackup(c,true);
        File currentDb=new File(c.getFilesDir(),"SiddiqClinic.db");
        // Never leave WAL/SHM files from the pre-restore database attached to the restored DB.
        new File(currentDb.getPath()+"-wal").delete();new File(currentDb.getPath()+"-shm").delete();
        copy(stagedDb,currentDb);
        File sp=new File(c.getFilesDir(),"prescriptions");if(sp.exists())deleteTree(sp);File stagedPres=new File(stage,"prescriptions");if(stagedPres.exists())copyTree(stagedPres,sp);
        deleteTree(stage);try{zip.delete();}catch(Exception ignored){}
        JSONObject out=new JSONObject();out.put("backupVersion",backupVersion);out.put("backupDatabaseVersion",backupDbVersion);out.put("currentVersion",APP_VERSION);out.put("migrated",backupVersion!=APP_VERSION);out.put("safetyBackup",safety.getName());return out;
    }
    private static void extract(ZipFile z,String prefix,File dest)throws IOException{dest.mkdirs();Enumeration<? extends ZipEntry> en=z.entries();while(en.hasMoreElements()){ZipEntry e=en.nextElement();if(e.isDirectory()||!e.getName().startsWith(prefix))continue;String rel=e.getName().substring(prefix.length());if(rel.isEmpty())continue;File f=new File(dest,rel);File canon=dest.getCanonicalFile();if(!f.getCanonicalPath().startsWith(canon.getPath()+File.separator))throw new IOException("Unsafe backup path");f.getParentFile().mkdirs();try(InputStream in=z.getInputStream(e);OutputStream out=new FileOutputStream(f)){byte[]b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}}}
    private static void copyTree(File src,File dst)throws IOException{if(src.isDirectory()){dst.mkdirs();File[]fs=src.listFiles();if(fs!=null)for(File f:fs)copyTree(f,new File(dst,f.getName()));}else{dst.getParentFile().mkdirs();copy(src,dst);}}
    private static void deleteTree(File f){if(!f.exists())return;if(f.isDirectory()){File[]fs=f.listFiles();if(fs!=null)for(File x:fs)deleteTree(x);}f.delete();}
}
