package com.siddiqclinic.android;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import java.util.concurrent.TimeUnit;

public class BackupWorker extends Worker {
    public BackupWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();
        try{
            android.content.SharedPreferences p=BackupManager.prefs(c);long now=System.currentTimeMillis();
            boolean le=p.getBoolean("local_enabled",true);boolean ce=p.getBoolean("cloud_enabled",false);
            long ll=p.getLong("last_local_ms",0),lc=p.getLong("last_cloud_ms",0);
            int lh=p.getInt("local_hours",1),ch=p.getInt("cloud_hours",6);
            if(le && (ll==0 || now-ll>=lh*3600000L)) BackupManager.createLocalBackup(c,false);
            if(ce && BackupManager.treeUri(c)!=null){
                lc=p.getLong("last_cloud_ms",0);if(lc==0 || now-lc>=ch*3600000L) BackupManager.syncLatestToDrive(c);
            }
            return Result.success();
        }catch(Exception e){return Result.retry();}
    }
    public static void schedule(Context c){
        PeriodicWorkRequest req=new PeriodicWorkRequest.Builder(BackupWorker.class,15,TimeUnit.MINUTES).build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("siddiq_backup_scheduler",ExistingPeriodicWorkPolicy.UPDATE,req);
    }
}
