# SiddiqClinic Android – v85

This version is based on v84 and adds a fully configurable Patient Prescription Template.

## Prescription template
Admin > Prescription Templates now controls the complete A4 prescription layout, including:
- Doctor box, hospital banner, hospital name/tagline/phone and logo position/size
- Header background and blue curve position, size, color and rotation
- Patient Details box and individual Patient ID, Name, Age, Sex, Phone, Address and Date fields
- General Details / Vitals box with SpO2, BP, Pulse, Weight and Temperature
- Chief Complaint, Prescription and Advice / Follow-up box positions and sizes
- Five independent right-side boxes: General Examination, Medical History, Drug Allergies, Investigation and Provisional Diagnosis
- Medicine/Dose/Frequency columns only; Sr., Duration and Timing are removed from printed prescription
- Footer background, orange curve, blue curve, Wish You Good Health and medico-legal note
- Per-box border, background, heading and content styling

All settings are saved in SQLite and the saved active template is used for prescription printing/PDF generation.
