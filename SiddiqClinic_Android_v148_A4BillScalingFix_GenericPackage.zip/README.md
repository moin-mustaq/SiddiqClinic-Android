Siddiq Clinic Android V148

Fix: OPD/LAB/Checkout A4 print clipping/scaling.

The bill renderer now uses the same WebView viewport/initial-scale configuration as the proven Prescription renderer. This prevents the 210mm bill template from being laid out against the phone CSS viewport and appearing as a tiny/partial strip at the A4 edge. The PDF remains A4 (210x297mm) and the bill template body remains centered within its configured character width.

Package: com.hospital.app
Version: 148.0 / versionCode 148
