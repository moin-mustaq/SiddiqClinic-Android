package com.hospital.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.print.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.pdf.PdfRenderer;
import android.view.View;
import android.view.ViewGroup;
import android.util.Base64;
import android.net.Uri;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import android.util.Log;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ScrollView;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import androidx.core.content.FileProvider;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Scope;
import org.json.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean prescriptionPdfBusy=false;
    private File dbFile;
    private static final int RESTORE_DB = 4101;
    private static final int PICK_HOSPITAL_LOGO = 4102;
    private static final int CONNECT_GOOGLE_DRIVE = 4103;
    private static final String GOOGLE_DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
    private static final String GOOGLE_AUTH_TAG = "SiddiqClinicGoogleAuth";
    private static final int PICK_LOCAL_BACKUP_FOLDER = 4104;
    private static final int PICK_LIVE_BACKUP_FOLDER = 4105;
    private static final String PC_SERVICE_TYPE = "_siddiqprint._tcp.";
    private static final String PC_PREFS = "pc_print";
    private NsdManager nsdManager;
    private NsdManager.DiscoveryListener nsdDiscoveryListener;
    private volatile boolean pcDiscoveryActive=false;
    private WifiManager.MulticastLock pcMulticastLock;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(18,59,109));
        getWindow().setNavigationBarColor(Color.rgb(18,59,109));
        dbFile = new File(getFilesDir(), "SiddiqClinic.db");
        if (!dbFile.exists()) copyAsset("database/TEST.db", dbFile);
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setTextZoom(100);
        webView.setBackgroundColor(Color.rgb(244,246,249));
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient(){ @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail){ runOnUiThread(()->Toast.makeText(MainActivity.this,"WebView renderer stopped. Reloading Siddiq Clinic...",Toast.LENGTH_LONG).show()); try{ view.destroy(); }catch(Exception ignored){} recreateMainWebView(); return true; } });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        BackupWorker.schedule(this);
    }

    private void recreateMainWebView(){
        runOnUiThread(()->{
            try{
                WebView nw=new WebView(MainActivity.this);
                WebSettings ws=nw.getSettings();
                ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
                ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setTextZoom(100);
                nw.setBackgroundColor(Color.rgb(244,246,249));
                nw.addJavascriptInterface(new Bridge(),"Android");
                nw.setWebViewClient(new WebViewClient(){ @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail){ return true; } });
                webView=nw;
                setContentView(webView);
                webView.loadUrl("file:///android_asset/index.html");
            }catch(Exception e){ Toast.makeText(MainActivity.this,"Unable to reload Siddiq Clinic: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        });
    }

    private void copyAsset(String name, File dest) {
        try (InputStream in = getAssets().open(name); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
        } catch(Exception e){ throw new RuntimeException(e); }
    }

    private SQLiteDatabase openDb() { return SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.OPEN_READWRITE); }
    private String jsonRows(Cursor c) throws Exception {
        JSONArray a=new JSONArray(); String[] cols=c.getColumnNames();
        while(c.moveToNext()){ JSONObject o=new JSONObject(); for(int i=0;i<cols.length;i++){ int t=c.getType(i); Object v; switch(t){case Cursor.FIELD_TYPE_NULL:v=JSONObject.NULL;break;case Cursor.FIELD_TYPE_INTEGER:v=c.getLong(i);break;case Cursor.FIELD_TYPE_FLOAT:v=c.getDouble(i);break;default:v=c.getString(i);} o.put(cols[i],v);} a.put(o); }
        c.close(); return a.toString();
    }
    private Object bind(JSONArray p,int i) throws Exception { Object v=p.opt(i); if(v==JSONObject.NULL) return null; return v; }

    public class Bridge {
        @JavascriptInterface public String sha256(String s){ try{byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)); StringBuilder h=new StringBuilder(); for(byte x:d) h.append(String.format("%02x",x)); return h.toString();}catch(Exception e){return "";} }
        @JavascriptInterface public String query(String sql, String paramsJson){ SQLiteDatabase d=null; Cursor c=null; try{d=openDb(); JSONArray p=new JSONArray(paramsJson==null?"[]":paramsJson); String[] args=new String[p.length()]; for(int i=0;i<p.length();i++){ Object v=bind(p,i); args[i]=v==null?null:String.valueOf(v); } c=d.rawQuery(sql,args); return jsonRows(c);}catch(Exception e){return error(e);}finally{if(c!=null&&!c.isClosed())c.close();if(d!=null)d.close();} }
        @JavascriptInterface public String execute(String sql, String paramsJson){SQLiteDatabase d=null; try{d=openDb(); JSONArray p=new JSONArray(paramsJson==null?"[]":paramsJson); Object[] args=new Object[p.length()]; for(int i=0;i<p.length();i++) args[i]=bind(p,i); d.execSQL(sql,args); long id=-1; try{Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);if(c.moveToFirst())id=c.getLong(0);c.close();}catch(Exception ignored){} if(d!=null){d.close();d=null;} BackupManager.scheduleLiveMirror(MainActivity.this); JSONObject o=new JSONObject();o.put("ok",true);o.put("lastInsertRowId",id);o.put("liveMirrorScheduled",true);return o.toString();}catch(Exception e){return error(e);}finally{if(d!=null)d.close();}}
        @JavascriptInterface public String executeBatch(String batchJson){SQLiteDatabase d=null; try{d=openDb(); JSONArray b=new JSONArray(batchJson); d.beginTransaction(); long id=-1; for(int i=0;i<b.length();i++){JSONObject x=b.getJSONObject(i);JSONArray p=x.optJSONArray("params");Object[] args=new Object[p==null?0:p.length()];for(int j=0;j<args.length;j++)args[j]=bind(p,j);d.execSQL(x.getString("sql"),args);Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);if(c.moveToFirst())id=c.getLong(0);c.close();}d.setTransactionSuccessful();d.endTransaction(); if(d!=null){d.close();d=null;} BackupManager.scheduleLiveMirror(MainActivity.this); JSONObject o=new JSONObject();o.put("ok",true);o.put("lastInsertRowId",id);o.put("liveMirrorScheduled",true);return o.toString();}catch(Exception e){if(d!=null&&d.inTransaction())d.endTransaction();return error(e);}finally{if(d!=null)d.close();}}
        private String error(Exception e){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",e.toString());return o.toString();}catch(Exception x){return "{\"ok\":false}";}}

        @JavascriptInterface public void toast(String msg){runOnUiThread(()->Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show());}
        @JavascriptInterface public void alert(String title,String msg){runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show());}
        @JavascriptInterface public void shareText(String subject,String text){Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_SUBJECT,subject);s.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(s,"Share"));}
        @JavascriptInterface public void whatsapp(String phone,String text){try{String p=phone==null?"":phone.replaceAll("[^0-9]","");String url="https://wa.me/"+(p.startsWith("91")?p:"91"+p)+"?text="+Uri.encode(text);startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("WhatsApp is not available");}}
        @JavascriptInterface public void chooseHospitalLogo(){
            try{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i,PICK_HOSPITAL_LOGO);
            }catch(Exception e){ alert("Hospital Logo","Unable to open image picker: "+e); }
        }
        @JavascriptInterface public void printPage(){ printPage("Document", "{}"); }

        @JavascriptInterface public void printPage(String jobLabel){ printPage(jobLabel, "{}"); }

        @JavascriptInterface public void printPage(String jobLabel, String pageConfigJson){
            final String label=(jobLabel==null||jobLabel.trim().isEmpty())?"Document":jobLabel.trim();
            final org.json.JSONObject pageConfig=parsePageConfig(pageConfigJson);
            if(pcPrefs().getBoolean("enabled",false)){
                // Do not synchronously wait a fixed 2 seconds for WebView JavaScript.
                // On busy/large bills that could return an empty printArea and create
                // a tiny blank PDF. Keep the WebView callback alive until the content
                // is actually available (or a 10 second safety timeout is reached).
                getPrintAreaHtmlAsync(html -> printHtmlToPc(html,label,null,pageConfig),
                        () -> runOnUiThread(() -> alert("Print Failed", label + " document content could not be prepared for printing.")));
                return;
            }
            printPageAndroid(pageConfig);
        }

        private void printPageAndroid(org.json.JSONObject pageConfig){
            runOnUiThread(()->{
                try{
                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                    PrintDocumentAdapter ad=webView.createPrintDocumentAdapter("Siddiq Clinic");
                    PrintAttributes.Builder pb=new PrintAttributes.Builder();
                    String orient=pageConfig.optString("orientation","portrait");
                    pb.setMediaSize("landscape".equalsIgnoreCase(orient)?PrintAttributes.MediaSize.ISO_A4.asLandscape():PrintAttributes.MediaSize.ISO_A4);
                    pb.setMinMargins(PrintAttributes.Margins.NO_MARGINS);
                    pm.print("Siddiq Clinic",ad,pb.build());
                }catch(Exception e){ alert("Print","Unable to start printing: "+e.getMessage()); }
            });
        }

        private String getPrintAreaHtml(){
            final String[] out={""};
            final CountDownLatch latch=new CountDownLatch(1);
            runOnUiThread(()->webView.evaluateJavascript("(function(){var e=document.getElementById('printArea');return e?e.innerHTML:'';})()",v->{
                try{out[0]=new org.json.JSONTokener(v==null?"\"\"":v).nextValue().toString();}catch(Exception ignored){} latch.countDown();
            }));
            try{latch.await(2,TimeUnit.SECONDS);}catch(Exception ignored){}
            return out[0];
        }

        private void getPrintAreaHtmlAsync(java.util.function.Consumer<String> onSuccess, Runnable onFailure){
            final Handler h=new Handler(Looper.getMainLooper());
            final boolean[] finished={false};
            final Runnable fail=()->{ if(finished[0]) return; finished[0]=true; if(onFailure!=null) onFailure.run(); };
            final Runnable timeout=fail;
            h.postDelayed(timeout,10000);
            runOnUiThread(()->{
                try{
                    if(webView==null){ fail.run(); return; }
                    webView.evaluateJavascript("(function(){try{var e=document.getElementById('printArea');return e?e.innerHTML:'';}catch(x){return '';}})()", v->{
                        if(finished[0]) return;
                        String html="";
                        try{ html=new org.json.JSONTokener(v==null?"\"\"":v).nextValue().toString(); }catch(Exception ignored){}
                        if(html==null || html.trim().isEmpty()){ fail.run(); return; }
                        finished[0]=true;
                        h.removeCallbacks(timeout);
                        if(onSuccess!=null) onSuccess.accept(html);
                    });
                }catch(Throwable e){ fail.run(); }
            });
        }

        private String compactEmbeddedImages(String html){
            if(html==null || html.length()<1000) return html==null?"":html;
            Pattern p=Pattern.compile("src\\s*=\\s*([\\\"\\\'])data:image/[^;]+;base64,([^\\\"\\\']+)\\1",Pattern.CASE_INSENSITIVE);
            Matcher m=p.matcher(html); StringBuffer sb=new StringBuffer();
            while(m.find()){
                try{
                    byte[] raw=Base64.decode(m.group(2),Base64.DEFAULT);
                    Bitmap src=BitmapFactory.decodeByteArray(raw,0,raw.length);
                    if(src==null){m.appendReplacement(sb,Matcher.quoteReplacement(m.group(0)));continue;}
                    int maxW=1000,maxH=500,w=src.getWidth(),h=src.getHeight();
                    float scale=Math.min(1f,Math.min((float)maxW/w,(float)maxH/h));
                    Bitmap b=src;
                    if(scale<1f){int nw=Math.max(1,Math.round(w*scale)),nh=Math.max(1,Math.round(h*scale));b=Bitmap.createScaledBitmap(src,nw,nh,true);}
                    // Canvas handwriting PNGs commonly contain a transparent background.
                    // Bitmap.compress(JPEG) converts transparent pixels to black, which was
                    // causing the entire handwriting area to appear as a solid black box in
                    // generated/viewed/printed prescriptions. Composite onto white first.
                    Bitmap white=Bitmap.createBitmap(b.getWidth(),b.getHeight(),Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas wc=new android.graphics.Canvas(white);
                    wc.drawColor(Color.WHITE);
                    wc.drawBitmap(b,0,0,null);
                    ByteArrayOutputStream bos=new ByteArrayOutputStream();
                    white.compress(Bitmap.CompressFormat.JPEG,88,bos);
                    String enc=Base64.encodeToString(bos.toByteArray(),Base64.NO_WRAP);
                    String replacement="src=\"data:image/jpeg;base64,"+enc+"\"";
                    m.appendReplacement(sb,Matcher.quoteReplacement(replacement));
                    if(white!=b) white.recycle();
                    if(b!=src) b.recycle();
                    src.recycle();
                }catch(Throwable ignored){
                    m.appendReplacement(sb,Matcher.quoteReplacement(m.group(0)));
                }
            }
            m.appendTail(sb); return sb.toString();
        }

        private void savePrescriptionPdfInternal(String html,String relativePath, final Runnable onSuccess, final Runnable onFailure){
            runOnUiThread(()->{
                if(html==null || html.trim().isEmpty()){
                    if(onFailure!=null) onFailure.run();
                    return;
                }
                if(prescriptionPdfBusy){ if(onFailure!=null) onFailure.run(); return; }
                prescriptionPdfBusy=true;
                final File out=new File(getFilesDir(),relativePath==null?"prescriptions/prescription.pdf":relativePath);
                File parent=out.getParentFile();
                if(parent!=null&&!parent.exists()&&!parent.mkdirs()&&!parent.exists()){
                    prescriptionPdfBusy=false; if(onFailure!=null) onFailure.run();
                    return;
                }

                final ViewGroup contentRoot=(ViewGroup)findViewById(android.R.id.content);
                if(contentRoot==null){ prescriptionPdfBusy=false; if(onFailure!=null) onFailure.run(); return; }

                final WebView w=new WebView(MainActivity.this);
                final boolean[] finished={false};
                final Runnable cleanup=()->{
                    try{ if(w.getParent() instanceof ViewGroup) ((ViewGroup)w.getParent()).removeView(w); }catch(Exception ignored){}
                    try{ w.stopLoading(); }catch(Exception ignored){}
                    try{ w.destroy(); }catch(Exception ignored){}
                };
                final Runnable fail=()->{
                    if(finished[0])return;
                    finished[0]=true;
                    cleanup.run();
                    prescriptionPdfBusy=false; if(onFailure!=null)onFailure.run();
                };

                // Only the temporary renderer is attached. The application's main WebView
                // remains untouched, avoiding parent/layout corruption during Save/View PDF.
                try {
                    ViewGroup.LayoutParams lp=new ViewGroup.LayoutParams(794,1123);
                    contentRoot.addView(w,lp);
                    w.setAlpha(1.0f);
                    // Keep the renderer attached and fully opaque: WebView.draw(canvas) respects
                    // the View alpha. Using a near-zero alpha here produced white/blank PDFs.
                    // The temporary renderer is moved off the visible app area instead.
                    w.setTranslationX(-794);

                    WebSettings ws=w.getSettings();
                ws.setJavaScriptEnabled(true);
                ws.setDomStorageEnabled(true);
                ws.setAllowFileAccess(true);
                ws.setAllowContentAccess(true);
                ws.setLoadsImagesAutomatically(true);
                ws.setDefaultTextEncodingName("UTF-8");
                ws.setUseWideViewPort(false);
                ws.setLoadWithOverviewMode(false);
                ws.setSupportZoom(false);
                int densityScale = Math.max(1, Math.round(getResources().getDisplayMetrics().density * 100f));
                w.setInitialScale(Math.max(25, Math.min(100, Math.round(10000f / densityScale))));
                w.setBackgroundColor(Color.WHITE);
                // Do NOT force software rendering. WebView is a Chromium renderer and
                // forcing a software layer can trigger renderer/memory failures on some devices.

                w.setWebViewClient(new WebViewClient(){
                    private boolean pageReady=false;
                    private void renderWhenReady(WebView view){
                        if(finished[0]||pageReady)return;
                        pageReady=true;
                        view.postDelayed(()->{
                            if(finished[0])return;
                            try{
                                final int pdfWidth=595, pdfHeight=842;
                                final int cssWidth=794, cssHeight=1123;
                                view.measure(View.MeasureSpec.makeMeasureSpec(cssWidth,View.MeasureSpec.EXACTLY),
                                             View.MeasureSpec.makeMeasureSpec(cssHeight,View.MeasureSpec.EXACTLY));
                                view.layout(0,0,cssWidth,cssHeight);

                                android.graphics.pdf.PdfDocument pdf=new android.graphics.pdf.PdfDocument();
                                android.graphics.pdf.PdfDocument.PageInfo info=
                                        new android.graphics.pdf.PdfDocument.PageInfo.Builder(pdfWidth,pdfHeight,1).create();
                                android.graphics.pdf.PdfDocument.Page page=pdf.startPage(info);
                                android.graphics.Canvas canvas=page.getCanvas();
                                canvas.drawColor(Color.WHITE);
                                canvas.save();
                                canvas.scale((float)pdfWidth/cssWidth,(float)pdfHeight/cssHeight);
                                view.draw(canvas);
                                canvas.restore();
                                pdf.finishPage(page);
                                try(FileOutputStream fos=new FileOutputStream(out,false)){ pdf.writeTo(fos); }
                                pdf.close();

                                if(!out.exists()||out.length()<100){ throw new IOException("Generated PDF is empty"); }
                                finished[0]=true;
                                cleanup.run();
                                prescriptionPdfBusy=false;
                                BackupManager.mirrorPrescriptionFileAsync(MainActivity.this,out,relativePath);
                                if(onSuccess!=null)onSuccess.run();
                            }catch(Throwable e){
                                try{if(out.exists())out.delete();}catch(Exception ignored){}
                                fail.run();
                            }
                        },300);
                    }
                    @Override public void onPageFinished(WebView view,String url){
                        if(finished[0])return;
                        // Wait for document images and fonts rather than relying on a fixed
                        // 1.5 second delay. This is important for saved handwriting images.
                        view.evaluateJavascript("(async function(){try{if(document.fonts&&document.fonts.ready)await document.fonts.ready;var imgs=[...document.images];await Promise.all(imgs.map(function(i){return i.complete?Promise.resolve():new Promise(function(r){i.onload=i.onerror=r;});}));return 'READY';}catch(e){return 'READY';}})()",value->{
                            if(!finished[0])renderWhenReady(view);
                        });
                    }
                    @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){
                        // Never let a Chromium/WebView renderer failure close the whole clinic app.
                        fail.run();
                        return true;
                    }
                });

                String fragment=compactEmbeddedImages(html==null?"":html);
                String pdfHtml="<!doctype html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=794, initial-scale=1, maximum-scale=1, user-scalable=no\"><link rel=\"stylesheet\" href=\"styles.css\"><style>html,body{margin:0!important;padding:0!important;background:#fff!important;width:794px!important;height:1123px!important;} .rx-sheet{position:relative!important;margin:0!important;width:210mm!important;height:297mm!important;min-height:297mm!important;max-height:297mm!important;overflow:hidden!important;transform:none!important;transform-origin:top left!important;} table{border-collapse:collapse;} img{max-width:100%;}</style></head><body>"+fragment+"</body></html>";
                w.loadDataWithBaseURL("file:///android_asset/",pdfHtml,"text/html","UTF-8",null);
                } catch(Throwable setupError) {
                    try{ if(w.getParent() instanceof ViewGroup) ((ViewGroup)w.getParent()).removeView(w); }catch(Exception ignored){}
                    try{ w.destroy(); }catch(Exception ignored){}
                    prescriptionPdfBusy=false; if(onFailure!=null) onFailure.run();
                }
            });
        }

        private void notifyJsPdfResult(String path, boolean ok, String action){
            String p=JSONObject.quote(path==null?"":path);
            String a=JSONObject.quote(action==null?"":action);
            runOnUiThread(()->{
                try{ if(webView!=null) webView.evaluateJavascript("window.onPrescriptionPdfResult && window.onPrescriptionPdfResult("+p+","+ok+","+a+")",null); }catch(Exception ignored){}
            });
        }

        @JavascriptInterface public void savePrescriptionPdf(String html,String relativePath){
            final String path=relativePath==null?"prescriptions/prescription.pdf":relativePath;
            savePrescriptionPdfInternal(html,path,()->notifyJsPdfResult(path,true,"save"),()->{notifyJsPdfResult(path,false,"save");alert("Prescription PDF","Unable to save prescription PDF. Please try again.");});
        }

        @JavascriptInterface public void savePrescriptionPdfAndOpen(String html,String relativePath){
            final String path=relativePath==null?"prescriptions/prescription.pdf":relativePath;
            savePrescriptionPdfInternal(html,path,()->openPdf(path),()->alert("Prescription PDF","Unable to recreate the prescription PDF."));
        }

        @JavascriptInterface public void savePrescriptionPdfAndPrint(String html,String relativePath){
            final String path=relativePath==null?"prescriptions/prescription.pdf":relativePath;
            savePrescriptionPdfInternal(html,path,()->{
                try{
                    byte[] pdf=readBytes(new File(getFilesDir(),path));
                    if(pcPrefs().getBoolean("enabled",false)){
                        if(pcPrefs().getString("host","").isEmpty()) startPcDiscovery(true,"/print",pdf,true,"Prescription",()->notifyJsPdfResult(path,true,"print"));
                        else sendPcRequest("/print",pdf,true,true,"Prescription",()->notifyJsPdfResult(path,true,"print"));
                    }else{
                        printPdfFile(new File(getFilesDir(),path));
                        notifyJsPdfResult(path,true,"print");
                    }
                }catch(Exception e){ notifyJsPdfResult(path,false,"print"); alert("Prescription Print","Unable to send the prescription to the printer.\n\n"+e.getMessage()); }
            },()->{notifyJsPdfResult(path,false,"print");alert("Prescription PDF","Unable to create the prescription PDF for printing.");});
        }
        private byte[] readBytes(File f)throws IOException{try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();}}

        @JavascriptInterface public boolean pdfExists(String relativePath){
            try{
                File f=new File(getFilesDir(),relativePath==null?"":relativePath);
                return f.exists() && f.length()>0;
            }catch(Exception e){ return false; }
        }

        private void printPdfFile(File file){
            try{
                if(file==null||!file.exists()||file.length()==0){alert("Print","Prescription PDF not found.");return;}
                // When PC Printer Mode is enabled, NEVER open the Android print preview.
                // Send the already-generated PDF directly to the PC print server.
                if(pcPrefs().getBoolean("enabled",false)){
                    byte[] pdf=readBytes(file);
                    if(pcPrefs().getString("host","").isEmpty()) startPcDiscovery(true,"/print",pdf,true,"Prescription",null);
                    else sendPcRequest("/print",pdf,true,true,"Prescription",null);
                    return;
                }
                PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                PrintDocumentAdapter adapter=new PrintDocumentAdapter(){
                    @Override public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){
                        if(cs.isCanceled()){cb.onLayoutCancelled();return;}
                        PrintDocumentInfo info=new PrintDocumentInfo.Builder(file.getName()).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();
                        cb.onLayoutFinished(info,true);
                    }
                    @Override public void onWrite(PageRange[] pages,ParcelFileDescriptor dest,CancellationSignal cs,WriteResultCallback cb){
                        try(FileInputStream in=new FileInputStream(file);FileOutputStream out=new FileOutputStream(dest.getFileDescriptor())){
                            byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0){if(cs.isCanceled()){cb.onWriteCancelled();return;}out.write(buf,0,n);}out.flush();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                        }catch(Exception e){cb.onWriteFailed(e.getMessage());}
                        finally{try{dest.close();}catch(Exception ignored){}}
                    }
                };
                pm.print("Siddiq Clinic Prescription",adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
            }catch(Exception e){alert("Print","Unable to start prescription printing: "+e.getMessage());}
        }

        @JavascriptInterface public void printSavedPrescriptionPdf(String relativePath){
            final String path=relativePath==null?"":relativePath;
            runOnUiThread(()->{
                File file=new File(getFilesDir(),path);
                if(!file.exists() || file.length()<1000){
                    alert("Prescription Print","Saved prescription PDF was not found. Please save the prescription first.");
                    return;
                }
                // Reuse the already-correct saved A4 prescription PDF. Do not render the
                // prescription template a second time for PC printing.
                if(pcPrefs().getBoolean("enabled",false)){
                    new Thread(()->{
                        try{
                            byte[] pdf=readBytes(file);
                            if(pcPrefs().getString("host","").isEmpty()) startPcDiscovery(true,"/print",pdf,true,"Prescription",null);
                            else sendPcRequest("/print",pdf,true,true,"Prescription",null);
                        }catch(Exception e){
                            runOnUiThread(()->alert("Prescription Print","Unable to send the saved prescription to the PC printer.\n\n"+e.getMessage()));
                        }
                    }).start();
                }else{
                    printPdfFile(file);
                }
            });
        }

        @JavascriptInterface public void openPdf(String relativePath){
            openPdfInApp(relativePath);
        }

        /**
         * Opens a saved prescription PDF inside Siddiq Clinic instead of launching
         * an external PDF reader. The viewer is a full-screen dialog, supports
         * portrait and landscape device orientations, supports multi-page PDFs,
         * and has a close button in the top-right corner.
         */
        private void openPdfInApp(String relativePath){
            final File f=new File(getFilesDir(),relativePath==null?"":relativePath);
            if(!f.exists() || f.length()==0){
                alert("Prescription PDF","PDF file not found.");
                return;
            }
            runOnUiThread(()->{
                Dialog dialog=new Dialog(MainActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

                FrameLayout root=new FrameLayout(MainActivity.this);
                root.setBackgroundColor(Color.rgb(235,238,242));

                LinearLayout main=new LinearLayout(MainActivity.this);
                main.setOrientation(LinearLayout.VERTICAL);
                main.setBackgroundColor(Color.WHITE);

                FrameLayout top=new FrameLayout(MainActivity.this);
                top.setBackgroundColor(Color.rgb(18,59,109));
                TextView title=new TextView(MainActivity.this);
                title.setText("Prescription");
                title.setTextColor(Color.WHITE);
                title.setTextSize(18);
                title.setGravity(Gravity.CENTER_VERTICAL);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,-1);
                tp.leftMargin=24; tp.rightMargin=70;
                top.addView(title,tp);

                TextView close=new TextView(MainActivity.this);
                close.setText("✕");
                close.setTextColor(Color.WHITE);
                close.setTextSize(25);
                close.setGravity(Gravity.CENTER);
                close.setBackgroundColor(Color.TRANSPARENT);
                close.setContentDescription("Close prescription");
                close.setOnClickListener(v->dialog.dismiss());
                FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(64,64,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
                cp.rightMargin=4;
                top.addView(close,cp);

                main.addView(top,new LinearLayout.LayoutParams(-1,68));

                ScrollView scroll=new ScrollView(MainActivity.this);
                scroll.setFillViewport(true);
                LinearLayout pages=new LinearLayout(MainActivity.this);
                pages.setOrientation(LinearLayout.VERTICAL);
                pages.setGravity(Gravity.CENTER_HORIZONTAL);
                pages.setPadding(8,8,8,8);
                scroll.addView(pages,new ScrollView.LayoutParams(-1,-2));
                main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
                root.addView(main,new FrameLayout.LayoutParams(-1,-1));
                dialog.setContentView(root);

                Window w=dialog.getWindow();
                if(w!=null){
                    w.setBackgroundDrawableResource(android.R.color.transparent);
                    w.setLayout(-1,-1);
                    w.setFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                    w.setStatusBarColor(Color.rgb(18,59,109));
                    w.setNavigationBarColor(Color.BLACK);
                }
                dialog.setOnShowListener(x->{
                    Window dw=dialog.getWindow();
                    if(dw!=null)dw.setLayout(-1,-1);
                    renderPdfPagesInDialog(f,pages,dialog);
                });
                dialog.show();
            });
        }

        private void renderPdfPagesInDialog(File file,LinearLayout pages,Dialog dialog){
            new Thread(()->{
                PdfRenderer renderer=null;
                ParcelFileDescriptor pfd=null;
                final java.util.ArrayList<Bitmap> bitmaps=new java.util.ArrayList<>();
                try{
                    pfd=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer=new PdfRenderer(pfd);
                    int count=renderer.getPageCount();
                    for(int i=0;i<count;i++){
                        PdfRenderer.Page page=renderer.openPage(i);
                        int width=Math.max(1,page.getWidth()*2);
                        int height=Math.max(1,page.getHeight()*2);
                        Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
                        bmp.eraseColor(Color.WHITE);
                        page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        page.close();
                        bitmaps.add(bmp);
                    }
                }catch(Exception e){
                    for(Bitmap b:bitmaps)try{b.recycle();}catch(Exception ignored){}
                    final String msg=e.getMessage()==null?e.toString():e.getMessage();
                    runOnUiThread(()->{ alert("Prescription","Unable to display the prescription PDF.\n\n"+msg); dialog.dismiss(); });
                    return;
                }finally{
                    try{if(renderer!=null)renderer.close();}catch(Exception ignored){}
                    try{if(pfd!=null)pfd.close();}catch(Exception ignored){}
                }
                runOnUiThread(()->{
                    try{
                        for(Bitmap bmp:bitmaps){
                            ZoomImageView iv=new ZoomImageView(MainActivity.this);
                            iv.setImageBitmap(bmp);
                            iv.setAdjustViewBounds(true);
                            iv.setBackgroundColor(Color.WHITE);
                            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);
                            ip.bottomMargin=12;
                            pages.addView(iv,ip);
                        }
                    }catch(Exception e){
                        for(Bitmap b:bitmaps)try{b.recycle();}catch(Exception ignored){}
                        alert("Prescription","Unable to display the prescription PDF.\n\n"+(e.getMessage()==null?e.toString():e.getMessage()));
                        dialog.dismiss();
                    }
                });
            }).start();
        }
        private android.content.SharedPreferences pcPrefs(){return getSharedPreferences(PC_PREFS,MODE_PRIVATE);}
        private boolean pcPrinterEnabled(){return pcPrefs().getBoolean("enabled",false);}
        private boolean pcPrinterConfigured(){return pcPrefs().getBoolean("enabled",false) && !pcPrefs().getString("host","").isEmpty();}
        private String pcBaseUrl(){return "http://"+pcPrefs().getString("host","")+":"+pcPrefs().getInt("port",5015);}
        private void notifyPc(String msg){runOnUiThread(()->Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show());}

        @JavascriptInterface public String pcPrinterStatus(){
            JSONObject o=new JSONObject();
            try{o.put("enabled",pcPrefs().getBoolean("enabled",false));o.put("host",pcPrefs().getString("host",""));o.put("port",pcPrefs().getInt("port",5015));o.put("serverName",pcPrefs().getString("serverName",""));o.put("printer",pcPrefs().getString("printer",""));}catch(Exception ignored){}
            return o.toString();
        }
        @JavascriptInterface public void setPcPrinterEnabled(boolean enabled){pcPrefs().edit().putBoolean("enabled",enabled).apply();}
        @JavascriptInterface public void clearPcPrinter(){pcPrefs().edit().clear().apply();stopPcDiscovery();}
        @JavascriptInterface public void findPcPrinter(){startPcDiscovery(false);}
        @JavascriptInterface public void testPcPrinter(){
            final String host=pcPrefs().getString("host","");
            if(!host.isEmpty()){sendPcRequest("/test",null,true,true,"Test print",null);return;}
            startPcDiscovery(true,"/test",null,true,"Test print",null);
        }
        @JavascriptInterface public void printCurrentPageToPc(String html){printHtmlToPc(html,"Document",null,parsePageConfig("{}"));}

        private void startPcDiscovery(boolean forPrint){ startPcDiscovery(forPrint,"/print",null,false,"Document",null); }
        private void startPcDiscovery(boolean forPrint,String requestPath,byte[] requestPayload,boolean notify,String jobLabel,Runnable onSuccess){
            if(nsdManager==null)nsdManager=(NsdManager)getSystemService(NSD_SERVICE);
            stopPcDiscovery(); pcDiscoveryActive=true;
            try{
                WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
                if(wm!=null){
                    pcMulticastLock=wm.createMulticastLock("SiddiqClinicPcPrinterDiscovery");
                    pcMulticastLock.setReferenceCounted(false);
                    pcMulticastLock.acquire();
                }
            }catch(Exception ignored){}
            nsdDiscoveryListener=new NsdManager.DiscoveryListener(){
                public void onStartDiscoveryFailed(String serviceType,int errorCode){pcDiscoveryActive=false; if(forPrint) alert("Print Failed",jobLabel+" failed.\n\nPC print server could not be discovered."); else notifyPc("PC Print Server discovery failed");}
                public void onStopDiscoveryFailed(String serviceType,int errorCode){pcDiscoveryActive=false;}
                public void onDiscoveryStarted(String serviceType){}
                public void onDiscoveryStopped(String serviceType){pcDiscoveryActive=false;}
                public void onServiceLost(NsdServiceInfo serviceInfo){}
                public void onServiceFound(NsdServiceInfo serviceInfo){
                    String discoveredType=serviceInfo.getServiceType();
                    if(discoveredType==null || !PC_SERVICE_TYPE.equals(discoveredType.endsWith(".")?discoveredType:discoveredType+"."))return;
                    try{nsdManager.resolveService(serviceInfo,new NsdManager.ResolveListener(){
                        public void onResolveFailed(NsdServiceInfo info,int code){}
                        public void onServiceResolved(NsdServiceInfo info){
                            InetAddress a=info.getHost(); if(a==null)return;
                            String host=a.getHostAddress(); int port=info.getPort();
                            pcPrefs().edit().putString("host",host).putInt("port",port).putString("serverName",info.getServiceName()).apply();
                            if(forPrint){stopPcDiscovery(); notifyPc("PC printer found. Sending print job...");}
                            else{stopPcDiscovery(); runOnUiThread(()->webView.evaluateJavascript("window.onPcPrinterFound&&window.onPcPrinterFound("+JSONObject.quote(host)+","+port+","+JSONObject.quote(info.getServiceName())+")",null));}
                            if(forPrint)sendPcRequest(requestPath,requestPayload,notify,false,jobLabel,onSuccess);
                        }
                    });}catch(Exception ignored){}
                }
            };
            try{nsdManager.discoverServices(PC_SERVICE_TYPE,NsdManager.PROTOCOL_DNS_SD,nsdDiscoveryListener);}catch(Exception e){pcDiscoveryActive=false;notifyPc("Unable to discover PC printer: "+e.getMessage());}
        }
        private void stopPcDiscovery(){
            try{if(nsdManager!=null&&nsdDiscoveryListener!=null&&pcDiscoveryActive)nsdManager.stopServiceDiscovery(nsdDiscoveryListener);}catch(Exception ignored){}
            pcDiscoveryActive=false;
            try{if(pcMulticastLock!=null&&pcMulticastLock.isHeld())pcMulticastLock.release();}catch(Exception ignored){}
            pcMulticastLock=null;
        }

        private void sendPcRequest(String path,byte[] payload,boolean notify){sendPcRequest(path,payload,notify,true,"Document",null);}
        private void sendPcRequest(String path,byte[] payload,boolean notify,boolean retryDiscovery){sendPcRequest(path,payload,notify,retryDiscovery,"Document",null);}
        private void sendPcRequest(String path,byte[] payload,boolean notify,boolean retryDiscovery,String jobLabel,Runnable onSuccess){
            new Thread(()->{
                HttpURLConnection c=null;
                try{
                    String url=pcBaseUrl()+path;c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(3000);c.setReadTimeout(15000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/pdf");String printer=pcPrefs().getString("printer","");if(!printer.isEmpty())c.setRequestProperty("X-Printer",printer);
                    if(payload!=null){try(OutputStream o=c.getOutputStream()){o.write(payload);}}
                    int code=c.getResponseCode();String msg="";try(InputStream in=code>=400?c.getErrorStream():c.getInputStream()){if(in!=null){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[1024];int n;while((n=in.read(x))>0)b.write(x,0,n);msg=b.toString("UTF-8");}}
                    if(code<200||code>=300)throw new IOException("PC print server returned HTTP "+code+(msg.isEmpty()?"":" - "+msg));
                    if(notify) showPrintSuccess(jobLabel);
                    if(onSuccess!=null) onSuccess.run();
                }catch(Exception e){
                    pcPrefs().edit().remove("host").apply();
                    if(retryDiscovery){
                        runOnUiThread(()->Toast.makeText(MainActivity.this,"PC printer not reachable. Searching for the PC again...",Toast.LENGTH_SHORT).show());
                        startPcDiscovery(true,path,payload,notify,jobLabel,onSuccess);
                    }else{
                        runOnUiThread(()->alert("Print Failed",jobLabel+" could not be printed.\n\n"+e.getMessage()));
                    }
                } finally{if(c!=null)c.disconnect();}
            }).start();
        }
        private void showPrintSuccess(String jobLabel){
            runOnUiThread(()->{
                final Toast t=Toast.makeText(MainActivity.this,(jobLabel==null||jobLabel.trim().isEmpty()?"Document":jobLabel)+" printed successfully",Toast.LENGTH_SHORT);
                t.show();
                new Handler(Looper.getMainLooper()).postDelayed(t::cancel,1000);
            });
        }
        private void printHtmlToPc(String html,String jobLabel,Runnable onSuccess,org.json.JSONObject pageConfig){
            if(html==null || html.trim().isEmpty()){
                runOnUiThread(()->alert("Print Failed",jobLabel+" document content is empty. Nothing was sent to the PC printer."));
                return;
            }
            renderGenericPdf(html,pageConfig,pdf->{
                // A valid PDF containing a real bill/prescription should be materially
                // larger than the ~4 KB blank PDF produced by the old failure path.
                if(pdf==null || pdf.length<1000){
                    runOnUiThread(()->alert("Print Failed",jobLabel+" generated an empty PDF. Please try again."));
                    return;
                }
                if(pcPrefs().getString("host","").isEmpty()) startPcDiscovery(true,"/print",pdf,true,jobLabel,onSuccess);
                else sendPcRequest("/print",pdf,true,true,jobLabel,onSuccess);
            },()->runOnUiThread(()->alert("Print Failed",jobLabel+" could not be prepared for printing.")));
        }
        private org.json.JSONObject parsePageConfig(String json){
            org.json.JSONObject o=new org.json.JSONObject();
            try{if(json!=null&&!json.trim().isEmpty())o=new org.json.JSONObject(json);}catch(Exception ignored){}
            try{o.put("width",o.optDouble("width",210));o.put("height",o.optDouble("height",297));o.put("orientation",o.optString("orientation","portrait"));o.put("resolutionDpi",Math.max(72,Math.min(600,o.optInt("resolutionDpi",300))));o.put("marginTop",Math.max(0,o.optDouble("marginTop",0)));o.put("marginBottom",Math.max(0,o.optDouble("marginBottom",0)));o.put("marginLeft",Math.max(0,o.optDouble("marginLeft",0)));o.put("marginRight",Math.max(0,o.optDouble("marginRight",0)));}catch(Exception ignored){}
            return o;
        }

        private boolean isPdfVisuallyBlank(File file){
            PdfRenderer renderer=null;
            PdfRenderer.Page page=null;
            ParcelFileDescriptor pfd=null;
            Bitmap bitmap=null;
            try{
                pfd=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
                renderer=new PdfRenderer(pfd);
                if(renderer.getPageCount()<1)return true;
                page=renderer.openPage(0);
                int w=Math.max(200,Math.min(900,page.getWidth()/2));
                int h=Math.max(200,Math.min(1200,page.getHeight()/2));
                bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                int step=Math.max(1,(int)Math.sqrt((w*h)/50000.0));
                int nonWhite=0, samples=0;
                for(int y=0;y<h;y+=step){
                    for(int x=0;x<w;x+=step){
                        int c=bitmap.getPixel(x,y);
                        int r=Color.red(c),g=Color.green(c),b=Color.blue(c),a=Color.alpha(c);
                        samples++;
                        if(a>10 && (r<245 || g<245 || b<245)) nonWhite++;
                    }
                }
                // A normal bill has text/borders/logo and therefore many non-white pixels.
                return samples==0 || nonWhite < Math.max(8,samples/1000);
            }catch(Throwable ignored){
                // Do not reject a valid PDF merely because PdfRenderer is unavailable on a device.
                return false;
            }finally{
                try{if(page!=null)page.close();}catch(Exception ignored){}
                try{if(renderer!=null)renderer.close();}catch(Exception ignored){}
                try{if(bitmap!=null)bitmap.recycle();}catch(Exception ignored){}
                try{if(pfd!=null)pfd.close();}catch(Exception ignored){}
            }
        }

        private void renderGenericPdf(String html, org.json.JSONObject cfg, java.util.function.Consumer<byte[]> onSuccess, Runnable onFailure){
            /*
             * OPD/LAB/CHECKOUT deliberately use the SAME proven rendering path as
             * prescription printing:
             *
             *     WebView -> PdfDocument + WebView.draw(Canvas)
             *
             * The previous V144 implementation used WebView.createPrintDocumentAdapter().
             * That produced a PDF file on some devices, but the PDF received by the PC
             * could contain a completely blank page.  The prescription renderer in this
             * application is already proven to produce correct PDFs, so bill printing
             * must use that renderer instead of a second Chromium print pipeline.
             */
            runOnUiThread(() -> {
                final ViewGroup contentRoot=(ViewGroup)findViewById(android.R.id.content);
                if(contentRoot==null){ if(onFailure!=null)onFailure.run(); return; }

                final WebView w=new WebView(MainActivity.this);
                final boolean[] finished={false};
                final Runnable cleanup=()->{
                    try{ if(w.getParent() instanceof ViewGroup)((ViewGroup)w.getParent()).removeView(w); }catch(Exception ignored){}
                    try{ w.stopLoading(); }catch(Exception ignored){}
                    try{ w.destroy(); }catch(Exception ignored){}
                };
                final Runnable fail=()->{
                    if(finished[0])return;
                    finished[0]=true;
                    cleanup.run();
                    if(onFailure!=null)onFailure.run();
                };

                try{
                    double mmW=Math.max(1.0,cfg.optDouble("width",210));
                    double mmH=Math.max(1.0,cfg.optDouble("height",297));
                    if("landscape".equalsIgnoreCase(cfg.optString("orientation","portrait")) && mmW<mmH){
                        double z=mmW; mmW=mmH; mmH=z;
                    }
                    if(!"landscape".equalsIgnoreCase(cfg.optString("orientation","portrait")) && mmW>mmH){
                        double z=mmW; mmW=mmH; mmH=z;
                    }

                    final int cssW=Math.max(1,(int)Math.round(mmW*96.0/25.4));
                    final int cssH=Math.max(1,(int)Math.round(mmH*96.0/25.4));
                    final int pdfW=Math.max(1,(int)Math.round(mmW*72.0/25.4));
                    final int pdfH=Math.max(1,(int)Math.round(mmH*72.0/25.4));

                    final double mt=Math.max(0,cfg.optDouble("marginTop",0));
                    final double mb=Math.max(0,cfg.optDouble("marginBottom",0));
                    final double ml=Math.max(0,cfg.optDouble("marginLeft",0));
                    final double mr=Math.max(0,cfg.optDouble("marginRight",0));

                    contentRoot.addView(w,new ViewGroup.LayoutParams(cssW,cssH));
                    w.setAlpha(1.0f);
                    // Keep the WebView attached and opaque, but move it outside the visible area.
                    // WebView.draw() respects alpha and a transparent WebView produces blank PDFs.
                    w.setTranslationX(-cssW);

                    WebSettings ws=w.getSettings();
                    ws.setJavaScriptEnabled(true);
                    ws.setDomStorageEnabled(true);
                    ws.setAllowFileAccess(true);
                    ws.setAllowContentAccess(true);
                    ws.setLoadsImagesAutomatically(true);
                    ws.setDefaultTextEncodingName("UTF-8");
                    // Match the proven Prescription renderer. Without the same WebView
                    // viewport/initial-scale configuration, the 210mm bill canvas can be
                    // laid out against the phone's narrow CSS viewport. The resulting PDF
                    // then contains only a clipped slice of the bill (the symptom seen on
                    // the A4 print: tiny/partial text at the right edge).
                    ws.setUseWideViewPort(false);
                    ws.setLoadWithOverviewMode(false);
                    ws.setSupportZoom(false);
                    int densityScale = Math.max(1, Math.round(getResources().getDisplayMetrics().density * 100f));
                    w.setInitialScale(Math.max(25, Math.min(100, Math.round(10000f / densityScale))));
                    w.setBackgroundColor(Color.WHITE);

                    w.setWebViewClient(new WebViewClient(){
                        private boolean pageReady=false;

                        private void renderWhenReady(WebView view){
                            if(finished[0] || pageReady)return;
                            pageReady=true;

                            view.postDelayed(()->{
                                if(finished[0])return;
                                try{
                                    view.measure(
                                            View.MeasureSpec.makeMeasureSpec(cssW,View.MeasureSpec.EXACTLY),
                                            View.MeasureSpec.makeMeasureSpec(cssH,View.MeasureSpec.EXACTLY));
                                    view.layout(0,0,cssW,cssH);

                                    android.graphics.pdf.PdfDocument pdf=new android.graphics.pdf.PdfDocument();
                                    android.graphics.pdf.PdfDocument.PageInfo info=
                                            new android.graphics.pdf.PdfDocument.PageInfo.Builder(pdfW,pdfH,1).create();
                                    android.graphics.pdf.PdfDocument.Page page=pdf.startPage(info);
                                    android.graphics.Canvas canvas=page.getCanvas();
                                    canvas.drawColor(Color.WHITE);
                                    canvas.save();

                                    // The WebView is laid out in CSS pixels (96 px/in) while
                                    // PdfDocument uses points (72 pt/in). This scale preserves
                                    // the selected physical mm dimensions exactly.
                                    canvas.scale((float)pdfW/cssW,(float)pdfH/cssH);
                                    view.draw(canvas);
                                    canvas.restore();
                                    pdf.finishPage(page);

                                    File out=new File(getCacheDir(),"hospital_bill_"+System.nanoTime()+".pdf");
                                    try(FileOutputStream fos=new FileOutputStream(out,false)){
                                        pdf.writeTo(fos);
                                    }
                                    pdf.close();

                                    boolean valid=out.exists()
                                            && out.length()>1500
                                            && isPdfVisuallyBlank(out)==false;

                                    if(!valid){
                                        try{out.delete();}catch(Exception ignored){}
                                        fail.run();
                                        return;
                                    }

                                    byte[] bytes=readBytes(out);
                                    if(bytes==null || bytes.length<=1500
                                            || bytes.length<5
                                            || bytes[0]!='%' || bytes[1]!='P'
                                            || bytes[2]!='D' || bytes[3]!='F'
                                            || bytes[4]!='-'){
                                        try{out.delete();}catch(Exception ignored){}
                                        fail.run();
                                        return;
                                    }

                                    finished[0]=true;
                                    cleanup.run();
                                    try{out.delete();}catch(Exception ignored){}
                                    if(onSuccess!=null)onSuccess.accept(bytes);
                                }catch(Throwable e){
                                    fail.run();
                                }
                            },300);
                        }

                        @Override public void onPageFinished(WebView view,String url){
                            if(finished[0])return;

                            // Wait for fonts and embedded images.  Bills normally contain
                            // text only, but this also protects hospital logos/templates.
                            view.evaluateJavascript(
                                    "(async function(){try{if(document.fonts&&document.fonts.ready)await document.fonts.ready;"+
                                    "var imgs=[...document.images];"+
                                    "await Promise.all(imgs.map(function(i){return i.complete?Promise.resolve():new Promise(function(r){i.onload=i.onerror=r;});}));"+
                                    "return 'READY';}catch(e){return 'READY';}})()",
                                    value->{ if(!finished[0])renderWhenReady(view); });
                        }

                        @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){
                            fail.run();
                            return true;
                        }
                    });

                    String fragment=compactEmbeddedImages(html==null?"":html);

                    // The bill preview and the actual print use the same physical page.
                    // Override the generic .bill-sheet defaults (210x297 + default padding)
                    // so A5/Letter/Legal/custom page settings are respected exactly once.
                    String css=
                            "<style>"+
                            "html,body{margin:0!important;padding:0!important;background:#fff!important;"+
                            "width:"+cssW+"px!important;min-width:"+cssW+"px!important;max-width:"+cssW+"px!important;"+
                            "height:"+cssH+"px!important;min-height:"+cssH+"px!important;max-height:"+cssH+"px!important;overflow:hidden!important;}"+
                            ".bill-sheet{box-sizing:border-box!important;width:"+mmW+"mm!important;"+
                            "height:"+mmH+"mm!important;min-height:"+mmH+"mm!important;max-height:"+mmH+"mm!important;"+
                            "margin:0!important;padding:"+mt+"mm "+mr+"mm "+mb+"mm "+ml+"mm!important;"+
                            "overflow:hidden!important;transform:none!important;transform-origin:top left!important;}"+
                            ".bill-sheet *{box-sizing:border-box;}"+
                            "</style>";

                    String pdfHtml="<!doctype html><html><head><meta charset=\"UTF-8\">"+
                            "<meta name=\"viewport\" content=\"width="+cssW+", initial-scale=1, maximum-scale=1, user-scalable=no\">"+
                            "<link rel=\"stylesheet\" href=\"styles.css\">"+css+
                            "</head><body>"+fragment+"</body></html>";

                    w.loadDataWithBaseURL("file:///android_asset/",pdfHtml,"text/html","UTF-8",null);
                }catch(Throwable setupError){
                    fail.run();
                }
            });
        }

        @JavascriptInterface public void backup(){new Thread(()->{try{File out=BackupManager.createLocalBackup(MainActivity.this,true);runOnUiThread(()->{shareFile(out,"application/zip","Siddiq Clinic backup");alert("Backup created","Backup saved to the selected Local Backup folder:\n"+out.getName());});}catch(Exception e){runOnUiThread(()->alert("Backup error",e.toString()));}}).start();}
        @JavascriptInterface public void createBackupNow(){new Thread(()->{try{File out=BackupManager.createLocalBackup(MainActivity.this,true);runOnUiThread(()->alert("Backup created","Backup saved locally:\n"+out.getName()));}catch(Exception e){runOnUiThread(()->alert("Backup error",e.toString()));}}).start();}
        @JavascriptInterface public void cloudBackupNow(){new Thread(()->{try{BackupManager.syncLastLocalBackupToDrive(MainActivity.this);runOnUiThread(()->alert("Cloud backup complete","The latest successful local backup has been uploaded to Google Drive."));}catch(Exception e){runOnUiThread(()->alert("Cloud backup error",e.toString()));}}).start();}
        @JavascriptInterface public String backupStatus(){return BackupManager.status(MainActivity.this).toString();}
        @JavascriptInterface public void saveBackupSettings(boolean liveEnabled,boolean localEnabled,int localHours,boolean cloudEnabled,int cloudHours,int localRetention,int cloudRetention){BackupManager.saveSettings(MainActivity.this,liveEnabled,localEnabled,localHours,cloudEnabled,cloudHours,localRetention,cloudRetention);runOnUiThread(()->toast("Backup settings saved"));}
        @JavascriptInterface public void connectGoogleDrive(){
            try{
                GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .requestScopes(new Scope(GOOGLE_DRIVE_SCOPE))
                        .build();
                Intent signInIntent=GoogleSignIn.getClient(MainActivity.this,gso).getSignInIntent();
                Log.d(GOOGLE_AUTH_TAG,"Starting Google Drive authorization. package="+getPackageName()+" scope="+GOOGLE_DRIVE_SCOPE);
                startActivityForResult(signInIntent,CONNECT_GOOGLE_DRIVE);
            }catch(Exception e){
                Log.e(GOOGLE_AUTH_TAG,"Unable to start Google authorization",e);
                alert("Google Drive","Unable to start Google authorization:\n\n"+e);
            }
        }
        @JavascriptInterface public void chooseLocalBackupFolder(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_LOCAL_BACKUP_FOLDER);}catch(Exception e){alert("Local backup folder","Unable to open folder picker: "+e);}}
        @JavascriptInterface public void clearLocalBackupFolder(){BackupManager.clearLocalBackupTreeUri(MainActivity.this);runOnUiThread(()->toast("Local Backup folder cleared. No external local backup will be written."));}
        @JavascriptInterface public void chooseLiveBackupFolder(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_LIVE_BACKUP_FOLDER);}catch(Exception e){alert("Live Backup folder","Unable to open folder picker: "+e);}}
        @JavascriptInterface public void clearLiveBackupFolder(){BackupManager.clearLiveTreeUri(MainActivity.this);runOnUiThread(()->toast("Live Backup folder cleared. Live synchronization is stopped."));}
        @JavascriptInterface public void disconnectGoogleDrive(){try{GoogleSignIn.getClient(MainActivity.this,GoogleSignInOptions.DEFAULT_SIGN_IN).signOut();}catch(Exception ignored){} BackupManager.clearGoogleAccount(MainActivity.this);runOnUiThread(()->toast("Google Drive disconnected"));}
        @JavascriptInterface public void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,RESTORE_DB);}
        @JavascriptInterface public void exportCsv(String fileName,String csv){try{File f=new File(getExternalFilesDir(null),safe(fileName,"report.csv"));try(FileOutputStream o=new FileOutputStream(f)){o.write(csv.getBytes(StandardCharsets.UTF_8));}shareFile(f,"text/csv","Export report");}catch(Exception e){alert("Export error",e.toString());}}
        @JavascriptInterface public void exportXlsx(String fileName,String payload){try{JSONObject data=new JSONObject(payload);JSONArray headers=data.getJSONArray("headers"), rows=data.getJSONArray("rows");File f=new File(getExternalFilesDir(null),safe(fileName,"report.xlsx"));writeXlsx(f,headers,rows);shareFile(f,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Export Excel");}catch(Exception e){alert("Export error",e.toString());}}
        private String safe(String f,String def){if(f==null||f.trim().isEmpty())return def;return f.replaceAll("[^A-Za-z0-9._-]","_");}
        private String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
        private void shareFile(File f,String type,String chooser){Uri u=FileProvider.getUriForFile(MainActivity.this,"com.hospital.app.fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,chooser));}
    }

    /** Simple pinch/double-tap zoomable PDF page used by View Patient Prescription. */
    private static class ZoomImageView extends ImageView {
        private final Matrix matrix=new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private final PointF last=new PointF();
        private float scale=1f;
        private boolean dragging=false;
        ZoomImageView(Context context){
            super(context);
            setScaleType(ScaleType.MATRIX);
            scaleDetector=new ScaleGestureDetector(context,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScale(ScaleGestureDetector d){
                    float factor=d.getScaleFactor();
                    float next=Math.max(1f,Math.min(5f,scale*factor));
                    factor=next/scale;
                    scale=next;
                    matrix.postScale(factor,factor,d.getFocusX(),d.getFocusY());
                    setImageMatrix(matrix);
                    getParent().requestDisallowInterceptTouchEvent(scale>1.01f);
                    return true;
                }
                @Override public void onScaleEnd(ScaleGestureDetector d){getParent().requestDisallowInterceptTouchEvent(scale>1.01f);}
            });
            setOnTouchListener((v,event)->{
                scaleDetector.onTouchEvent(event);
                switch(event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        last.set(event.getX(),event.getY());
                        dragging=scale>1.01f;
                        getParent().requestDisallowInterceptTouchEvent(dragging);
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if(dragging&&!scaleDetector.isInProgress()){
                            float dx=event.getX()-last.x,dy=event.getY()-last.y;
                            matrix.postTranslate(dx,dy);
                            setImageMatrix(matrix);
                            last.set(event.getX(),event.getY());
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging=false;
                        getParent().requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return true;
            });
            setOnClickListener(v->{});
            setOnDoubleClickListener();
        }
        private void setOnDoubleClickListener(){
            final long[] lastTap={0};
            setOnTouchListener((v,event)->{
                scaleDetector.onTouchEvent(event);
                switch(event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        long now=System.currentTimeMillis();
                        if(now-lastTap[0]<300){
                            scale=scale>1.01f?1f:2.5f;
                            matrix.reset();
                            if(scale>1.01f)matrix.postScale(scale,scale,event.getX(),event.getY());
                            setImageMatrix(matrix);
                        }
                        lastTap[0]=now;
                        last.set(event.getX(),event.getY());
                        dragging=scale>1.01f;
                        getParent().requestDisallowInterceptTouchEvent(dragging);
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if(dragging&&!scaleDetector.isInProgress()){
                            float dx=event.getX()-last.x,dy=event.getY()-last.y;
                            matrix.postTranslate(dx,dy); setImageMatrix(matrix); last.set(event.getX(),event.getY());
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging=false; getParent().requestDisallowInterceptTouchEvent(false); break;
                }
                return true;
            });
        }
    }

    private String googleAuthStatusText(int code){
        switch(code){
            case 10: return "Google OAuth is misconfigured (DEVELOPER_ERROR). The Android OAuth client must use this exact package name and the SHA-1 of the certificate that signed this APK.";
            case 7: return "Google authorization could not connect to the network (NETWORK_ERROR). Check Internet access and Google Play services.";
            case 16: return "Google authorization was cancelled by the client or Google Play services.";
            case 12501: return "Google Sign-In reported that the sign-in/consent flow was cancelled. If you selected an account and did not cancel, check the Android OAuth package name and signing SHA-1.";
            case 12502: return "Another Google Sign-In flow is already in progress. Wait a moment and try again.";
            default: return "Google authorization returned an unexpected status.";
        }
    }

    private String getSigningSha1(){
        try{
            android.content.pm.PackageManager pm=getPackageManager();
            android.content.pm.PackageInfo pi;
            if(Build.VERSION.SDK_INT>=28){
                pi=pm.getPackageInfo(getPackageName(),android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
                android.content.pm.Signature[] sigs=pi.signingInfo.hasMultipleSigners()?pi.signingInfo.getApkContentsSigners():pi.signingInfo.getSigningCertificateHistory();
                if(sigs!=null&&sigs.length>0){
                    MessageDigest md=MessageDigest.getInstance("SHA-1");
                    byte[] d=md.digest(sigs[0].toByteArray());
                    StringBuilder b=new StringBuilder();
                    for(int i=0;i<d.length;i++){if(i>0)b.append(':');b.append(String.format(Locale.US,"%02X",d[i]&0xFF));}
                    return b.toString();
                }
            }else{
                pi=pm.getPackageInfo(getPackageName(),android.content.pm.PackageManager.GET_SIGNATURES);
                if(pi.signatures!=null&&pi.signatures.length>0){
                    MessageDigest md=MessageDigest.getInstance("SHA-1");
                    byte[] d=md.digest(pi.signatures[0].toByteArray());
                    StringBuilder b=new StringBuilder();
                    for(int i=0;i<d.length;i++){if(i>0)b.append(':');b.append(String.format(Locale.US,"%02X",d[i]&0xFF));}
                    return b.toString();
                }
            }
        }catch(Exception e){Log.e(GOOGLE_AUTH_TAG,"Unable to read signing SHA-1",e);}
        return "Unavailable";
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_HOSPITAL_LOGO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                Uri u=data.getData();
                InputStream in=getContentResolver().openInputStream(u);
                Bitmap src=BitmapFactory.decodeStream(in);
                if(in!=null)in.close();
                if(src==null)throw new IOException("Selected file is not a valid image");
                int max=640;
                float scale=Math.min(1f,Math.min((float)max/src.getWidth(),(float)max/src.getHeight()));
                Bitmap bmp=scale<1f?Bitmap.createScaledBitmap(src,Math.max(1,Math.round(src.getWidth()*scale)),Math.max(1,Math.round(src.getHeight()*scale)),true):src;
                ByteArrayOutputStream bout=new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG,100,bout);
                String dataUrl="data:image/png;base64,"+Base64.encodeToString(bout.toByteArray(),Base64.NO_WRAP);
                if(bmp!=src)bmp.recycle();
                if(src!=bmp)src.recycle();
                String safeJs=JSONObject.quote(dataUrl);
                webView.post(()->webView.evaluateJavascript("window.receiveHospitalLogo("+safeJs+")",null));
            }catch(Exception e){new AlertDialog.Builder(this).setTitle("Hospital Logo").setMessage("Unable to load logo: "+e).setPositiveButton("OK",null).show();}
            return;
        }
        if(requestCode==CONNECT_GOOGLE_DRIVE){
            // Do not treat every non-OK Activity result as a user cancellation. Google Sign-In
            // can return a detailed status inside the Intent even when Android reports RESULT_CANCELED.
            // The previous implementation hid those details, making OAuth configuration errors look
            // like a simple cancellation after the user selected an account.
            if(data!=null){
                try{
                    GoogleSignInAccount account=GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                    if(account!=null){
                        BackupManager.setGoogleAccount(this,account);
                        webView.post(()->webView.evaluateJavascript("if(window.backupRestore){backupRestore();}",null));
                        new AlertDialog.Builder(this).setTitle("Google Drive connected")
                                .setMessage("Google Account: "+account.getEmail()+"\n\nGoogle Drive is now connected. Cloud backup will use the latest successful Local Backup ZIP. Use BACKUP NOW TO CLOUD to upload it.")
                                .setPositiveButton("OK",null).show();
                        return;
                    }
                }catch(ApiException e){
                    int code=e.getStatusCode();
                    Log.e(GOOGLE_AUTH_TAG,"Google authorization failed. resultCode="+resultCode+" statusCode="+code,e);
                    String detail=googleAuthStatusText(code);
                    String extra=e.getMessage()==null?"":e.getMessage();
                    new AlertDialog.Builder(this).setTitle("Google Drive connection failed")
                            .setMessage(detail+"\n\nGoogle status code: "+code+"\nAndroid result code: "+resultCode+"\n"+extra+"\n\nPackage: "+getPackageName()+"\nSigning SHA-1: "+getSigningSha1())
                            .setPositiveButton("OK",null).show();
                    return;
                }catch(Exception e){
                    Log.e(GOOGLE_AUTH_TAG,"Unexpected Google authorization result",e);
                    new AlertDialog.Builder(this).setTitle("Google Drive connection failed")
                            .setMessage("Unexpected Google authorization result.\n\n"+e+"\n\nAndroid result code: "+resultCode+"\nPackage: "+getPackageName()+"\nSigning SHA-1: "+getSigningSha1())
                            .setPositiveButton("OK",null).show();
                    return;
                }
            }
            if(resultCode==RESULT_CANCELED){
                new AlertDialog.Builder(this).setTitle("Google Drive connection cancelled")
                        .setMessage("Google returned no authorization result. If you selected an account and were returned here, this is not necessarily a user cancellation.\n\nPackage: "+getPackageName()+"\nSigning SHA-1: "+getSigningSha1()+"\n\nIf the next attempt shows error 10, add this package name and SHA-1 to the Android OAuth client in Google Cloud Console.")
                        .setPositiveButton("OK",null).show();
            }else{
                new AlertDialog.Builder(this).setTitle("Google Drive connection failed")
                        .setMessage("No Google authorization data was returned. Android result code: "+resultCode+"\n\nPackage: "+getPackageName()+"\nSigning SHA-1: "+getSigningSha1())
                        .setPositiveButton("OK",null).show();
            }
            return;
        }
        if(requestCode==PICK_LOCAL_BACKUP_FOLDER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){try{BackupManager.setLocalBackupTreeUri(this,data.getData());new AlertDialog.Builder(this).setTitle("Local Backup folder").setMessage("The selected folder will be used only for Local Backup ZIP files. Live Backup uses a separate folder.").setPositiveButton("OK",null).show();webView.post(()->webView.evaluateJavascript("if(window.backupRestore){backupRestore();}",null));}catch(Exception e){new AlertDialog.Builder(this).setTitle("Local Backup folder").setMessage("Unable to save selected folder: "+e).setPositiveButton("OK",null).show();}}
        if(requestCode==PICK_LIVE_BACKUP_FOLDER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){try{BackupManager.setLiveTreeUri(this,data.getData());new AlertDialog.Builder(this).setTitle("Live Backup folder").setMessage("Live Backup folder selected. Turn Live Backup ON to create the hospital _appdata folder and start synchronization.").setPositiveButton("OK",null).show();webView.post(()->webView.evaluateJavascript("if(window.backupRestore){backupRestore();}",null));}catch(Exception e){new AlertDialog.Builder(this).setTitle("Live Backup folder").setMessage("Unable to save selected folder: "+e).setPositiveButton("OK",null).show();}}
        if(requestCode==RESTORE_DB&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            new Thread(()->{try{Uri u=data.getData();InputStream in=getContentResolver().openInputStream(u);if(in==null)throw new IOException("Unable to open selected backup");JSONObject result;try{result=BackupManager.restoreZip(this,in);}finally{try{in.close();}catch(Exception ignored){}}final JSONObject rr=result;runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Restore complete").setMessage("Backup version: v"+rr.optInt("backupVersion")+"\nCurrent version: v"+rr.optInt("currentVersion")+(rr.optBoolean("migrated")?"\n\nOlder backup detected. Database migration/schema upgrade will run when the application reloads.":"\n\nBackup version matches the application.")+"\n\nA safety backup was created before restore.").setPositiveButton("RELOAD",(x,w)->webView.reload()).show());}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Restore error").setMessage(e.toString()).setPositiveButton("OK",null).show());}}).start();
        }
    }

    private static void copyFile(File a,File b)throws IOException{try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){byte[]z=new byte[8192];int n;while((n=in.read(z))>0)out.write(z,0,n);}}

    private static String esc(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private void writeEntry(ZipOutputStream z,String path,String body)throws IOException{z.putNextEntry(new ZipEntry(path));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private void writeXlsx(File file,JSONArray headers,JSONArray rows)throws Exception{
        StringBuilder sheet=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        int r=1; sheet.append("<row r=\"1\">"); for(int c=0;c<headers.length();c++)sheet.append(cell(c+1,r,headers.optString(c))); sheet.append("</row>");
        for(int i=0;i<rows.length();i++){r++;JSONArray row=rows.getJSONArray(i);sheet.append("<row r=\""+r+"\">");for(int c=0;c<row.length();c++)sheet.append(cell(c+1,r,row.optString(c,"")));sheet.append("</row>");}
        sheet.append("</sheetData></worksheet>");
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(file))){
            writeEntry(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
            writeEntry(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            writeEntry(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Report\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            writeEntry(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
            writeEntry(z,"xl/worksheets/sheet1.xml",sheet.toString());
        }
    }
    private String cell(int col,int row,String val){StringBuilder ref=new StringBuilder();int n=col;while(n>0){int rem=(n-1)%26;ref.insert(0,(char)('A'+rem));n=(n-1)/26;}ref.append(row);return "<c r=\""+ref+"\" t=\"inlineStr\"><is><t>"+esc(val)+"</t></is></c>";}
}
