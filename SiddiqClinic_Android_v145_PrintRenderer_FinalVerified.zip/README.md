# Hospital Management Android V145

Package: `com.hospital.app`

## V145 bill printing fix

OPD, LAB and CHECKOUT PC-print PDFs now use the same proven PDF rendering mechanism as the working Prescription renderer:

`WebView -> PdfDocument -> WebView.draw(Canvas) -> PDF -> validation -> PC`

The V144 `createPrintDocumentAdapter()` bill path has been removed from the PC bill-print renderer because it could produce a valid-looking but visually blank PDF on some devices.

The renderer:
- waits for WebView page completion, fonts and images;
- uses CSS pixels at 96 CSS px/in;
- uses PDF points at 72 pt/in;
- converts the configured physical mm page size exactly once;
- applies configured margins once;
- validates the PDF header and visually renders page 1 with PdfRenderer before sending it to the PC;
- rejects a blank PDF instead of sending it to the PC.

Prescription printing code is retained as the reference implementation because it is already proven to work.

Version: 145.0 / versionCode 145.
