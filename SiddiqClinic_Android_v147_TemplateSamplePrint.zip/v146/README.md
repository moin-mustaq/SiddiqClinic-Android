# Hospital Management Android V147

Package: `com.hospital.app`

## V147 Template Sample Print

Added **PRINT SAMPLE** to the Bill Templates and Prescription Templates screens.

- OPD, LAB and CHECKOUT: the button prints a sample using the **currently edited template draft**, so changes can be checked before saving.
- Prescription: the button prints a sample using the **currently edited prescription template draft**.
- Sample data is dummy data and does not create or modify patient/bill records.
- The sample uses the same template renderer and page settings used by the real print path.
- The button is available for each OPD/LAB/Checkout template type and on the Prescription Templates screen.
- `com.hospital.app` remains the fixed generic package name.

Previous V146 A4 centered bill-width changes are retained.

Version: 147.0 / versionCode 147.
