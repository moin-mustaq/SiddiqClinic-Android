import http.server
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

PORT = 5015
SERVICE_TYPE = "_siddiqprint._tcp.local."
SERVICE_NAME = "Siddiq Print Server._siddiqprint._tcp.local."
BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.json"

try:
    import win32print
    import win32ui
    from PIL import Image, ImageWin
    import fitz
    from zeroconf import Zeroconf, ServiceInfo
except ImportError as exc:
    print("Missing dependency:", exc)
    print("Run install.bat first.")
    raise


def load_config():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"printer": "", "port": PORT}


def save_config(cfg):
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def printers():
    flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    return [p[2] for p in win32print.EnumPrinters(flags)]


def default_printer():
    try:
        return win32print.GetDefaultPrinter()
    except Exception:
        return ""


def local_ip():
    # UDP connect discovers the LAN interface without sending traffic.
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"
    finally:
        s.close()


def print_pdf(pdf_path, printer):
    printer = printer or default_printer()
    if not printer:
        raise RuntimeError("No Windows printer is installed/default printer is not available.")

    doc = fitz.open(pdf_path)
    try:
        for page_index in range(len(doc)):
            page = doc[page_index]
            pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            dc = win32ui.CreateDC()
            try:
                dc.CreatePrinterDC(printer)
                printable_w = dc.GetDeviceCaps(8)   # HORZRES
                printable_h = dc.GetDeviceCaps(10)  # VERTRES
                dc.StartDoc("Siddiq Clinic")
                try:
                    dc.StartPage()
                    scale = min(printable_w / img.width, printable_h / img.height)
                    draw_w = max(1, int(img.width * scale))
                    draw_h = max(1, int(img.height * scale))
                    # Center the rendered page in the printer's printable area.
                    x = max(0, (printable_w - draw_w) // 2)
                    y = max(0, (printable_h - draw_h) // 2)
                    dib = ImageWin.Dib(img)
                    dib.draw(dc.GetHandleOutput(), (x, y, x + draw_w, y + draw_h))
                    dc.EndPage()
                finally:
                    dc.EndDoc()
            finally:
                dc.DeleteDC()
    finally:
        doc.close()


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "SiddiqPrintServer/1.0"

    def _send(self, code=200, payload=None, content_type="application/json"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload or {"ok": True}).encode()
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST,GET,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,X-Printer")
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            self._send(payload={"ok": True, "server": "Siddiq Print Server", "printer": default_printer(), "printers": printers()})
        elif self.path == "/printers":
            self._send(payload={"ok": True, "printers": printers(), "default": default_printer()})
        elif self.path == "/test":
            self._send(payload={"ok": True, "message": "Use POST /test from the Android app."})
        else:
            self._send(404, {"ok": False, "error": "Not found"})

    def do_POST(self):
        try:
            if self.path == "/test":
                # Generate a one-page PDF and print it.
                import fitz
                doc = fitz.open()
                page = doc.new_page(width=595, height=842)
                page.insert_text((70, 90), "SIDDIQ CLINIC - TEST PRINT", fontsize=20)
                page.insert_text((70, 130), "Android -> Wi-Fi -> PC -> USB Printer", fontsize=12)
                page.insert_text((70, 160), "Automatic PC discovery is working.", fontsize=12)
                fd, name = tempfile.mkstemp(suffix=".pdf")
                os.close(fd)
                doc.save(name)
                doc.close()
                try:
                    print_pdf(name, self.headers.get("X-Printer", ""))
                finally:
                    try: os.remove(name)
                    except OSError: pass
                self._send(payload={"ok": True, "message": "Test page printed", "printer": default_printer()})
                return

            if self.path != "/print":
                self._send(404, {"ok": False, "error": "Not found"})
                return

            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 30 * 1024 * 1024:
                raise RuntimeError("Invalid PDF size")
            data = self.rfile.read(length)
            if not data.startswith(b"%PDF"):
                raise RuntimeError("Request is not a PDF")
            fd, name = tempfile.mkstemp(prefix="siddiq_print_", suffix=".pdf")
            os.close(fd)
            Path(name).write_bytes(data)
            try:
                print_pdf(name, self.headers.get("X-Printer", ""))
            finally:
                try: os.remove(name)
                except OSError: pass
            self._send(payload={"ok": True, "message": "Print job completed", "printer": default_printer()})
        except Exception as exc:
            self._send(500, {"ok": False, "error": str(exc)})

    def log_message(self, fmt, *args):
        print("[HTTP]", fmt % args)


class PrintServerApp:
    def __init__(self):
        self.cfg = load_config()
        self.port = int(self.cfg.get("port", PORT))
        self.httpd = None
        self.http_thread = None
        self.zeroconf = None
        self.service_info = None
        self.root = tk.Tk()
        self.root.title("Siddiq Clinic - PC Print Server")
        self.root.geometry("520x300")
        self.root.resizable(False, False)
        self.status = tk.StringVar(value="Starting...")
        self.ip = tk.StringVar(value=local_ip())
        self.printer = tk.StringVar(value=self.cfg.get("printer") or default_printer())
        self.build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.start()

    def build_ui(self):
        pad = {"padx": 14, "pady": 7}
        ttk.Label(self.root, text="SIDDIQ CLINIC PC PRINT SERVER", font=("Segoe UI", 16, "bold")).pack(pady=(14, 8))
        ttk.Label(self.root, text="Android devices on the same Wi-Fi can print to the USB printer through this PC.").pack()
        frame = ttk.Frame(self.root); frame.pack(fill="x", padx=18, pady=14)
        ttk.Label(frame, text="PC address:").grid(row=0,column=0,sticky="w",**pad)
        ttk.Label(frame, textvariable=self.ip).grid(row=0,column=1,sticky="w",**pad)
        ttk.Label(frame, text="Port:").grid(row=1,column=0,sticky="w",**pad)
        ttk.Label(frame, text=str(self.port)).grid(row=1,column=1,sticky="w",**pad)
        ttk.Label(frame, text="Printer:").grid(row=2,column=0,sticky="w",**pad)
        self.combo=ttk.Combobox(frame,textvariable=self.printer,values=printers(),state="readonly",width=42)
        self.combo.grid(row=2,column=1,sticky="w",**pad)
        ttk.Button(frame,text="Refresh Printers",command=self.refresh).grid(row=3,column=1,sticky="w",**pad)
        ttk.Label(self.root,textvariable=self.status,foreground="#176b3a").pack(pady=6)
        ttk.Button(self.root,text="TEST PRINT",command=self.test_print).pack(pady=4)
        ttk.Label(self.root,text="Keep this program running while the clinic needs PC printing.").pack(pady=5)

    def refresh(self):
        ps=printers();self.combo["values"]=ps
        if self.printer.get() not in ps:self.printer.set(default_printer() or (ps[0] if ps else ""))
        self.cfg["printer"]=self.printer.get();save_config(self.cfg)
        self.status.set(f"Ready - {self.printer.get() or 'No printer selected'}")

    def start(self):
        try:
            self.httpd=http.server.ThreadingHTTPServer(("0.0.0.0",self.port),Handler)
            self.http_thread=threading.Thread(target=self.httpd.serve_forever,daemon=True);self.http_thread.start()
            self.register_mdns()
            self.status.set(f"RUNNING - {self.printer.get() or default_printer() or 'No printer'}")
        except Exception as exc:
            self.status.set("ERROR: "+str(exc))
            messagebox.showerror("Siddiq Print Server",str(exc))

    def register_mdns(self):
        self.zeroconf=Zeroconf()
        addr=socket.inet_aton(local_ip())
        self.service_info=ServiceInfo(SERVICE_TYPE,SERVICE_NAME,addresses=[addr],port=self.port,properties={b"path":b"/",b"app":b"Siddiq Clinic",b"version":b"125"},server="siddiq-print.local.")
        self.zeroconf.register_service(self.service_info)

    def test_print(self):
        try:
            import requests
            r=requests.post(f"http://127.0.0.1:{self.port}/test",headers={"X-Printer":self.printer.get()},timeout=15)
            if r.ok: messagebox.showinfo("Test Print","Test page sent to the printer.")
            else: messagebox.showerror("Test Print",r.text)
        except Exception as exc: messagebox.showerror("Test Print",str(exc))

    def close(self):
        try:
            if self.service_info and self.zeroconf:self.zeroconf.unregister_service(self.service_info);self.zeroconf.close()
        except Exception: pass
        try:
            if self.httpd:self.httpd.shutdown();self.httpd.server_close()
        except Exception: pass
        self.root.destroy()

if __name__ == "__main__":
    PrintServerApp().root.mainloop()
