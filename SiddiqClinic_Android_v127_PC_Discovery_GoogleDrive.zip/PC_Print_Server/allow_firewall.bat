@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Please right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
netsh advfirewall firewall add rule name="Siddiq Clinic Print Server TCP" dir=in action=allow protocol=TCP localport=5015 profile=private
netsh advfirewall firewall add rule name="Siddiq Clinic Print Server mDNS" dir=in action=allow protocol=UDP localport=5353 profile=private
echo Firewall rules added for the Windows Private network.
pause
