@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo Siddiq Clinic PC Print Server - Installation
echo ==============================================
where py >nul 2>nul
if %errorlevel% neq 0 (
  where python >nul 2>nul
  if %errorlevel% neq 0 (
    echo Python is not installed.
    echo Install Python 3.11 or newer from https://www.python.org/downloads/windows/
    echo IMPORTANT: enable "Add python.exe to PATH" during installation.
    pause
    exit /b 1
  )
  set PY=python
) else (
  set PY=py -3
)
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
  echo Installation failed.
  pause
  exit /b 1
)
echo.
echo Installation completed successfully.
echo Run start_server.bat to start the print server.
pause
