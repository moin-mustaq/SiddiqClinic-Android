@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 SiddiqPrintServer.py
) else (
  python SiddiqPrintServer.py
)
pause
