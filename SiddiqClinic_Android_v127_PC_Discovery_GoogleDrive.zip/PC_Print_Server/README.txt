SIDDIQ CLINIC - PC NETWORK PRINT SERVER
========================================

Purpose
-------
This program allows Siddiq Clinic Android to print to a normal USB/non-Wi-Fi
printer connected to a Windows PC. Android and PC must be on the same Wi-Fi.
The Android app discovers the PC automatically using mDNS, so the PC IP address
does not need to be entered or updated when the router changes it.

FIRST-TIME INSTALLATION
-----------------------
1. Make sure the USB printer is installed in Windows and can print a Windows
   test page. Set it as the Windows default printer if possible.
2. Install Python 3.11 or newer on the Windows PC if it is not already installed.
   During Python installation, enable "Add python.exe to PATH".
3. Double-click install.bat.
4. After installation, double-click start_server.bat.
5. Windows Firewall may ask for permission. Allow the program on PRIVATE networks.
   Do not expose this service to the Public/Internet network.
6. The Siddiq Print Server window should show RUNNING and the printer name.
7. Click TEST PRINT in the server window. A test page should print.

ANDROID SETUP
-------------
1. Put the Android phone and the PC on the same Wi-Fi network.
2. Open Siddiq Clinic -> Backup & Restore -> PC NETWORK PRINTER.
3. Set PC Printer Mode = Enabled.
4. Tap FIND PC.
5. The app should show the PC address and Connected status.
6. Tap TEST PRINT.
7. If the paper prints, the connection is working.

NORMAL USE
----------
Once PC Printer Mode is enabled, existing Siddiq Clinic PRINT and SAVE & PRINT
operations send the generated A4 PDF to the PC print server. The PC prints it
using the selected Windows printer.

IP ADDRESS CHANGES
------------------
Do not change anything in the Android app. If the router gives the PC a new IP,
Siddiq Clinic automatically searches for the print server again when the old
address cannot be reached.

SECURITY
--------
The print server is intended for the private clinic Wi-Fi only. It is an HTTP
local-network service and should not be port-forwarded to the Internet.

TROUBLESHOOTING
---------------
- PC not found: make sure start_server.bat is running, both devices use the same
  Wi-Fi, and Windows Firewall allows the program on Private networks.
- Test print fails: print a Windows test page first and verify the printer is
  online/default. Refresh Printers in the server window.
- If the PC changes Wi-Fi networks, tap FIND PC again once.
