package com.siddiqclinic.android;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.*;

/**
 * Backup architecture v124:
 *  - Application private storage is always the primary working data.
 *  - Live Backup is completely optional and uses a separately selected folder.
 *  - Local Backup is completely separate from Live Backup and uses its own folder.
 *  - No external folder is touched when the corresponding option is disabled or unset.
 */
public final class BackupManager {
    public static final int APP_VERSION = 127;
    public static final int BACKUP_FORMAT_VERSION = 2;
    private static final String PREF = "backup_settings";

    private static final String KEY_LIVE_ENABLED = "live_enabled";
    private static final String KEY_LIVE_TREE_URI = "live_tree_uri";
    private static final String KEY_LIVE_ROOT_NAME = "live_root_name";

    private static final String KEY_LOCAL_ENABLED = "local_enabled";
    private static final String KEY_LOCAL_HOURS = "local_hours";
    private static final String KEY_LOCAL_RETENTION = "local_retention";
    private static final String KEY_LOCAL_TREE_URI = "local_backup_tree_uri";
    private static final String KEY_LOCAL_ROOT_NAME = "local_backup_root_name";

    private static final String KEY_CLOUD_ENABLED = "cloud_enabled";
    private static final String KEY_CLOUD_HOURS = "cloud_hours";
    private static final String KEY_CLOUD_RETENTION = "cloud_retention";
    private static final String KEY_TREE_URI = "cloud_tree_uri";
    private static final String KEY_LAST_LOCAL = "last_local_ms";
    private static final String KEY_LAST_CLOUD = "last_cloud_ms";
    private static final String KEY_GOOGLE_EMAIL = "google_email";
    private static final String KEY_GOOGLE_ROOT_ID = "google_root_id";

    // v123 used local_tree_uri for the live-data folder. Migrate that setting once.
    private static final String LEGACY_LOCAL_TREE_URI = "local_tree_uri";

    private static final ScheduledExecutorService LIVE_EXECUTOR = Executors.newSingleThreadScheduledExecutor();
    private static ScheduledFuture<?> liveMirrorFuture;
    private static final Object LIVE_LOCK = new Object();

    private BackupManager() {}
    static SharedPreferences prefs(Context c){ migrateLegacyPrefs(c); return c.getSharedPreferences(PREF,Context.MODE_PRIVATE); }

    private static void migrateLegacyPrefs(Context c){
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String old=p.getString(LEGACY_LOCAL_TREE_URI,"");
        String live=p.getString(KEY_LIVE_TREE_URI,"");
        if(!old.isEmpty() && live.isEmpty()){
            p.edit()
                .putString(KEY_LIVE_TREE_URI,old)
                .putBoolean(KEY_LIVE_ENABLED,true)
                .remove(LEGACY_LOCAL_TREE_URI)
                // v123's local_enabled meant internal/app-storage backup. It must not
                // silently become external Local Backup in v124.
                .putBoolean(KEY_LOCAL_ENABLED,false)
                .apply();
        }
    }

    public static String hospitalName(Context c){
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READONLY)){
            Cursor cur=d.rawQuery("SELECT hospital_name FROM hospital_profile WHERE profile_id=1 LIMIT 1",null);
            String s="SIDDIQ HOSPITAL"; if(cur.moveToFirst()) s=cur.getString(0); cur.close();
            return s==null||s.trim().isEmpty()?"SIDDIQ HOSPITAL":s.trim();
        }catch(Exception e){return "SIDDIQ HOSPITAL";}
    }
    public static String safeHospital(String s){
        s=s==null?"":s.replaceAll("\\s+","").replaceAll("[^A-Za-z0-9._&-]","");
        return s.isEmpty()?"Hospital":s;
    }
    private static int databaseVersion(File db)throws Exception{
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READONLY)){
            Cursor c=d.rawQuery("PRAGMA user_version",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}
        }
    }
    public static String today(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    public static String fileName(Context c){return safeHospital(hospitalName(c))+"_"+APP_VERSION+"_"+today()+".zip";}

    public static JSONObject status(Context c){
        JSONObject o=new JSONObject();
        try{
            SharedPreferences p=prefs(c);
            Uri live=liveTreeUri(c), local=localBackupTreeUri(c), cloud=treeUri(c);
            boolean liveEnabled=p.getBoolean(KEY_LIVE_ENABLED,false);
            boolean localEnabled=p.getBoolean(KEY_LOCAL_ENABLED,false);
            o.put("liveEnabled",liveEnabled);
            o.put("liveFolderSet",live!=null);
            o.put("liveFolderUri",live==null?"":live.toString());
            o.put("localEnabled",localEnabled);
            o.put("localFolderSet",local!=null);
            o.put("localFolderUri",local==null?"":local.toString());
            o.put("localHours",p.getInt(KEY_LOCAL_HOURS,6));
            o.put("localRetention",p.getInt(KEY_LOCAL_RETENTION,30));
            o.put("cloudEnabled",p.getBoolean(KEY_CLOUD_ENABLED,false));
            o.put("cloudHours",p.getInt(KEY_CLOUD_HOURS,6));
            o.put("cloudRetention",p.getInt(KEY_CLOUD_RETENTION,30));
            o.put("cloudConnected",isGoogleDriveConnected(c));
            o.put("cloudAccount",p.getString(KEY_GOOGLE_EMAIL,""));
            o.put("hospitalName",hospitalName(c));
            o.put("safeHospitalName",safeHospital(hospitalName(c)));
            o.put("todayFile",fileName(c));
            DocumentFile today=findTodayLocalBackup(c);
            o.put("localFileExists",today!=null&&today.isFile());
            o.put("localFileSize",today!=null&&today.isFile()?today.length():0);
            o.put("lastLocalMs",p.getLong(KEY_LAST_LOCAL,0));
            o.put("lastCloudMs",p.getLong(KEY_LAST_CLOUD,0));
        }catch(Exception ignored){}
        return o;
    }

    public static void saveSettings(Context c, boolean liveEnabled, boolean localEnabled,int localHours,
                                     boolean cloudEnabled,int cloudHours,int localRetention,int cloudRetention){
        localHours=Math.max(1,Math.min(168,localHours));
        cloudHours=Math.max(1,Math.min(168,cloudHours));
        localRetention=Math.max(1,Math.min(365,localRetention));
        cloudRetention=Math.max(1,Math.min(365,cloudRetention));
        prefs(c).edit()
            .putBoolean(KEY_LIVE_ENABLED,liveEnabled)
            .putBoolean(KEY_LOCAL_ENABLED,localEnabled)
            .putInt(KEY_LOCAL_HOURS,localHours)
            .putBoolean(KEY_CLOUD_ENABLED,cloudEnabled)
            .putInt(KEY_CLOUD_HOURS,cloudHours)
            .putInt(KEY_LOCAL_RETENTION,localRetention)
            .putInt(KEY_CLOUD_RETENTION,cloudRetention)
            .apply();
        BackupWorker.schedule(c);
        if(liveEnabled && liveTreeUri(c)!=null) scheduleLiveMirror(c);
    }

    public static void setTreeUri(Context c,Uri uri){
        if(uri==null)return;
        takePersisted(c,uri);
        prefs(c).edit().putString(KEY_TREE_URI,uri.toString()).apply();
        BackupWorker.schedule(c);
    }
    public static void clearTreeUri(Context c){prefs(c).edit().remove(KEY_TREE_URI).apply();BackupWorker.schedule(c);}
    public static Uri treeUri(Context c){String s=prefs(c).getString(KEY_TREE_URI,"");return s.isEmpty()?null:Uri.parse(s);}

    // ---------------- LIVE BACKUP ----------------
    public static void setLiveTreeUri(Context c,Uri uri){
        if(uri==null)return;
        takePersisted(c,uri);
        prefs(c).edit().putString(KEY_LIVE_TREE_URI,uri.toString()).apply();
        if(prefs(c).getBoolean(KEY_LIVE_ENABLED,false)) scheduleLiveMirror(c);
    }
    public static void clearLiveTreeUri(Context c){prefs(c).edit().remove(KEY_LIVE_TREE_URI).remove(KEY_LIVE_ROOT_NAME).apply();}
    public static Uri liveTreeUri(Context c){String s=prefs(c).getString(KEY_LIVE_TREE_URI,"");return s.isEmpty()?null:Uri.parse(s);}

    private static void takePersisted(Context c,Uri uri){
        int flags=Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        try{c.getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
    }

    private static DocumentFile ensureWritableRoot(Context c,Uri tree,String rootName)throws IOException{
        if(tree==null)throw new IOException("Folder is not configured");
        DocumentFile parent=DocumentFile.fromTreeUri(c,tree);
        if(parent==null||!parent.canWrite())throw new IOException("Selected folder is not writable");
        return findOrCreateDir(parent,rootName);
    }

    public static DocumentFile ensureLiveDataFolders(Context c)throws IOException{
        Uri tree=liveTreeUri(c);
        DocumentFile root=ensureWritableRoot(c,tree,safeHospital(hospitalName(c))+"_appdata");
        findOrCreateDir(root,"database");
        findOrCreateDir(root,"prescriptions");
        findOrCreateDir(root,"bills");
        findOrCreateDir(root,"templates");
        findOrCreateDir(root,"hospital");
        prefs(c).edit().putString(KEY_LIVE_ROOT_NAME,root.getName()).apply();
        return root;
    }

    /** Coalesced background sync. No work is scheduled unless Live Backup is explicitly enabled and a folder is set. */
    public static void scheduleLiveMirror(final Context context){
        SharedPreferences p=prefs(context);
        if(!p.getBoolean(KEY_LIVE_ENABLED,false) || liveTreeUri(context)==null)return;
        synchronized(LIVE_LOCK){
            if(liveMirrorFuture!=null)liveMirrorFuture.cancel(false);
            final Context app=context.getApplicationContext();
            liveMirrorFuture=LIVE_EXECUTOR.schedule(()->{
                try{mirrorLiveData(app);}catch(Exception ignored){}
            },500,TimeUnit.MILLISECONDS);
        }
    }

    /** Mirrors the complete application files that are relevant to recovery. */
    public static void mirrorLiveData(Context c)throws IOException{
        SharedPreferences p=prefs(c);
        if(!p.getBoolean(KEY_LIVE_ENABLED,false))return;
        Uri tree=liveTreeUri(c);if(tree==null)return;
        DocumentFile root=ensureLiveDataFolders(c);
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");
        if(!db.exists())return;
        // Flush WAL so the external database is a single self-contained SQLite file.
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){
            try(Cursor x=d.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null)){}catch(Exception ignored){}
        }
        copyFileToDocument(c,db,findOrCreateDir(root,"database"),"SiddiqClinic.db","application/octet-stream");
        mirrorDirectory(c,new File(c.getFilesDir(),"prescriptions"),findOrCreateDir(root,"prescriptions"));
        // These directories are intentionally supported even when currently empty so
        // future file-backed templates/bills/hospital data do not require a new design.
        mirrorDirectory(c,new File(c.getFilesDir(),"bills"),findOrCreateDir(root,"bills"));
        mirrorDirectory(c,new File(c.getFilesDir(),"templates"),findOrCreateDir(root,"templates"));
        mirrorDirectory(c,new File(c.getFilesDir(),"hospital"),findOrCreateDir(root,"hospital"));
        writeManifest(c,root);
    }

    private static void writeManifest(Context c,DocumentFile root)throws IOException{
        DocumentFile old=root.findFile("app_state.json");if(old!=null)old.delete();
        DocumentFile m=root.createFile("application/json","app_state.json");
        if(m==null)throw new IOException("Unable to create live backup manifest");
        try{
            JSONObject j=new JSONObject();j.put("application_version",APP_VERSION);j.put("backup_type","LIVE_BACKUP");
            j.put("hospital_name",hospitalName(c));j.put("updated_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));
            try(OutputStream out=c.getContentResolver().openOutputStream(m.getUri(),"w")){if(out!=null)out.write(j.toString(2).getBytes(StandardCharsets.UTF_8));}
        }catch(org.json.JSONException e){throw new IOException("Unable to create live backup manifest",e);}
    }

    private static void mirrorDirectory(Context c,File src,DocumentFile dest)throws IOException{
        if(!src.exists()||!src.isDirectory())return;
        File[] fs=src.listFiles();if(fs==null)return;
        Set<String> expected=new HashSet<>();
        for(File f:fs){expected.add(f.getName());if(f.isDirectory()){
            DocumentFile child=findOrCreateDir(dest,f.getName());mirrorDirectory(c,f,child);
        }else copyFileToDocument(c,f,dest,f.getName(),guessMime(f.getName()));}
        // Remove stale files/directories from the external mirror.
        for(DocumentFile old:dest.listFiles())if(old.getName()!=null&&!expected.contains(old.getName()))old.delete();
    }

    private static void copyFileToDocument(Context c,File source,DocumentFile parent,String name,String mime)throws IOException{
        DocumentFile old=parent.findFile(name);if(old!=null)old.delete();
        DocumentFile dest=parent.createFile(mime,name);if(dest==null)throw new IOException("Unable to create live backup file: "+name);
        try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=c.getContentResolver().openOutputStream(dest.getUri(),"w")){
            if(out==null)throw new IOException("Unable to write live backup file: "+name);
            byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();
        }
    }

    public static void mirrorPrescriptionFileAsync(final Context context,final File source,final String relativeName){
        SharedPreferences p=prefs(context);
        if(source==null||!source.exists()||!p.getBoolean(KEY_LIVE_ENABLED,false)||liveTreeUri(context)==null)return;
        LIVE_EXECUTOR.execute(()->{try{mirrorPrescriptionFile(context.getApplicationContext(),source,relativeName);}catch(Exception ignored){}});
    }
    public static void mirrorPrescriptionFile(Context c,File source,String relativeName)throws IOException{
        if(!prefs(c).getBoolean(KEY_LIVE_ENABLED,false)||liveTreeUri(c)==null||source==null||!source.exists())return;
        DocumentFile root=ensureLiveDataFolders(c),dir=findOrCreateDir(root,"prescriptions");
        copyFileToDocument(c,source,dir,new File(relativeName).getName(),"application/pdf");
        writeManifest(c,root);
    }

    // ---------------- LOCAL BACKUP ----------------
    public static void setLocalBackupTreeUri(Context c,Uri uri){
        if(uri==null)return;takePersisted(c,uri);
        prefs(c).edit().putString(KEY_LOCAL_TREE_URI,uri.toString()).apply();
        BackupWorker.schedule(c);
    }
    public static void clearLocalBackupTreeUri(Context c){prefs(c).edit().remove(KEY_LOCAL_TREE_URI).remove(KEY_LOCAL_ROOT_NAME).apply();BackupWorker.schedule(c);}
    public static Uri localBackupTreeUri(Context c){String s=prefs(c).getString(KEY_LOCAL_TREE_URI,"");return s.isEmpty()?null:Uri.parse(s);}

    private static DocumentFile localBackupRoot(Context c)throws IOException{
        Uri tree=localBackupTreeUri(c);if(tree==null)throw new IOException("Local Backup folder is not configured");
        DocumentFile root=ensureWritableRoot(c,tree,safeHospital(hospitalName(c))+"_backup");
        prefs(c).edit().putString(KEY_LOCAL_ROOT_NAME,root.getName()).apply();return root;
    }
    private static DocumentFile localDay(Context c)throws IOException{return findOrCreateDir(localBackupRoot(c),today());}

    public static File createLocalBackup(Context c)throws Exception{
        return createLocalBackup(c,false);
    }
    public static File createLocalBackup(Context c,boolean manual)throws Exception{
        if(localBackupTreeUri(c)==null)throw new IOException("Local Backup folder is not configured. Select a Local Backup folder first.");
        File zip=buildBackupZip(c,new File(c.getCacheDir(),fileName(c)));
        DocumentFile day=localDay(c);String name=fileName(c);
        DocumentFile old=day.findFile(name);if(old!=null)old.delete();
        copyFileToDocument(c,zip,day,name,"application/zip");
        prefs(c).edit().putLong(KEY_LAST_LOCAL,System.currentTimeMillis()).apply();
        pruneSelectedLocal(c);
        return zip;
    }

    /** Creates an internal safety snapshot without requiring a Local Backup folder. */
    private static File createSafetyBackup(Context c)throws Exception{
        File dir=new File(c.getCacheDir(),"safety_backups");if(!dir.exists())dir.mkdirs();
        return buildBackupZip(c,new File(dir,"safety_"+System.currentTimeMillis()+".zip"));
    }

    private static File buildBackupZip(Context c,File out)throws Exception{
        File db=new File(c.getFilesDir(),"SiddiqClinic.db");if(!db.exists())throw new IOException("Application database is missing");
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(db.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){
            try(Cursor x=d.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null)){}catch(Exception ignored){}
        }
        JSONObject info=new JSONObject();
        info.put("backup_format_version",BACKUP_FORMAT_VERSION);info.put("application_name","Siddiq Clinic");
        info.put("application_version",APP_VERSION);info.put("database_version",databaseVersion(db));
        info.put("hospital_name",hospitalName(c));info.put("backup_date",today());
        info.put("created_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));
        File tmp=new File(out.getParent(),out.getName()+".tmp");if(tmp.exists())tmp.delete();
        try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))){
            putText(z,"backup_info.json",info.toString(2));
            // v2 snapshots contain the complete private files directory. Database and
            // prescription PDFs therefore remain together with any future file-backed data.
            addDir(z,c.getFilesDir(),"app_files");
        }
        if(out.exists())out.delete();if(!tmp.renameTo(out)){copy(tmp,out);tmp.delete();}
        return out;
    }

    // ---------------- GOOGLE DRIVE CLOUD BACKUP ----------------
    public static boolean isGoogleDriveConnected(Context c){
        String email=prefs(c).getString(KEY_GOOGLE_EMAIL,"");
        if(email.isEmpty()) return false;
        GoogleSignInAccount a=GoogleSignIn.getLastSignedInAccount(c);
        return a!=null && a.getEmail()!=null && email.equalsIgnoreCase(a.getEmail());
    }
    public static String googleAccountEmail(Context c){return prefs(c).getString(KEY_GOOGLE_EMAIL,"");}
    public static void setGoogleAccount(Context c,GoogleSignInAccount account)throws Exception{
        if(account==null||account.getEmail()==null)throw new IOException("No Google account was returned");
        prefs(c).edit().putString(KEY_GOOGLE_EMAIL,account.getEmail()).remove(KEY_GOOGLE_ROOT_ID).apply();
    }
    public static void clearGoogleAccount(Context c){prefs(c).edit().remove(KEY_GOOGLE_EMAIL).remove(KEY_GOOGLE_ROOT_ID).apply();}

    private static String googleToken(Context c)throws Exception{
        GoogleSignInAccount a=GoogleSignIn.getLastSignedInAccount(c);
        String email=prefs(c).getString(KEY_GOOGLE_EMAIL,"");
        if(a==null||a.getAccount()==null||email.isEmpty())throw new IOException("Google Drive is not connected");
        if(a.getEmail()!=null&&!email.equalsIgnoreCase(a.getEmail()))throw new IOException("Connected Google account changed. Connect Google Drive again.");
        String scope="oauth2:https://www.googleapis.com/auth/drive.file";
        try{
            return GoogleAuthUtil.getToken(c,a.getAccount(),scope);
        }catch(UserRecoverableAuthException e){throw new IOException("Google authorization is required again. Disconnect and connect Google Drive again.",e);}
    }

    private static JSONObject driveJson(Context c,String method,String url,String token,String body)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();
        h.setRequestMethod(method);h.setConnectTimeout(20000);h.setReadTimeout(60000);
        h.setRequestProperty("Authorization","Bearer "+token);h.setRequestProperty("Accept","application/json");
        if(body!=null){h.setDoOutput(true);h.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream o=h.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();
        String text="";if(in!=null)try(InputStream ii=in){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=ii.read(x))>0)b.write(x,0,n);text=new String(b.toByteArray(),StandardCharsets.UTF_8);}
        if(code<200||code>=300)throw new IOException("Google Drive HTTP "+code+": "+text);
        return text.isEmpty()?new JSONObject():new JSONObject(text);
    }

    private static String driveFindFolder(Context c,String token,String name,String parentId)throws Exception{
        String q="name = '"+name.replace("'","\\'")+"' and mimeType = 'application/vnd.google-apps.folder' and trashed = false and '"+parentId+"' in parents";
        String url="https://www.googleapis.com/drive/v3/files?q="+java.net.URLEncoder.encode(q,"UTF-8")+"&pageSize=10&fields=files(id,name)";
        JSONObject o=driveJson(c,"GET",url,token,null);org.json.JSONArray a=o.optJSONArray("files");
        return a!=null&&a.length()>0?a.getJSONObject(0).optString("id",""):"";
    }
    private static String driveCreateFolder(Context c,String token,String name,String parentId)throws Exception{
        JSONObject meta=new JSONObject();meta.put("name",name);meta.put("mimeType","application/vnd.google-apps.folder");
        meta.put("parents",new org.json.JSONArray().put(parentId));
        return driveJson(c,"POST","https://www.googleapis.com/drive/v3/files?fields=id,name",token,meta.toString()).getString("id");
    }
    private static String driveEnsureFolder(Context c,String token,String name,String parentId)throws Exception{
        String id=driveFindFolder(c,token,name,parentId);return id.isEmpty()?driveCreateFolder(c,token,name,parentId):id;
    }
    private static String driveFindFile(Context c,String token,String name,String parentId)throws Exception{
        String q="name = '"+name.replace("'","\\'")+"' and trashed = false and '"+parentId+"' in parents";
        String url="https://www.googleapis.com/drive/v3/files?q="+java.net.URLEncoder.encode(q,"UTF-8")+"&pageSize=10&fields=files(id,name)";
        JSONObject o=driveJson(c,"GET",url,token,null);org.json.JSONArray a=o.optJSONArray("files");
        return a!=null&&a.length()>0?a.getJSONObject(0).optString("id",""):"";
    }
    private static void driveUpload(Context c,String token,File local,String parentId,String existingId)throws Exception{
        String boundary="siddiq_"+System.currentTimeMillis();
        String meta="{\"name\":"+JSONObject.quote(local.getName())+",\"mimeType\":\"application/zip\""+(existingId.isEmpty()?",\"parents\":["+JSONObject.quote(parentId)+"]":"")+"}";
        String base=existingId.isEmpty()?"https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name":"https://www.googleapis.com/upload/drive/v3/files/"+existingId+"?uploadType=multipart&fields=id,name";
        HttpURLConnection h=(HttpURLConnection)new URL(base).openConnection();h.setRequestMethod(existingId.isEmpty()?"POST":"PATCH");h.setDoOutput(true);h.setConnectTimeout(20000);h.setReadTimeout(120000);
        h.setRequestProperty("Authorization","Bearer "+token);h.setRequestProperty("Content-Type","multipart/related; boundary="+boundary);
        try(OutputStream o=new BufferedOutputStream(h.getOutputStream());InputStream in=new BufferedInputStream(new FileInputStream(local))){
            o.write(("--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+meta+"\r\n").getBytes(StandardCharsets.UTF_8));
            o.write(("--"+boundary+"\r\nContent-Type: application/zip\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            byte[] b=new byte[32768];int n;while((n=in.read(b))>0)o.write(b,0,n);o.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
        }
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();String err="";if(in!=null)try(InputStream ii=in){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=ii.read(x))>0)b.write(x,0,n);err=new String(b.toByteArray(),StandardCharsets.UTF_8);}if(code<200||code>=300)throw new IOException("Google Drive upload HTTP "+code+": "+err);
    }
    private static void driveDelete(Context c,String token,String id)throws Exception{driveJson(c,"DELETE","https://www.googleapis.com/drive/v3/files/"+java.net.URLEncoder.encode(id,"UTF-8"),token,null);}

    public static void syncLatestToDrive(Context c)throws Exception{
        File local=materializeLatestLocalBackup(c);if(local==null){createLocalBackup(c,false);local=materializeLatestLocalBackup(c);}if(local==null)throw new IOException("No Local Backup is available. Configure Local Backup and create a backup first.");uploadBackupToGoogleDrive(c,local);
    }
    public static void syncLastLocalBackupToDrive(Context c)throws Exception{
        File local=materializeLatestLocalBackup(c);if(local==null)throw new IOException("No Local Backup is available. Configure Local Backup and create a backup first.");uploadBackupToGoogleDrive(c,local);
    }
    private static void uploadBackupToGoogleDrive(Context c,File local)throws Exception{
        if(local==null||!local.exists()||local.length()<1000)throw new IOException("Local Backup is missing or invalid");
        String token=googleToken(c);String rootName=safeHospital(hospitalName(c))+"_backup";String root=driveEnsureFolder(c,token,rootName,"root");
        prefs(c).edit().putString(KEY_GOOGLE_ROOT_ID,root).apply();String dayName=backupDateFromZip(local);String day=driveEnsureFolder(c,token,dayName,root);
        String existing=driveFindFile(c,token,local.getName(),day);driveUpload(c,token,local,day,existing);
        prefs(c).edit().putLong(KEY_LAST_CLOUD,System.currentTimeMillis()).apply();
        pruneGoogleDrive(c,token,root);
    }
    private static void pruneGoogleDrive(Context c,String token,String root){
        try{int keep=prefs(c).getInt(KEY_CLOUD_RETENTION,30);String q="'"+root+"' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false";String url="https://www.googleapis.com/drive/v3/files?q="+java.net.URLEncoder.encode(q,"UTF-8")+"&pageSize=100&fields=files(id,name)";JSONObject o=driveJson(c,"GET",url,token,null);org.json.JSONArray a=o.optJSONArray("files");if(a==null||a.length()<=keep)return;List<JSONObject> days=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if(x.optString("name","").matches("\\d{8}"))days.add(x);}days.sort(Comparator.comparing(x->x.optString("name")));for(int i=0;i<days.size()-keep;i++)driveDelete(c,token,days.get(i).getString("id"));}catch(Exception ignored){}
    }

    // ---------------- RESTORE ----------------
    public static JSONObject restoreZip(Context c,InputStream input)throws Exception{
        File tmp=new File(c.getCacheDir(),"restore_"+System.currentTimeMillis()+".zip");
        try(OutputStream o=new FileOutputStream(tmp)){byte[]b=new byte[32768];int n;while((n=input.read(b))>0)o.write(b,0,n);}return restoreZipFile(c,tmp);
    }
    public static JSONObject restoreZipFile(Context c,File zip)throws Exception{
        JSONObject info=null;int fmt=1;File stage=new File(c.getCacheDir(),"restore_stage_"+System.currentTimeMillis());if(!stage.mkdirs())throw new IOException("Unable to create restore staging folder");
        try(ZipFile z=new ZipFile(zip)){
            ZipEntry ie=z.getEntry("backup_info.json");if(ie==null)throw new IOException("Invalid backup: backup_info.json is missing");
            try(InputStream in=z.getInputStream(ie)){ByteArrayOutputStream bout=new ByteArrayOutputStream();byte[] bb=new byte[8192];int nn;while((nn=in.read(bb))>0)bout.write(bb,0,nn);info=new JSONObject(new String(bout.toByteArray(),StandardCharsets.UTF_8));}
            fmt=info.optInt("backup_format_version",1);if(fmt!=1&&fmt!=2)throw new IOException("Unsupported backup format version: "+fmt);
            if(fmt==1){if(z.getEntry("database/SiddiqClinic.db")==null)throw new IOException("Backup database is missing");extract(z,"database/",new File(stage,"database"));extract(z,"prescriptions/",new File(stage,"prescriptions"));}
            else {if(z.getEntry("app_files/SiddiqClinic.db")==null)throw new IOException("Backup database is missing");extract(z,"app_files/",new File(stage,"app_files"));}
        }
        int backupVersion=info.optInt("application_version",0);int backupDbVersion=info.optInt("database_version",0);
        if(backupVersion<=0)throw new IOException("Backup application version is missing");
        if(backupVersion>APP_VERSION)throw new IOException("This backup was created by a newer Siddiq Clinic version (v"+backupVersion+"). Install/update the app before restoring it.");
        if(backupDbVersion>APP_VERSION)throw new IOException("This backup database schema is newer than this app. Install/update the app before restoring it.");
        File stagedDb=fmt==1?new File(stage,"database/SiddiqClinic.db"):new File(stage,"app_files/SiddiqClinic.db");
        if(!stagedDb.exists()||stagedDb.length()<10000)throw new IOException("Backup database is invalid or empty");
        try(SQLiteDatabase d=SQLiteDatabase.openDatabase(stagedDb.getPath(),null,SQLiteDatabase.OPEN_READONLY)){d.rawQuery("SELECT name FROM sqlite_master LIMIT 1",null).close();}

        File safety=createSafetyBackup(c);
        File currentRoot=c.getFilesDir();
        new File(c.getFilesDir(),"SiddiqClinic.db-wal").delete();new File(c.getFilesDir(),"SiddiqClinic.db-shm").delete();
        if(fmt==2){
            // Replace only files represented in the backup, preserving Android runtime files.
            File stagedRoot=new File(stage,"app_files");
            File[] existing=currentRoot.listFiles();if(existing!=null)for(File f:existing)deleteTree(f);
            currentRoot.mkdirs();copyTreeContents(stagedRoot,currentRoot);
        }else{
            File currentDb=new File(c.getFilesDir(),"SiddiqClinic.db");copy(stagedDb,currentDb);
            File sp=new File(c.getFilesDir(),"prescriptions");if(sp.exists())deleteTree(sp);File stagedPres=new File(stage,"prescriptions");if(stagedPres.exists())copyTree(stagedPres,sp);
        }
        deleteTree(stage);try{zip.delete();}catch(Exception ignored){}
        JSONObject out=new JSONObject();out.put("backupVersion",backupVersion);out.put("backupDatabaseVersion",backupDbVersion);out.put("currentVersion",APP_VERSION);out.put("migrated",backupVersion!=APP_VERSION);out.put("safetyBackup",safety.getName());return out;
    }

    private static void extract(ZipFile z,String prefix,File dest)throws IOException{
        dest.mkdirs();Enumeration<? extends ZipEntry> en=z.entries();while(en.hasMoreElements()){
            ZipEntry e=en.nextElement();if(e.isDirectory()||!e.getName().startsWith(prefix))continue;String rel=e.getName().substring(prefix.length());if(rel.isEmpty())continue;
            File f=new File(dest,rel);File canon=dest.getCanonicalFile();if(!f.getCanonicalPath().startsWith(canon.getPath()+File.separator))throw new IOException("Unsafe backup path");
            f.getParentFile().mkdirs();try(InputStream in=z.getInputStream(e);OutputStream out=new FileOutputStream(f)){byte[]b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}
        }
    }
    private static void copyTreeContents(File src,File dst)throws IOException{
        if(!src.exists())return;File[] fs=src.listFiles();if(fs==null)return;for(File f:fs){File target=new File(dst,f.getName());if(f.isDirectory()){target.mkdirs();copyTreeContents(f,target);}else{target.getParentFile().mkdirs();copy(f,target);}}
    }
    private static void copyTree(File src,File dst)throws IOException{if(src.isDirectory()){dst.mkdirs();File[]fs=src.listFiles();if(fs!=null)for(File f:fs)copyTree(f,new File(dst,f.getName()));}else{dst.getParentFile().mkdirs();copy(src,dst);}}
    private static void deleteTree(File f){if(!f.exists())return;if(f.isDirectory()){File[]fs=f.listFiles();if(fs!=null)for(File x:fs)deleteTree(x);}f.delete();}
    private static void copy(File a,File b)throws IOException{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[]x=new byte[16384];int n;while((n=i.read(x))>0)o.write(x,0,n);}}
    private static void putText(ZipOutputStream z,String name,String s)throws IOException{ZipEntry e=new ZipEntry(name);z.putNextEntry(e);z.write(s.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private static void addDir(ZipOutputStream z,File dir,String base)throws IOException{if(!dir.exists()||!dir.isDirectory())return;File[] fs=dir.listFiles();if(fs==null)return;for(File f:fs){String p=base+"/"+f.getName();if(f.isDirectory())addDir(z,f,p);else addFile(z,f,p);}}
    private static void addFile(ZipOutputStream z,File f,String path)throws IOException{ZipEntry e=new ZipEntry(path);z.putNextEntry(e);try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)z.write(b,0,n);}z.closeEntry();}
    private static String guessMime(String n){String s=n==null?"":n.toLowerCase(Locale.US);if(s.endsWith(".pdf"))return "application/pdf";if(s.endsWith(".json"))return "application/json";if(s.endsWith(".png"))return "image/png";if(s.endsWith(".jpg")||s.endsWith(".jpeg"))return "image/jpeg";return "application/octet-stream";}
    private static DocumentFile findOrCreateDir(DocumentFile parent,String name)throws IOException{DocumentFile f=parent.findFile(name);if(f!=null&&f.isDirectory())return f;if(f!=null)f.delete();f=parent.createDirectory(name);if(f==null)throw new IOException("Unable to create folder: "+name);return f;}
}
