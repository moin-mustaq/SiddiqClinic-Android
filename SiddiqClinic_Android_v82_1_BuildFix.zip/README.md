Siddiq Clinic Android v82

Added configurable OPD, LAB and CHECKOUT bill templates. Admin can set body left/right character indexes, per-line field positions, left/center/right alignment, add/remove/reorder lines, separators, custom text, and save templates in SQLite. Saved templates are used for actual bill printing.
