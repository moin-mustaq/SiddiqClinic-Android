# SiddiqClinic Android v96

Fixes: bill header rendering, OPD/LAB patient ID direct search, bill preview restoration, prescription patient/vitals field rendering, and Patients Admitted Today count includes checked-out admissions.


## v95 changes
- Removed ruled guide lines from Medicine handwriting canvases in Prescription tab.
- Added Provisional Diagnosis consultation tab immediately after Chief Complaint.
- Added 3-line touch handwriting for Provisional Diagnosis and persistence in consultation/PDF.
- Added per-box line configuration: show/hide, line 1/2/3 top position, left/right, color, thickness.
- Added line configuration to Chief Complaint, Provisional Diagnosis, General Examination, Medical History, Drug Allergies, Investigation, and Advice/Follow-up.
- Prescription template keeps exactly Medicine/Dose/Frequency and configurable column percentages.

## v96 changes
- Added independent Content Left, Content Top, Content Right, and Content Bottom controls for each of the five right-side clinical boxes: Provisional Diagnosis, General Examination, Medical History, Drug Allergies, and Investigation.
- Content position settings move the written/selected text or handwriting area independently without changing the box position or ruled-line positions.
- Added explicit default 3-line configuration for Investigation.
