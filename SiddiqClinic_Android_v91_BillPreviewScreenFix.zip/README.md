# SiddiqClinic Android v89

Fixes bill printing so configured hospital/laboratory header details are restored when an older saved OPD/LAB/Checkout template contains no enabled organization header fields. Existing per-field configuration is preserved when at least one organization header field is configured.
