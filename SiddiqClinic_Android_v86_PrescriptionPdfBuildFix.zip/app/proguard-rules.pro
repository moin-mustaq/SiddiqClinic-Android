# No custom shrinking rules; release build intentionally keeps the WebView bridge intact.
