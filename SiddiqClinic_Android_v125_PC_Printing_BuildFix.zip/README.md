# Siddiq Clinic Android v125

v125 keeps the v124 separated backup architecture and adds PC Network Printing.

## Backup architecture
- Primary application data remains in Android app-private storage.
- **Live Backup** is optional and disabled by default. It has its own selected folder and creates `<HospitalNameWithoutSpaces>_appdata/`. No folder is created or synchronized when Live Backup is disabled or no folder is configured.
- **Local Backup** is completely separate and has its own selected folder. It creates `<HospitalNameWithoutSpaces>_backup/YYYYMMDD/<HospitalName>_125_<YYYYMMDD>.zip`.
- Google Drive uploads the latest successful Local Backup ZIP.
- Restore accepts older supported backups and blocks backups created by a newer app version.
- Live synchronization remains off the UI/JavaScript thread and is coalesced.

## PC Network Printing
- A Windows PC can act as the print bridge for a USB/non-Wi-Fi printer.
- Android and PC must be on the same Wi-Fi.
- The Android app discovers the PC automatically using mDNS/NSD; no daily IP entry is required.
- Existing Siddiq Clinic PRINT and SAVE & PRINT operations can use the PC printer when PC Printer Mode is enabled.
- If the cached PC address stops responding, the Android app clears it and searches for the print server again.
- The PC print server prints the received A4 PDF through the selected Windows printer.

## PC Print Server installation
1. On the Windows PC, verify the USB printer prints a Windows test page.
2. Install Python 3.11 or newer and enable **Add python.exe to PATH**.
3. Open the `PC_Print_Server` folder and double-click `install.bat`.
4. Double-click `start_server.bat`.
5. Allow Windows Firewall access on the **Private network** when prompted. Do not expose port 5015 to the Internet.
6. The Siddiq Print Server window should show RUNNING and the Windows printer.
7. Click TEST PRINT in the server window.

## Android test
1. Connect Android and the PC to the same Wi-Fi.
2. Open **Backup & Restore -> PC NETWORK PRINTER**.
3. Set PC Printer Mode to **Enabled**.
4. Tap **FIND PC**.
5. Tap **TEST PRINT**.
6. After the test succeeds, normal PRINT/SAVE & PRINT actions can use the PC printer.

The PC print server is intended for the private clinic LAN only.
