# Siddiq Clinic Android V136

## Configurable page and rendering settings

V135 is based on the working V134 build and adds configurable print-page settings without changing the existing visual templates.

### Prescription template
In **Prescription Templates → PAGE / PRINT SETTINGS**:
- Page Width (mm)
- Page Height (mm)
- Orientation (Portrait/Landscape)
- Resolution (DPI), default 300
- Top/Bottom/Left/Right margins (mm)

### OPD / LAB / CHECKOUT bill templates
Each bill template has its own **PAGE / PRINT SETTINGS**:
- Paper width/height in mm
- Portrait/Landscape
- Resolution (DPI), default 300
- Four margins in mm

These settings are stored with each template and are passed to the Android PDF renderer when that template is printed to the PC.

### Rendering
Generic OPD/LAB/Checkout printing now renders the configured physical page at the configured DPI and creates a PDF page using the physical mm dimensions. The existing template HTML/CSS is retained.

The existing prescription printing path remains unchanged from V134 (the working prescription PDF path), while its template now exposes the same page/resolution configuration for future use.

## Suggested first test
Use the defaults:
- A4: 210 x 297 mm
- Portrait
- 300 DPI
- 0 mm margins

Then test OPD, LAB and Checkout and inspect the received PDF in `received_jobs` before changing the PC printer rendering.

## V136 bill template UI fixes
- OPD / LAB / CHECKOUT selector is horizontally scrollable on small screens and the active template is highlighted correctly.
- Live bill preview is now inside a two-axis scroll container so the complete A4/custom page can be inspected on a phone.
- Preview uses the configured paper size, orientation and margins instead of always displaying a hard-coded A4 preview.
- Printing behavior and saved bill-template data are otherwise unchanged.


## V138 fixes
- Bill Templates: OPD BILL, LAB BILL and CHECKOUT BILL tabs remain selectable and the Live Preview is a real two-dimensional scroll area so the complete A4/custom page can be inspected on a phone.
- Google Drive: the app no longer labels every non-OK OAuth result as “cancelled”. It extracts Google Sign-In status codes, shows the exact error, and displays the installed APK package name and signing SHA-1 for OAuth configuration.
- Google Drive continues to request the narrow `drive.file` scope.

### Google OAuth requirement
For the installed APK, the Google Cloud Android OAuth client must match package `com.siddiqclinic.android` and the signing certificate SHA-1 shown by the app/build workflow. Google documents that Android OAuth credentials require the signing certificate SHA-1.
