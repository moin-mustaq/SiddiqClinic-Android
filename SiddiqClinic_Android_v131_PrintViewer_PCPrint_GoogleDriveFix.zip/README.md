# Siddiq Clinic Android v126

v126 keeps the v124 separated backup architecture and adds PC Network Printing.

## Backup architecture
- Primary application data remains in Android app-private storage.
- **Live Backup** is optional and disabled by default. It has its own selected folder and creates `<HospitalNameWithoutSpaces>_appdata/`. No folder is created or synchronized when Live Backup is disabled or no folder is configured.
- **Local Backup** is completely separate and has its own selected folder. It creates `<HospitalNameWithoutSpaces>_backup/YYYYMMDD/<HospitalName>_125_<YYYYMMDD>.zip`.
- Google Drive uploads the latest successful Local Backup ZIP.
- Restore accepts older supported backups and blocks backups created by a newer app version.
- Live synchronization remains off the UI/JavaScript thread and is coalesced.

## PC Network Printing
- A Windows PC can act as the print bridge for a USB/non-Wi-Fi printer.
- Android and PC must be on the same Wi-Fi.
- The Android app discovers the PC automatically using mDNS/NSD; no daily IP entry is required.
- Existing Siddiq Clinic PRINT and SAVE & PRINT operations can use the PC printer when PC Printer Mode is enabled.
- If the cached PC address stops responding, the Android app clears it and searches for the print server again.
- The PC print server prints the received A4 PDF through the selected Windows printer.

## PC Print Server installation
1. On the Windows PC, verify the USB printer prints a Windows test page.
2. Install Python 3.11 or newer and enable **Add python.exe to PATH**.
3. Open the `PC_Print_Server` folder and double-click `install.bat`.
4. Double-click `start_server.bat`.
5. Allow Windows Firewall access on the **Private network** when prompted. Do not expose port 5015 to the Internet.
6. The Siddiq Print Server window should show RUNNING and the Windows printer.
7. Click TEST PRINT in the server window.

## Android test
1. Connect Android and the PC to the same Wi-Fi.
2. Open **Backup & Restore -> PC NETWORK PRINTER**.
3. Set PC Printer Mode to **Enabled**.
4. Tap **FIND PC**.
5. Tap **TEST PRINT**.
6. After the test succeeds, normal PRINT/SAVE & PRINT actions can use the PC printer.

The PC print server is intended for the private clinic LAN only.


## v131 Google Drive connection

Google Drive Cloud Backup now uses Google Account OAuth instead of the Android folder picker. The app requests the narrow `drive.file` scope, stores the selected Google account identifier locally (not the password), and uploads the latest successful Local Backup ZIP into `<HospitalNameWithoutSpaces>_backup/YYYYMMDD/`. The same-date ZIP is replaced on subsequent uploads and retention removes older date folders.

One-time Google Cloud setup is required before testing Google Drive: enable the Google Drive API, configure the OAuth consent screen, and create an Android OAuth client for package `com.siddiqclinic.android` with the SHA-1 certificate used to sign the APK. Google documents `drive.file` as the narrow per-file scope recommended for this kind of integration.

## v131 In-App Prescription Viewer
- Prescription PDF viewing from Patient Consultation History and View Patient Prescription now stays inside Siddiq Clinic.
- Full-screen viewer with top-right close button.
- Supports portrait and landscape screen orientations.
- Supports multi-page prescription PDFs.
- Does not launch an external PDF reader.


## v131 fixes
- In-app prescription PDF viewer renders all pages before closing PdfRenderer, preventing the cannot load page error.
- PC Printer Mode is treated as a direct-print mode even before a PC host is discovered; discovery is performed automatically instead of falling back to Android PrintManager.
- Google Drive connection is now independent of the first cloud upload; successful Google account authorization is shown as connected even when no Local Backup exists yet.
- Google authorization failures show the Google status/error code for diagnosis.
