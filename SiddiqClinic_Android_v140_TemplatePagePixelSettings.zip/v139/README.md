# Siddiq Clinic Android V139

Changes from V138:
- OPD/LAB/Checkout generic PDF rendering fixed so the bill template is not treated as a second full-size page inside the configured print page.
- Patient ID, Name, Age and Sex moved 2 mm downward in the prescription template.
- SpO2, BP, Pulse, Weight and Temperature moved 2 mm downward.
- Prescription Doctor Box now supports independently configurable Show/Hide for Doctor Name, Degree, Doctor Tagline and Specialization.
- Each doctor detail has independent position, width, font, bold and alignment settings.
- Doctor specialization is populated from the doctor's Specialization field.
- Existing Google Drive authentication diagnostics/fixes and V138 preview changes are retained.
