# Hospital Management Android V141

Changes from V138:
- OPD/LAB/Checkout generic PDF rendering fixed so the bill template is not treated as a second full-size page inside the configured print page.
- Patient ID, Name, Age and Sex moved 2 mm downward in the prescription template.
- SpO2, BP, Pulse, Weight and Temperature moved 2 mm downward.
- Prescription Doctor Box now supports independently configurable Show/Hide for Doctor Name, Degree, Doctor Tagline and Specialization.
- Each doctor detail has independent position, width, font, bold and alignment settings.
- Doctor specialization is populated from the doctor's Specialization field.
- Existing Google Drive authentication diagnostics/fixes and V138 preview changes are retained.

## V141 printing fix
OPD, LAB and CHECKOUT PC-print PDFs now use the configured physical page dimensions directly. The previous renderer applied an additional `DPI/96` WebView zoom on top of CSS millimetre sizing, which could make bills print much larger than the selected paper. V141 removes that second scaling step while retaining DPI as the render-canvas resolution.

Android application ID: `com.hospital.app`
