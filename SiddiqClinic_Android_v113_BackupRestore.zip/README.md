# Siddiq Clinic Android v110

Fixes in this version:
- OPD, LAB and Checkout printed bills always render the current Hospital/Laboratory details from Hospital Profile at the top of the actual print output. Existing template body/header positioning remains used for the rest of the bill; duplicate organization header rows from older templates are suppressed.
- Prescription PDF saving now uses the already-rendered main WebView with Android WebView PrintDocumentAdapter, the same print CSS/template used by the visible prescription. This replaces the unreliable off-screen WebView PDF path that could result in “Unable to recreate the prescription PDF.”
- Missing prescription PDFs can now be recreated from Patient Consultation History and View Patient Prescription using the same print renderer.
- PDF generation waits for the rendered prescription and polls up to 30 seconds before reporting failure.
