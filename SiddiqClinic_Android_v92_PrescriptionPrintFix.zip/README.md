# SiddiqClinic Android v92

## Prescription print/save fixes
- Patient Details fields now render above the Patient Details box background.
- General Details / Vitals fields now render above the Vitals box background.
- Prescription is a real 3-column table: Medicine, Dose, Frequency, with visible borders and header styling.
- Medicine handwriting data URLs are rendered as images instead of being printed as raw base64 characters.
- Saved prescription PDF now receives only the rendered prescription sheet instead of the whole hidden application document.
- Android PDF renderer wraps the prescription fragment in a print-ready A4 HTML document.
- Version 92.0.
